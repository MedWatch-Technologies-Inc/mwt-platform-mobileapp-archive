import 'graph_provider.dart';

class GraphProviderList {
  List<GraphProvider> graphProviderList = [];

// void addGraph(GraphProvider item) {
//   graphProviderList.add(item);
//   notifyListeners();
// }
//
// void removeGraph(int index) {
//   graphProviderList.removeAt(index);
//   notifyListeners();
// }
}
