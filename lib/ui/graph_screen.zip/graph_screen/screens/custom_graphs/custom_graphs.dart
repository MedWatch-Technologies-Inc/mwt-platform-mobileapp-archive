import 'dart:io';

import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_material_color_picker/flutter_material_color_picker.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:health_gauge/ui/graph_screen/manager/graph_item_enum.dart';
import 'package:health_gauge/ui/graph_screen/manager/graph_shared_preference_manager_model.dart';
import 'package:health_gauge/ui/graph_screen/manager/graph_type_model.dart';
import 'package:health_gauge/ui/graph_screen/providers/graph_provider.dart';
import 'package:health_gauge/ui/graph_screen/providers/graph_provider_list.dart';
import 'package:health_gauge/utils/concave_decoration.dart';
import 'package:health_gauge/utils/constants.dart';
import 'package:health_gauge/utils/gloabals.dart';
import 'package:health_gauge/value/app_color.dart';
import 'package:health_gauge/value/string_localization_support/string_localization.dart';
import 'package:health_gauge/widgets/buttons.dart';
import 'package:health_gauge/widgets/custom_dialog.dart';
import 'package:health_gauge/widgets/custom_snackbar.dart';
import 'package:health_gauge/widgets/custom_switch.dart';
import 'package:health_gauge/widgets/text_utils.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';

import '../choose_graph_items.dart';
import '../page_view_screen.dart';

class CustomGraphs extends StatefulWidget {
  final DateTime selectedDates;
  final GraphTab graphTab;
  final WindowModel graphWindow;
  final List<GraphTypeModel> graphTypeList;
  final GraphSharedPreferenceManagerModel graphSharedPreferenceManagerModel;
  final int index;
  final int currentIndex;
  final GestureTapCallback onClickRemove;
  final GraphProviderList prov;

  CustomGraphs({
    required this.selectedDates,
    required this.graphTab,
    required this.graphWindow,
    required this.graphTypeList,
    required this.graphSharedPreferenceManagerModel,
    required this.index,
    required this.onClickRemove,
    required this.prov,
    required this.currentIndex,
  });

  @override
  _CustomGraphsState createState() => _CustomGraphsState();
}

class _CustomGraphsState extends State<CustomGraphs> {
  late GraphProviderList provider;
  late GraphTypeModel model;
  late ChartType chartType;
  bool isInterpolationEnable = false;
  bool isNormalization = false;
  late ChartType tempChartType;

  @override
  void initState() {
    print('Default Graph Custom');
    provider = widget.prov;
    chartType = widget.graphWindow.selectedChartType;
    tempChartType = chartType;
    isNormalization = widget.graphWindow.normalization;
    isInterpolationEnable = widget.graphWindow.interpolation;
    // widget.graphWindow.onChangeDate.value = widget.selectedDates;

    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    print("Dispoe");
    // widget.graphWindow.onChangeDate.value = DateTime(DateTime.now().year,
    //     DateTime.now().month, DateTime.now().day, 0, 0, 0, 0, 0);
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<GraphProvider>.value(
        value: provider.graphProviderList[widget.index],
        child: Consumer<GraphProvider>(builder: (context, parent, child) {
          return Container(
              decoration: BoxDecoration(
                color: Theme.of(context).brightness == Brightness.dark
                    ? HexColor.fromHex('#111B1A')
                    : AppColor.backgroundColor,
                borderRadius: BorderRadius.circular(10.h),
                boxShadow: [
                  BoxShadow(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? HexColor.fromHex('#D1D9E6').withOpacity(0.07)
                        : Colors.white,
                    blurRadius: 4,
                    spreadRadius: 0,
                    offset: Offset(-4, -4),
                  ),
                  BoxShadow(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? HexColor.fromHex('#000000').withOpacity(0.6)
                        : HexColor.fromHex('#9F2DBC').withOpacity(0.15),
                    blurRadius: 4,
                    spreadRadius: 0,
                    offset: Offset(4, 4),
                  ),
                ],
              ),
              margin: EdgeInsets.symmetric(horizontal: 13.w, vertical: 10.h),
              child: Stack(children: [
                Container(
                  alignment: Alignment.topRight,
                  padding: EdgeInsets.only(top: 8.h, right: 20.w),
                  child: InkWell(
                    child: Image.asset(
                      'asset/pencil_icon.png',
                      height: 20.h,
                      width: 20.h,
                    ),
                    onTap: () {
                      provider.graphProviderList[widget.index].isEditMode =
                          !provider.graphProviderList[widget.index].isEditMode;
                    },
                  ),
                ),
                provider.graphProviderList[widget.index].graphWindow!.editMode
                    ? Align(
                        alignment: Alignment.topLeft,
                        child: InkWell(
                            onTap: () {
                              selectGraphType(onClickOk: () {
                                chartType = tempChartType;
                                Navigator.of(context, rootNavigator: true)
                                    .pop();
                                provider.graphProviderList[widget.index]
                                    .graphWindow?.selectedChartType = chartType;
                                provider
                                    .graphProviderList[widget.index]
                                    .graphWindow
                                    ?.normalization = isNormalization;
                                provider
                                    .graphProviderList[widget.index]
                                    .graphWindow
                                    ?.interpolation = isInterpolationEnable;
                                provider.graphProviderList[widget.index]
                                    .updatePrefForSelectedItem();
                                provider.graphProviderList[widget.index]
                                    .getData(context: context);
                              });
                            },
                            child: Padding(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 12.w, vertical: 8.h),
                              child: Icon(
                                Icons.insert_chart,
                                color: AppColor.primaryColor,
                              ),
                            )),
                      )
                    : Container(),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    SizedBox(height: 10.h),
                    Container(
                      height: 25.h,
                      width: 270.w,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                            child: Body1Text(
                              text: provider.graphProviderList[widget.index]
                                  .graphTypeName1,
                              align: provider.graphProviderList[widget.index]
                                          .selectedGraphTypeList.length ==
                                      1
                                  ? TextAlign.center
                                  : TextAlign.right,
                              color: provider
                                  .graphProviderList[widget.index].color1,
                              textOverflow: TextOverflow.ellipsis,
                            ),
                          ),
                          SizedBox(
                            width: 5.w,
                          ),
                          Body1Text(
                            text: provider.graphProviderList[widget.index]
                                        .selectedGraphTypeList.length >
                                    1
                                ? 'Vs'
                                : '',
                            align: TextAlign.center,
                          ),
                          SizedBox(
                            width: 5.w,
                          ),
                          provider.graphProviderList[widget.index]
                                      .selectedGraphTypeList.length >
                                  1
                              ? Expanded(
                                  child: Body1Text(
                                    text: provider
                                        .graphProviderList[widget.index]
                                        .graphTypeName2,
                                    align: TextAlign.left,
                                    color: provider
                                        .graphProviderList[widget.index].color2,
                                    textOverflow: TextOverflow.ellipsis,
                                  ),
                                )
                              : Container(),
                        ],
                      ),
                    ),
                    Container(
                      padding:
                          EdgeInsets.symmetric(horizontal: 8.w, vertical: 8.h),
                      height: provider.graphProviderList[widget.index]
                              .graphWindow!.editMode
                          ? 390.0.h
                          : 305.h,
                      width: MediaQuery.of(context).size.width,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Expanded(
                                child: provider.graphProviderList[widget.index]
                                        .graphWindow!.editMode
                                    ? selectedItemsListView()
                                    : SizedBox(
                                        height: 10.h,
                                      ),
                              ),
                              provider.graphProviderList[widget.index]
                                          .graphWindow!.editMode &&
                                      (provider.graphProviderList[widget.index]
                                              .selectedGraphTypeList.length >
                                          1)
                                  ? Container(
                                      padding: EdgeInsets.only(right: 20.w),
                                      child: InkWell(
                                        child: Icon(
                                          Icons.swap_horizontal_circle,
                                          color: AppColor.primaryColor,
                                          size: 30.h,
                                        ),
                                        onTap: () {
                                          provider
                                              .graphProviderList[widget.index]
                                              .isSwap = true;
                                          provider
                                              .graphProviderList[widget.index]
                                              .getData(context: context);
                                        },
                                      ),
                                    )
                                  : Container(),
                              provider.graphProviderList[widget.index]
                                      .isEditMode
                                  ? Container(
                                      padding: EdgeInsets.only(right: 5.w),
                                      child: InkWell(
                                        child: Icon(
                                          Icons.delete,
                                          color: AppColor.primaryColor,
                                        ),
                                        onTap: deleteDialog,
                                      ),
                                    )
                                  : Container(),
                            ],
                          ),

                          // provider.graphProviderList[widget.index]
                          //     .getData(context: context);

                          Expanded(
                            child: provider.graphProviderList[widget.index]
                                    .selectedGraphTypeList.isNotEmpty
                                ? graphDataLayout()
                                : Container(),
                          ),
                          SizedBox(
                            height: 20.h,
                          ),
                        ],
                      ),
                    ),
                  ],
                )
              ]));
        }));
  }

  /// Added by Shahzad
  /// Added on 31st Aug 2021
  /// to show the selected graph items
  Wrap selectedItemsListView() {
    return Wrap(
      direction: Axis.horizontal,
      children: List<Widget>.generate(
          provider.graphProviderList[widget.index].selectedGraphTypeList
                  .length +
              1, (index) {
        if (index == 0) {
          if (provider.graphProviderList[widget.index].selectedGraphTypeList
                  .length ==
              provider.graphProviderList[widget.index].graphTypeList.length) {
            return Container();
          }
          return Card(
            color: AppColor.primaryColor,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(100.h)),
            child: InkWell(
              onTap: () async {
                if (widget.graphTypeList.length !=
                    provider.graphProviderList[widget.index]
                        .selectedGraphTypeList.length) {
                  var dialog = ChooseGraphItems(
                    typeList: widget.graphTypeList,
                    selectedGraphType: provider
                        .graphProviderList[widget.index].selectedGraphTypeList,
                  );
                  GraphTypeModel graphType = await showDialog(
                      context: context, builder: (context) => dialog);
                  if (provider.graphProviderList[widget.index]
                          .selectedGraphTypeList.length ==
                      2) {
                    CustomSnackBar.buildSnackbar(
                        context,
                        stringLocalization
                            .getText(StringLocalization.addGraphRestriction),
                        3);
                  }
                  if (provider.graphProviderList[widget.index]
                          .selectedGraphTypeList.length <
                      2) {
                    provider
                        .graphProviderList[widget.index].selectedGraphTypeList
                        .add(graphType);
                    if (provider.graphProviderList[widget.index]
                            .selectedGraphTypeList.length ==
                        1) {
                      var title = provider.graphProviderList[widget.index]
                          .setGraphTitle(
                              provider.graphProviderList[widget.index]
                                  .selectedGraphTypeList,
                              0);
                      provider.graphProviderList[widget.index].graphTypeName1 =
                          title;
                      provider.graphProviderList[widget.index].graphWindow
                              ?.title =
                          provider
                              .graphProviderList[widget.index].graphTypeName1;
                    } else {
                      var title1 = provider.graphProviderList[widget.index]
                          .setGraphTitle(
                              provider.graphProviderList[widget.index]
                                  .selectedGraphTypeList,
                              0);
                      var title2 = provider.graphProviderList[widget.index]
                          .setGraphTitle(
                              provider.graphProviderList[widget.index]
                                  .selectedGraphTypeList,
                              1);
                      provider.graphProviderList[widget.index].graphTypeName1 =
                          title1;
                      provider.graphProviderList[widget.index].graphTypeName2 =
                          title2;
                      provider.graphProviderList[widget.index].graphWindow
                              ?.title =
                          '${provider.graphProviderList[widget.index].graphTypeName1} Vs ${provider.graphProviderList[widget.index].graphTypeName2}';
                    }
                    provider.graphProviderList[widget.index]
                        .updatePrefForSelectedItem();
                    provider.graphProviderList[widget.index]
                        .getData(context: context);
                    provider.graphProviderList[widget.index]
                        .isShowLoadingScreen = true;
                  }
                }
              },
              child: Container(
                key: Key('moreIcon'),
                height: 34.h,
                width: 34.h,
                // padding: EdgeInsets.all(6.h),
                child: Icon(
                  Icons.more_vert,
                  size: 30.h,
                  color: Colors.white,
                ),
              ),
            ),
          );
        }
        if (provider
            .graphProviderList[widget.index].selectedGraphTypeList.isNotEmpty) {
          model = provider
              .graphProviderList[widget.index].selectedGraphTypeList[index - 1];
        }
        if (model == null) {
          return Container();
        }
        Color color = Colors.black;
        if (model.color != null) {
          color = HexColor.fromHex(model.color);
        }
        if (index - 1 == 0) {
          provider.graphProviderList[widget.index].color1 = color;
        } else {
          provider.graphProviderList[widget.index].color2 = color;
        }

        return Container(
          constraints: BoxConstraints(
            minWidth: 80.0.h,
          ),
          margin: EdgeInsets.all(5.h),
          decoration: BoxDecoration(
              color: Theme.of(context).brightness == Brightness.dark
                  ? HexColor.fromHex('#111B1A')
                  : HexColor.fromHex('#EEF1F1').withOpacity(0.5),
              borderRadius: BorderRadius.circular(20.h),
              border: Border.all(
                color: HexColor.fromHex('#FF9E99'),
              )),
          padding: EdgeInsets.only(top: 5.h, bottom: 5.h, left: 10.w),
          child: Container(
            height: 25.h,
            constraints: BoxConstraints(maxWidth: 200.w),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                SizedBox(width: 10.w),
                GestureDetector(
                  onTap: () {
                    if (provider.graphProviderList[widget.index].isEditMode) {
                      selectColorDialog(
                          provider.graphProviderList[widget.index]
                              .selectedGraphTypeList[index - 1],
                          index);
                      provider.graphProviderList[widget.index]
                          .updatePrefForSelectedItem();
                      provider.graphProviderList[widget.index]
                          .isShowLoadingScreen = true;
                      provider.graphProviderList[widget.index]
                          .getData(context: context);
                    }
                  },
                  child: Container(
                    constraints: BoxConstraints(maxWidth: 155.w),
                    child: Body1Text(
                      text: stringLocalization.getTextFromEnglish(model.name),
                      color: color,
                      align: TextAlign.center,
                      textOverflow: TextOverflow.ellipsis,
                    ),
                  ),
                ),
                // SizedBox(
                //   width: 10.w,
                // ),
                Opacity(
                  opacity: provider.graphProviderList[widget.index].isEditMode
                      ? 1
                      : 0,
                  child: InkWell(
                    child: Container(
                      margin:
                          EdgeInsets.symmetric(vertical: 5.h, horizontal: 10.w),
                      child: Image.asset(
                        'asset/close_icon.png',
                        height: 8,
                        width: 7.5,
                      ),
                    ),
                    onTap: () {
                      if (provider.graphProviderList[widget.index].isEditMode) {
                        provider.graphProviderList[widget.index]
                            .selectedGraphTypeList
                            .removeAt(index - 1);
                        if (index - 1 == 0) {
                          provider.graphProviderList[widget.index]
                              .graphTypeName1 = provider
                                  .graphProviderList[widget.index]
                                  .selectedGraphTypeList
                                  .isEmpty
                              ? ''
                              : provider.graphProviderList[widget.index]
                                  .graphTypeName2;
                          provider.graphProviderList[widget.index].color1 =
                              color;
                          provider.graphProviderList[widget.index].graphWindow
                                  ?.title =
                              provider.graphProviderList[widget.index]
                                  .graphTypeName1;
                        } else {
                          provider.graphProviderList[widget.index]
                              .graphTypeName1 = provider
                                  .graphProviderList[widget.index]
                                  .selectedGraphTypeList
                                  .isEmpty
                              ? ''
                              : provider.graphProviderList[widget.index]
                                  .graphTypeName1;
                          provider.graphProviderList[widget.index].color1 =
                              color;
                          provider.graphProviderList[widget.index].graphWindow
                                  ?.title =
                              provider.graphProviderList[widget.index]
                                  .graphTypeName1;
                        }
                        if (chartType == ChartType.pie) {
                          chartType = ChartType.bar;
                          provider.graphProviderList[widget.index].graphWindow
                              ?.selectedChartType = chartType;
                        }
                        provider.graphProviderList[widget.index]
                            .updatePrefForSelectedItem();
                        provider.graphProviderList[widget.index]
                            .isShowLoadingScreen = true;
                        provider.graphProviderList[widget.index]
                            .getData(context: context);
                      }
                    },
                  ),
                )
              ],
            ),
          ),
        );
      }),
    );
  }

  /// Added by Shahzad
  /// Added on 1st Sept 2021
  /// to select color for the graphs
  void selectColorDialog(GraphTypeModel model, int index) {
    var selectedColor = HexColor.fromHex(model.color);
    var dialog = AlertDialog(
      title: Text(StringLocalization.of(context)
          .getText(StringLocalization.selectColor)),
      content: SingleChildScrollView(
        child: Container(
          height: 300.h,
          color: Theme.of(context).cardColor,
          child: Column(
            children: [
              Expanded(
                child: MaterialColorPicker(
                  shrinkWrap: true,
                  circleSize: 30.h,
                  colors: fullMaterialColors,
                  selectedColor: selectedColor,
                  onColorChange: (Color color) {
                    selectedColor = color;
                  },
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                mainAxisSize: MainAxisSize.max,
                children: [
                  FlatBtn(
                    onPressed: () {
                      Navigator.of(context, rootNavigator: true).pop();
                    },
                    text: stringLocalization.getText(StringLocalization.cancel),
                    color: AppColor.black,
                  ),
                  FlatBtn(
                    onPressed: () {
                      Navigator.of(context, rootNavigator: true).pop();
                      if (index - 1 == 0) {
                        provider.graphProviderList[widget.index].color1 =
                            selectedColor;
                        model.color = selectedColor.toHex();
                      } else {
                        model.color = selectedColor.toHex();
                        provider.graphProviderList[widget.index].color2 =
                            selectedColor;
                      }
                      provider.graphProviderList[widget.index]
                          .updatePrefForSelectedItem();
                      provider.graphProviderList[widget.index]
                          .isShowLoadingScreen = true;
                      provider.graphProviderList[widget.index]
                          .getData(context: context);
                    },
                    text: stringLocalization.getText(StringLocalization.ok),
                    color: AppColor.primaryColor,
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
    showDialog(
        context: context,
        useRootNavigator: true,
        builder: (context) => dialog,
        barrierDismissible: false);
  }

  /// Added by Shahzad
  /// Added on 1st Sept 2021
  /// to select different types of graph
  void selectGraphType({required GestureTapCallback onClickOk}) {
    showDialog(
        context: context,
        useRootNavigator: true,
        builder: (context) {
          return StatefulBuilder(builder: (context, setState) {
            Widget customRadio(
                {required int index,
                required Color color,
                required String unitText}) {
              return GestureDetector(
                onTap: () {
                  tempChartType = index == 0
                      ? ChartType.line
                      : index == 1
                          ? ChartType.bar
                          : ChartType.pie;
                  if (mounted) setState(() {});
                },
                child: Container(
                  height: 28.h,
                  child: Row(
                    children: [
                      Container(
                        height: 28.h,
                        width: 28.h,
                        decoration: ConcaveDecoration(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(28.h)),
                            depression: 4,
                            colors: [
                              Theme.of(context).brightness == Brightness.dark
                                  ? Colors.black.withOpacity(0.8)
                                  : HexColor.fromHex('#D1D9E6'),
                              Theme.of(context).brightness == Brightness.dark
                                  ? HexColor.fromHex('#D1D9E6').withOpacity(0.1)
                                  : Colors.white,
                            ]),
                        child: Container(
                          margin: EdgeInsets.all(6.h),
                          decoration: BoxDecoration(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? HexColor.fromHex('#111B1A')
                                  : AppColor.backgroundColor,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? HexColor.fromHex('#D1D9E6')
                                          .withOpacity(0.1)
                                      : Colors.white,
                                  blurRadius: 3,
                                  spreadRadius: 0,
                                  offset: Offset(-3, -3),
                                ),
                                BoxShadow(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.black.withOpacity(0.75)
                                      : HexColor.fromHex('#D1D9E6'),
                                  blurRadius: 3,
                                  spreadRadius: 0,
                                  offset: Offset(3, 3),
                                ),
                              ]),
                          child: Container(
                              margin: EdgeInsets.all(3.h),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: color,
                              )),
                        ),
                      ),
                      SizedBox(
                        width: 9.w,
                      ),
                      unitText != ''
                          ? Flexible(
                              child: SizedBox(
                                height: 23.h,
                                child: Body1AutoText(
                                  overflow: TextOverflow.ellipsis,
                                  text: unitText,
                                  fontSize: 16.sp,
                                  minFontSize: 10,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white.withOpacity(0.6)
                                      : HexColor.fromHex('#5D6A68'),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            )
                          : Container()
                    ],
                  ),
                ),
              );
            }

            return Dialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.h),
              ),
              elevation: 0,
              backgroundColor: Theme.of(context).brightness == Brightness.dark
                  ? HexColor.fromHex('#111B1A')
                  : AppColor.backgroundColor,
              child: Container(
                decoration: BoxDecoration(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? AppColor.darkBackgroundColor
                        : AppColor.backgroundColor,
                    borderRadius: BorderRadius.circular(10.h),
                    boxShadow: [
                      BoxShadow(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? HexColor.fromHex('#D1D9E6').withOpacity(0.1)
                            : HexColor.fromHex('#DDE3E3').withOpacity(0.3),
                        blurRadius: 5,
                        spreadRadius: 0,
                        offset: Offset(-5, -5),
                      ),
                      BoxShadow(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? HexColor.fromHex('#000000').withOpacity(0.75)
                            : HexColor.fromHex('#384341').withOpacity(0.9),
                        blurRadius: 5,
                        spreadRadius: 0,
                        offset: Offset(5, 5),
                      ),
                    ]),
                padding: EdgeInsets.only(top: 27.h, left: 20.w, right: 20.w),
                // height: selectedGraphTypeList.length == 2 ? 310.h : 248.h,
                width: 309.w,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 25,
                      child: AutoSizeText(
                        StringLocalization.of(context)
                            .getText(StringLocalization.selectGraphType),
                        style: TextStyle(
                            fontSize: 20.sp,
                            fontWeight: FontWeight.bold,
                            color: Theme.of(context).brightness ==
                                    Brightness.dark
                                ? HexColor.fromHex('#FFFFFF').withOpacity(0.87)
                                : HexColor.fromHex('#384341')),
                      ),
                    ),
                    SizedBox(height: 25.0.h),
                    Container(
                      // width: MediaQuery.of(context).size.width,
                      alignment: Alignment.topLeft,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            // flex: 5,
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  GridView.builder(
                                      gridDelegate:
                                          SliverGridDelegateWithFixedCrossAxisCount(
                                        crossAxisCount: 1,
                                        childAspectRatio: 2.8,
                                      ),
                                      physics: NeverScrollableScrollPhysics(),
                                      itemCount: provider
                                                  .graphProviderList[
                                                      widget.index]
                                                  .selectedGraphTypeList
                                                  .length ==
                                              2
                                          ? provider
                                              .graphProviderList[widget.index]
                                              .graphList
                                              .length
                                          : 2,
                                      shrinkWrap: true,
                                      itemBuilder: (context, index) {
                                        return Container(
                                          height: 28.h,
                                          child: customRadio(
                                            index: index,
                                            color: index + 1 ==
                                                    (tempChartType ==
                                                            ChartType.line
                                                        ? 1
                                                        : tempChartType ==
                                                                ChartType.bar
                                                            ? 2
                                                            : 3)
                                                ? HexColor.fromHex('FF6259')
                                                : Colors.transparent,
                                            unitText: provider
                                                .graphProviderList[widget.index]
                                                .graphList[index]
                                                .text,
                                          ),
                                        );
                                      })
                                ]),
                          ),
                          Expanded(
                              // flex: 5,
                              child: Padding(
                            padding: EdgeInsets.only(top: 14.h),
                            child: Column(
                              children: [
                                Row(
                                  // crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Expanded(
                                      child: SizedBox(
                                        height: 23.h,
                                        child: Body1AutoText(
                                          overflow: TextOverflow.ellipsis,
                                          text: stringLocalization
                                              .getText(StringLocalization
                                                  .interpolation)
                                              .toUpperCase(),
                                          fontSize: 14.sp,
                                          minFontSize: 8,
                                          fontWeight: FontWeight.bold,
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white.withOpacity(0.87)
                                              : HexColor.fromHex('#5D6A68'),
                                        ),
                                      ),
                                    ),
                                    Flexible(
                                      child: SizedBox(
                                        height: 23.h,
                                        child: CustomSwitch(
                                          value: isInterpolationEnable,
                                          onChanged: (value) {
                                            isInterpolationEnable = value;
                                            if (mounted) {
                                              setState(() {});
                                            }
                                          },
                                          activeColor:
                                              HexColor.fromHex('#00AFAA'),
                                          inactiveTrackColor:
                                              Theme.of(context).brightness ==
                                                      Brightness.dark
                                                  ? AppColor.darkBackgroundColor
                                                  : HexColor.fromHex('#E7EBF2'),
                                          inactiveThumbColor: Theme.of(context)
                                                      .brightness ==
                                                  Brightness.dark
                                              ? Colors.white.withOpacity(0.6)
                                              : HexColor.fromHex('#D1D9E6'),
                                          activeTrackColor:
                                              Theme.of(context).brightness ==
                                                      Brightness.dark
                                                  ? AppColor.darkBackgroundColor
                                                  : HexColor.fromHex('#E7EBF2'),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 30.h,
                                ),
                                Row(
                                  // crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Expanded(
                                      child: Body1Text(
                                        text: stringLocalization
                                            .getText(StringLocalization
                                                .graphNormalization)
                                            .toUpperCase(),
                                        fontSize: 14.sp,
                                        maxLine: 2,
                                        fontWeight: FontWeight.bold,
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white.withOpacity(0.87)
                                            : HexColor.fromHex('#5D6A68'),
                                      ),
                                    ),
                                    Flexible(
                                      child: SizedBox(
                                        height: 23.h,
                                        child: Checkbox(
                                          value: isNormalization,
                                          onChanged: (value) {
                                            isNormalization = value ?? false;
                                            if (mounted) {
                                              setState(() {});
                                            }
                                          },
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ))
                        ],
                      ),
                    ),
                    SizedBox(height: 5.h),
                    Align(
                      alignment: Alignment.bottomRight,
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: onClickOk,
                          child: Container(
                            margin: EdgeInsets.only(right: 7.w),
                            width: 30.w,
                            height: 23.h,
                            child: AutoSizeText(
                              stringLocalization
                                  .getText(StringLocalization.ok)
                                  .toUpperCase(),
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 14.sp,
                                color: HexColor.fromHex('#00AFAA'),
                              ),
                              textAlign: TextAlign.right,
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 27.h),
                  ],
                ),
              ),
            );
          });
        },
        barrierDismissible: false);
  }

  /// Added by Shahzad
  /// Added on 1st Sept 2021
  /// pop up window to confirm deletion of graph
  void deleteDialog() {
    var dialog = CustomDialog(
      title: stringLocalization.getText(StringLocalization.delete),
      subTitle: stringLocalization.getText(StringLocalization.deleteInfo),
      onClickNo: () {
        Navigator.of(context, rootNavigator: true).pop();
      },
      onClickYes: () {
        widget.onClickRemove();
        Navigator.of(context, rootNavigator: true).pop();
      },
      maxLine: 2,
    );
    showDialog(
        context: context,
        useRootNavigator: true,
        builder: (context) => dialog,
        barrierDismissible: false);
  }

  /// Added by Shahzad
  /// Added on 1st Sept 2021
  /// to show graph on the screen
  ///
  ///

  Future<bool> requestPermissionForGoogleFit() async {
    if (Platform.isAndroid) {
      try {
        if (preferences?.getBool(Constants.isGoogleSyncEnabled) ?? false) {
          var isGranted = await Permission.activityRecognition.isGranted;
          if (!isGranted) {
            isGranted = await Permission.activityRecognition.request() ==
                PermissionStatus.granted;
          }
          if (isGranted) {
            var isAuthenticated = await connections.checkAuthForGoogleFit();
            if (!isAuthenticated) {
              return false;
            }
          } else {
            return false;
          }
        }
      } catch (e) {
        debugPrint('Exception at requestPermissionForGoogleFit $e');
      }
    }
    return true;
  }

  Widget graphDataLayout() {
    return Selector<GraphProvider, bool>(
        selector: (context, model) => model.isShowLoadingScreen,
        builder: (context, isShowLoadingScreen, child) {
          bool isLoad = true;
          return ValueListenableBuilder(
              valueListenable: widget.graphWindow.onChangeDate,
              builder: (context, DateTime? selectedDate, child) {
                // if (widget.graphWindow.isChange.value == false) {

                //
                // if(snapshot.data == false){
                //   return Container(
                //     child: Text('Not access'),
                //   );
                // }

                if (selectedDate != null) {
                  print(
                      "graphItemList  data :::: if  ${selectedDate.toString()}  ${widget.graphWindow.isChange.value.toString()}");
                  refresh(selectedDate!);
                  widget.graphWindow.onChangeDate.value = null;
                } else {
                  if (widget.graphWindow.isChange.value) {
                    var _temp;
                    if (widget.currentIndex == 0) {
                      _temp = DateTime(
                          DateTime.now().year,
                          DateTime.now().month,
                          DateTime.now().day,
                          0,
                          0,
                          0,
                          0,
                          0);
                    }
                    if (widget.currentIndex == 1) {
                      _temp = DateTime(
                          DateTime.now().year,
                          DateTime.now().month,
                          DateTime.now().day,
                          0,
                          0,
                          0,
                          0,
                          0);
                      var dayNr = (_temp.weekday + 7) % 7 - 1;
                      _temp = _temp.subtract(Duration(days: (dayNr)));
                    }
                    if (widget.currentIndex == 2) {
                      _temp = DateTime(
                          DateTime.now().year,
                          DateTime.now().month,
                          DateTime.now().day,
                          0,
                          0,
                          0,
                          0,
                          0);
                    }

                    print(
                        "graphItemList  data :::: else if ${_temp.toString()}  ${selectedDate.toString()}  ${widget.graphWindow.isChange.value.toString()}");
                    // refresh(_temp);
                    widget.graphWindow.isChange.value = false;
                    widget.graphWindow.onChangeDate.value = _temp;
                  } else {
                    print(
                        "graphItemList  data :::: else ${selectedDate.toString()}  ${widget.graphWindow.isChange.value.toString()}");
                  }

                  // widget.graphWindow.onChangeDate.value = _temp;
                }

                if (isShowLoadingScreen &&
                    provider.graphProviderList[widget.index]
                        .selectedGraphTypeList.isNotEmpty) {
                  return Center(
                    child: CircularProgressIndicator(),
                    // child: Text(
                    //     "${isShowLoadingScreen.toString()} - ${provider.graphProviderList[widget.index].selectedGraphTypeList.length}"),
                  );
                }
                return chartType == ChartType.line
                    ? provider.graphProviderList[widget.index].lineChartWidget
                    : chartType == ChartType.bar
                        ? provider
                            .graphProviderList[widget.index].barChartWidget
                        : provider.graphProviderList[widget.index]
                            .lineAndBarChartWidget;
              });
        });
  }

  void refresh(DateTime selectedDate) {
    provider.graphProviderList[widget.index].isShowLoadingScreen = true;
    provider.graphProviderList[widget.index].setDates(selectedDate);

    provider.graphProviderList[widget.index].getData(context: context);
    // if (mounted) {
    //   setState(() {});
    // }
  }
}
