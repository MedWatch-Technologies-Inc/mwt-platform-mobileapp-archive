import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:health_gauge/ui/graph_screen/manager/graph_item_enum.dart';
import 'package:health_gauge/ui/graph_screen/manager/graph_shared_preference_manager_model.dart';
import 'package:health_gauge/ui/graph_screen/manager/graph_type_model.dart';
import 'package:health_gauge/ui/graph_screen/providers/graph_provider.dart';
import 'package:health_gauge/ui/graph_screen/providers/graph_provider_list.dart';
import 'package:health_gauge/ui/graph_screen/screens/default_graphs/bp_graph.dart';
import 'package:health_gauge/ui/graph_screen/screens/default_graphs/sleep_graph.dart';
import 'package:health_gauge/ui/graph_screen/screens/default_graphs/weight_graph.dart';
import 'package:health_gauge/utils/constants.dart';
import 'package:health_gauge/utils/gloabals.dart';
import 'package:health_gauge/value/app_color.dart';
import 'package:health_gauge/value/string_localization_support/string_localization.dart';
import 'package:health_gauge/widgets/text_utils.dart';
import 'package:provider/provider.dart';

import 'activity_graph.dart';
import 'hr_graph.dart';

class DefaultGraphs extends StatefulWidget {
  final DateTime selectedDate;
  final GraphTab graphTab;
  final WindowModel graphWindow;
  final List<GraphTypeModel> graphTypeList;
  final GraphSharedPreferenceManagerModel graphSharedPreferenceManagerModel;
  final int index;
  final int defaultGraphIndex;
  final GraphProviderList prov;

  DefaultGraphs({
    required this.selectedDate,
    required this.graphTab,
    required this.graphWindow,
    required this.graphTypeList,
    required this.graphSharedPreferenceManagerModel,
    required this.index,
    required this.defaultGraphIndex,
    required this.prov,
  });

  @override
  _DefaultGraphState createState() => _DefaultGraphState();
}

class _DefaultGraphState extends State<DefaultGraphs> {
  late GraphProviderList provider;
  late ChartType chartType;
  bool isInterpolationEnable = false;
  late GraphProvider model;

  @override
  void initState() {
    print('Default Graph');
    provider = widget.prov;
    model = provider.graphProviderList[widget.index];
    chartType = widget.graphWindow.selectedChartType;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<GraphProvider>.value(
        value: model,
        child: Container(
          decoration: BoxDecoration(
            color: Theme.of(context).brightness == Brightness.dark
                ? HexColor.fromHex('#111B1A')
                : AppColor.backgroundColor,
            borderRadius: BorderRadius.circular(10.h),
            boxShadow: [
              BoxShadow(
                color: Theme.of(context).brightness == Brightness.dark
                    ? HexColor.fromHex('#D1D9E6').withOpacity(0.07)
                    : Colors.white,
                blurRadius: 4,
                spreadRadius: 0,
                offset: Offset(-4, -4),
              ),
              BoxShadow(
                color: Theme.of(context).brightness == Brightness.dark
                    ? HexColor.fromHex('#000000').withOpacity(0.6)
                    : HexColor.fromHex('#9F2DBC').withOpacity(0.15),
                blurRadius: 4,
                spreadRadius: 0,
                offset: Offset(4, 4),
              ),
            ],
          ),
//        elevation: 4.0,
          margin: EdgeInsets.symmetric(horizontal: 13.w, vertical: 10.h),
          child: Stack(
            children: [
              widget.defaultGraphIndex == 0 && widget.graphTab != GraphTab.day
                  ? Align(
                      alignment: Alignment.topLeft,
                      child: InkWell(
                        onTap: () {
                          chartType = chartType == ChartType.line
                              ? ChartType.bar
                              : ChartType.line;
                          provider.graphProviderList[widget.index].graphWindow
                              ?.selectedChartType = chartType;
                          provider.graphProviderList[widget.index]
                              .updatePrefForSelectedItem();
                          if (mounted) setState(() {});
                        },
                        child: Padding(
                          padding: EdgeInsets.symmetric(
                              horizontal: 12.w, vertical: 8.h),
                          child: Icon(
                            widget.graphWindow.selectedChartType ==
                                    ChartType.line
                                ? Icons.insert_chart
                                : Icons.show_chart,
                            size: 25.h,
                            color: Theme.of(context).colorScheme.secondary,
                          ),
                        ),
                      ),
                    )
                  : Container(),
              Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  SizedBox(height: 10.h),
                  Flexible(
                    child: SizedBox(
                      height: 25.h,
                      child: Body1AutoText(
                        text: widget.graphWindow.title,
                        align: TextAlign.center,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? AppColor.white87
                            : AppColor.color384341,
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        maxLine: 1,
                        minFontSize: 12,
                      ),
                    ),
                  ),
                  Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 8.w, vertical: 8.h),
                    height: heightForGraph(),
                    width: MediaQuery.of(context).size.width,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        checkForLabel()
                            ? Padding(
                                padding: provider
                                                .graphProviderList[widget.index]
                                                .selectedGraphTypeList
                                                .first
                                                .fieldName ==
                                            'approxDBP' &&
                                        widget.graphTab == GraphTab.week
                                    ? EdgeInsets.only(left: 5)
                                    : EdgeInsets.only(left: 0),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: SizedBox(
                                        height: 22.h,
                                        child: AutoSizeText(
                                          fieldName(),
                                          textAlign: setTextAlign(),
                                          style: TextStyle(
                                              color: Theme.of(context)
                                                          .brightness ==
                                                      Brightness.dark
                                                  ? HexColor.fromHex('#FF9E99')
                                                  : HexColor.fromHex('#FF6259'),
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            : Container(),
                        Expanded(child: graphDataLayout()),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ));
  }

  double heightForGraph() {
    if (provider
            .graphProviderList[widget.index].selectedGraphTypeList.isNotEmpty &&
        provider.graphProviderList[widget.index].selectedGraphTypeList.length >
            1) {
      if (provider.graphProviderList[widget.index].selectedGraphTypeList.first
              .fieldName ==
          'approxHr') {
        return provider.graphProviderList[widget.index].selectedGraphTypeList[1]
                    .fieldName ==
                'step'
            ? 480.h
            : (widget.graphTab == GraphTab.week ||
                    widget.graphTab == GraphTab.month)
                ? widget.graphWindow.selectedChartType == ChartType.bar
                    ? 562.h
                    : 520.h
                : 410.h + 3;
      } else if (provider.graphProviderList[widget.index].selectedGraphTypeList
                  .first.fieldName ==
              'Oxygen' ||
          provider.graphProviderList[widget.index].selectedGraphTypeList.first
                  .fieldName ==
              'Temperature') {
        if (widget.graphTab == GraphTab.day) {
          return 410.h + 3;
        } else {
          return widget.graphWindow.selectedChartType == ChartType.bar
              ? 562.h
              : 520.h;
        }
      } else if (provider.graphProviderList[widget.index].selectedGraphTypeList
              .first.fieldName ==
          'WeightSum') {
        return 480.h;
      } else {
        return provider.graphProviderList[widget.index].selectedGraphTypeList
                        .first.fieldName ==
                    'approxSBP' &&
                widget.index == 1
            ? 445.h
            : 535.h;
      }
    }
    return 390.h;
  }

  String fieldName() {
    if (provider.graphProviderList[widget.index].selectedGraphTypeList.any(
        (element) => element.fieldName == DefaultGraphItem.weight.fieldName)) {
      if (UnitExtension.getUnitType(weightUnit) == UnitTypeEnum.imperial) {
        return '${stringLocalization.getText(StringLocalization.weight).toUpperCase()} (${stringLocalization.getText(StringLocalization.lb)})';
      } else {
        return '${stringLocalization.getText(StringLocalization.weight).toUpperCase()} (${stringLocalization.getText(StringLocalization.kg)})';
      }
    }
    var temp = tempUnit == 0 ? '(°C)' : '(°F)';
    return provider.graphProviderList[widget.index].selectedGraphTypeList.first
                .fieldName ==
            'approxHr'
        ? 'HR'
        : provider.graphProviderList[widget.index].selectedGraphTypeList.first
                    .fieldName ==
                'Oxygen'
            ? '${stringLocalization.getText(StringLocalization.oxygen).toUpperCase()}'
            : provider.graphProviderList[widget.index].selectedGraphTypeList
                        .first.fieldName ==
                    'WeightSum'
                ? 'WEIGHT'
                : provider.graphProviderList[widget.index].selectedGraphTypeList
                                .first.fieldName ==
                            'approxSBP' &&
                        widget.index == 1
                    ? 'BP'
                    : provider.graphProviderList[widget.index]
                                .selectedGraphTypeList.first.fieldName ==
                            'Temperature'
                        ? '${stringLocalization.getText(StringLocalization.bodyTemperature).toUpperCase()} $temp'
                        : 'SYS';
  }

  bool checkForLabel() {
    return (provider.graphProviderList[widget.index].selectedGraphTypeList
                .isNotEmpty &&
            provider.graphProviderList[widget.index].selectedGraphTypeList.any(
                (element) =>
                    element.fieldName == DefaultGraphItem.weight.fieldName)) ||
        (provider.graphProviderList[widget.index].selectedGraphTypeList.length >
                1 &&
            widget.graphWindow.defaultGraph);
  }

  TextAlign setTextAlign() {
    try {
      if (provider.graphProviderList[widget.index].selectedGraphTypeList
              .isNotEmpty &&
          provider.graphProviderList[widget.index].selectedGraphTypeList
                  .length >
              1) {
        if (provider
                .graphProviderList[widget.index].selectedGraphTypeList.length >
            1) {
          var index = provider
              .graphProviderList[widget.index].selectedGraphTypeList
              .indexWhere((element) =>
                  element.fieldName == DefaultGraphItem.weight.fieldName);
          if (index > -1 && index == 1) {
            return TextAlign.end;
          }
        }
      }
    } catch (e) {
      print('exception in graph window screen $e');
    }
    return TextAlign.start;
  }

  Widget graphDataLayout() {
    return ValueListenableBuilder(
        valueListenable: widget.graphWindow.onChangeDate,
        builder: (context, DateTime? selectedDate, child) {
          if (selectedDate != null) {
            provider.graphProviderList[widget.index].isShowLoadingScreen = true;
            provider.graphProviderList[widget.index].setDates(selectedDate);
           widget.graphWindow.onChangeDate.value = null;
          }else{
            // provider.graphProviderList[widget.index].setDates(DateTime(
            //     DateTime.now().year,
            //     DateTime.now().month,
            //     DateTime.now().day,
            //     0,
            //     0,
            //     0,
            //     0,
            //     0));
          }
          switch (widget.defaultGraphIndex) {
            case 0:
              {
                dynamic sleepGraph = SleepGraph(
                    selectedDate: widget.selectedDate,
                    graphTab: widget.graphTab,
                    graphWindow: widget.graphWindow,
                    startDate:
                        provider.graphProviderList[widget.index].startDate,
                    endDate: provider.graphProviderList[widget.index].endDate,
                    graphTypeList: widget.graphTypeList,
                    index: widget.index,
                    chartType: chartType,
                    selectedGraphTypeList: provider
                        .graphProviderList[widget.index].selectedGraphTypeList,
                    prov: provider);
                return sleepGraph;
              }
            case 1:
              {
                dynamic weightGraph = WeightGraph(
                    selectedDate: widget.selectedDate,
                    startDate:
                        provider.graphProviderList[widget.index].startDate,
                    endDate: provider.graphProviderList[widget.index].endDate,
                    graphTab: widget.graphTab,
                    graphTypeList: widget.graphTypeList,
                    index: widget.index,
                    prov: provider,
                    selectedGraphTypeList: provider
                        .graphProviderList[widget.index].selectedGraphTypeList);
                return weightGraph;
              }
            case 2:
              {
                dynamic hrGraph = HrGraph(
                    selectedDate: widget.selectedDate,
                    startDate:
                        provider.graphProviderList[widget.index].startDate,
                    endDate: provider.graphProviderList[widget.index].endDate,
                    graphTab: widget.graphTab,
                    graphTypeList: widget.graphTypeList,
                    index: widget.index,
                    prov: provider,
                    selectedGraphTypeList: provider
                        .graphProviderList[widget.index].selectedGraphTypeList);
                return hrGraph;
              }
            case 3:
              {
                dynamic activityGraph = ActivityGraph(
                    selectedDate: widget.selectedDate,
                    startDate:
                        provider.graphProviderList[widget.index].startDate,
                    endDate: provider.graphProviderList[widget.index].endDate,
                    graphTab: widget.graphTab,
                    graphTypeList: widget.graphTypeList,
                    index: widget.index,
                    prov: provider,
                    selectedGraphTypeList: provider
                        .graphProviderList[widget.index].selectedGraphTypeList);
                return activityGraph;
              }
            case 4:
              {
                dynamic bpGraph = BPGraph(
                    selectedDate: widget.selectedDate,
                    startDate:
                        provider.graphProviderList[widget.index].startDate,
                    endDate: provider.graphProviderList[widget.index].endDate,
                    graphTab: widget.graphTab,
                    graphTypeList: widget.graphTypeList,
                    index: widget.index,
                    prov: provider,
                    bpGraphType: widget.index == 1 ? 2 : 1,
                    selectedGraphTypeList: provider
                        .graphProviderList[widget.index].selectedGraphTypeList);
                return bpGraph;
              }
            default:
              return Container();
          }
        });
  }
}
