import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:health_gauge/screens/MeasurementHistory/m_history_helper.dart';
import 'package:health_gauge/ui/graph_screen/manager/graph_item_enum.dart';
import 'package:health_gauge/ui/graph_screen/manager/graph_shared_preference_manager_model.dart';
import 'package:health_gauge/ui/graph_screen/manager/graph_type_model.dart';
import 'package:health_gauge/ui/graph_screen/providers/graph_provider.dart';
import 'package:health_gauge/ui/graph_screen/providers/graph_provider_list.dart';
import 'package:health_gauge/utils/db_table_helper.dart';
import 'package:health_gauge/utils/constants.dart';
import 'package:health_gauge/utils/date_picker.dart';
import 'package:health_gauge/utils/date_utils.dart';
import 'package:health_gauge/utils/gloabals.dart';
import 'package:health_gauge/value/app_color.dart';
import 'package:health_gauge/value/string_localization_support/string_localization.dart';
import 'package:health_gauge/widgets/custom_floating_action_button.dart';
import 'package:health_gauge/widgets/day_week_month_tab.dart';
import 'package:health_gauge/widgets/text_utils.dart';
import 'package:intl/intl.dart';
import 'package:scroll_to_index/scroll_to_index.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'custom_graphs/custom_graphs.dart';
import 'default_graphs/default_graph.dart';

//ValueNotifier<DateTime> onChangeDate = new ValueNotifier(null);

class GraphListPage extends StatefulWidget {
  final GraphSharedPreferenceManagerModel graphSharedPreferenceManagerModel;
  final List<GraphTypeModel> graphTypeList;

  GraphListPage(
      {required this.graphSharedPreferenceManagerModel,
      required this.graphTypeList});

  @override
  _GraphListPageState createState() =>
      _GraphListPageState(graphSharedPreferenceManagerModel, graphTypeList);
}

class _GraphListPageState extends State<GraphListPage>
    with AutomaticKeepAliveClientMixin {
  bool isShowLoadingScreen = true;

  PageController pageViewDayWeekMonthController =
      PageController(initialPage: 0);
  TextEditingController titleController = TextEditingController();

  bool showRemoveIcon = false;
  late AutoScrollController controller;
  final scrollDirection = Axis.vertical;

  int currentIndex = 0;
  DateTime selectedDate = DateTime.now();
  DateTime firstDateOfWeek = DateTime.now();
  DateTime lastDateOfWeek = DateTime.now();

  GraphSharedPreferenceManagerModel graphSharedPreferenceManagerModel;

  List<GraphTypeModel> graphTypeList = [];

  bool isGraphDeleted = false;

  _GraphListPageState(
      this.graphSharedPreferenceManagerModel, this.graphTypeList);

  late GraphProviderList provider;

  @override
  void initState() {
    selectWeek(selectedDate);
    super.initState();
    controller = AutoScrollController(
        viewportBoundaryGetter: () =>
            Rect.fromLTRB(0, 0, 0, MediaQuery.of(context).padding.bottom),
        axis: scrollDirection);
    provider = GraphProviderList();

    for (var element2 in widget.graphSharedPreferenceManagerModel.windowList) {
      element2?.isChange.value = true;
    }
  }

  @override
  Widget build(BuildContext context) {
    // ScreenUtil.init(context, width: 375.0, height: 812.0, allowFontScaling: true);
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Theme.of(context).brightness == Brightness.dark
          ? HexColor.fromHex('#111B1A')
          : HexColor.fromHex('#EEF1F1'),
      body: layout(),
      floatingActionButton: !widget.graphSharedPreferenceManagerModel.isDefault
          ? CustomFloatingActionButton(
              onTap: () {
                addWindow(titleController.text);
                scrollToItem();
              },
            )
          : Container(),
    );
  }

  Future<void> refreshBPData() async {
    print(
        'refreshBPData :: ${provider.graphProviderList.map((e) => e.selectedGraphTypeList)}');
    Future.delayed(Duration(milliseconds: 1000), () async {
      var tableName = provider
              .graphProviderList[0]
              .graphSharedPreferenceManagerModel
              ?.windowList
              .first
              ?.selectedType
              .first
              .tableName ??
          '';
      if (tableName == DBTableHelper().m.table) {
        var startDate = provider.graphProviderList[0].startDate;
        var endDate = provider.graphProviderList[0].endDate;
        await MHistoryHelper().fetchDay(
          startDate: startDate.millisecondsSinceEpoch,
          endDate: endDate.millisecondsSinceEpoch,
          pageSize: 500,
        );
        if (mounted) {
          setState(() {});
        }
      }
    });
  }

  Widget layout() {
    return Container(
      color: Theme.of(context).brightness == Brightness.dark
          ? HexColor.fromHex('#111B1A')
          : HexColor.fromHex('#EEF1F1'),
      child: Column(
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              DayWeekMonthTab(
                currentIndex: currentIndex,
                onTapDay: () async {
                  currentIndex = 0;
                  pageViewDayWeekMonthController.animateToPage(0,
                      duration: Duration(milliseconds: 200),
                      curve: Curves.linear);

                  // refreshData();
                  if (mounted) {
                    setState(() {});
                  }
                  refreshBPData();
                  for (var element2
                      in widget.graphSharedPreferenceManagerModel.windowList) {
                    element2?.isChange.value = true;
                    element2?.onChangeDate.value = selectedDate;
                  }
//                  scrollToItem(scrollIndex: _currentItem);
                },
                onTapWeek: () async {
                  currentIndex = 1;
                  pageViewDayWeekMonthController.animateToPage(1,
                      duration: Duration(milliseconds: 200),
                      curve: Curves.linear);
                  // refreshData();
                  // scrollToGraph();
                  if (mounted) {
                    setState(() {});
                  }
                  refreshBPData();
                  for (var element2
                      in widget.graphSharedPreferenceManagerModel.windowList) {
                    element2?.isChange.value = true;
                    element2?.onChangeDate.value = selectedDate;
                  }
//                  scrollToItem(scrollIndex: _currentItem);
                },
                onTapMonth: () async {
                  var currentTime = DateTime.now();
                  if (selectedDate.year == currentTime.year &&
                      selectedDate.month - currentTime.month > 0) {
                    selectedDate = currentTime;
                  }
                  currentIndex = 2;
                  pageViewDayWeekMonthController.animateToPage(2,
                      duration: Duration(milliseconds: 200),
                      curve: Curves.linear);
                  // refreshData();
                  if (mounted) {
                    setState(() {});
                  }
                  refreshBPData();
                  for (var element2
                      in widget.graphSharedPreferenceManagerModel.windowList) {
                    element2?.isChange.value = true;
                    element2?.onChangeDate.value = selectedDate;
                  }
//                  scrollToItem(scrollIndex: _currentItem);
                },
                date: selectedValueText(),
                onTapPreviousDate: onClickBefore,
                onTapNextDate: () {
                  bool isEnable = true;
                  if (currentIndex == 0 &&
                      selectedDate.difference(DateTime.now()).inDays == 0) {
                    isEnable = false;
                  }
                  if (currentIndex == 1 &&
                      lastDateOfWeek.difference(DateTime.now()).inDays >= 0) {
                    isEnable = false;
                  }
                  if (currentIndex == 2 &&
                      (selectedDate.difference(DateTime.now()).inDays >= 0 ||
                          (selectedDate.year == DateTime.now().year &&
                              selectedDate.month == DateTime.now().month))) {
                    isEnable = false;
                  }
                  if (isEnable) onClickNext();

                  for (var element2
                      in widget.graphSharedPreferenceManagerModel.windowList) {
                    element2?.isChange.value = true;
                    element2?.onChangeDate.value = selectedDate;
                    // element2?.onChangeDate.value = selectedDate;
                  }
                },
                onTapCalendar: () async {
                  selectedDate = await Date(
                          getDatabaseDataFrom:
                              graphSharedPreferenceManagerModel.isDefault
                                  ? graphSharedPreferenceManagerModel.title
                                  : '')
                      .selectDate(context, selectedDate);
                  selectWeek(selectedDate);
                  refreshData();
                  for (var element2
                      in widget.graphSharedPreferenceManagerModel.windowList) {
                    element2?.isChange.value = true;
                    element2?.onChangeDate.value = selectedDate;
                  }
                  if (mounted) {
                    setState(() {});
                  }
                },
              ),
            ],
          ),
          Expanded(
              child: PageView.builder(
            controller: pageViewDayWeekMonthController,
            itemCount: 3,
            itemBuilder: (context, index) {
              return listOfWindowsWidget(index);
            },
            physics: NeverScrollableScrollPhysics(),
            onPageChanged: (page) async {},
          )),
        ],
      ),
    );
  }

  Widget listOfWindowsWidget(int tabIndex) {
    provider.graphProviderList = [];
    print(
        'graphItems :: ${graphSharedPreferenceManagerModel.windowList.map((e) => e!.selectedType)}');

    for (var item in graphSharedPreferenceManagerModel.windowList) {
      var tempModel =
          graphSharedPreferenceManagerModel.windowList.first?.selectedType ??
              [];
      var tempProvider = GraphProvider();
      tempProvider.graphWindow = item;
      tempProvider.graphTypeList = graphTypeList;
      tempProvider.selectedGraphTypeList = item?.selectedType ?? [];
      tempProvider.graphSharedPreferenceManagerModel =
          graphSharedPreferenceManagerModel;
      tempProvider.isShowLoadingScreen = true;
      tempProvider.graphTab = getGraphTypeFromDay(tabIndex);
      tempProvider.isEditMode = false;
      tempProvider.setDates(selectedDate);
      tempProvider.getPreference();
      tempProvider.getGraphTitle();
      if (item != null && item.defaultGraph) {
        tempProvider.getData(context: context);
      }
      provider.graphProviderList.add(tempProvider);
    }

    return ListView.builder(
      scrollDirection: scrollDirection,
      controller: controller,
      shrinkWrap: true,
      itemCount: itemCountOfWindowList(),
      padding: EdgeInsets.only(bottom: kToolbarHeight),
      itemBuilder: (context, index) {
        WindowModel? model;
        try {
          model = graphSharedPreferenceManagerModel.windowList.elementAt(index);
        } on Exception catch (e) {
          print(e);
        }
        if (model == null) {
          return Container();
        }
        print("model.defaultGraph ${model.defaultGraph.toString()}");

        return AutoScrollTag(
          key: ValueKey(index),
          index: index,
          controller: controller,
          child: Stack(
            children: [
              model.defaultGraph
                  ? DefaultGraphs(
                      defaultGraphIndex:
                          graphSharedPreferenceManagerModel.index,
                      index: index,
                      selectedDate: selectedDate,
                      graphTab: getGraphTypeFromDay(tabIndex),
                      graphWindow: model,
                      graphTypeList: graphTypeList,
                      graphSharedPreferenceManagerModel:
                          graphSharedPreferenceManagerModel,
                      prov: provider,
                    )
                  : CustomGraphs(
                      currentIndex: currentIndex,
                      index: index,
                      selectedDates: selectedDate,
                      graphTab: getGraphTypeFromDay(tabIndex),
                      graphWindow: model,
                      graphTypeList: graphTypeList,
                      graphSharedPreferenceManagerModel:
                          graphSharedPreferenceManagerModel,
                      onClickRemove: () async {
                        isGraphDeleted = true;
                        graphSharedPreferenceManagerModel.windowList[index] =
                            null;
                        provider.graphProviderList.removeAt(index);
                        await updateWindowListInPreference(deletedIndex: index);
                        setState(() {});
                      },
                      prov: provider,
                    ),
            ],
          ),
        );
      },
    );

    // return ListView(
    //   scrollDirection: scrollDirection,
    //   controller: controller,
    //   shrinkWrap: true,
    //   padding: EdgeInsets.only(bottom: kToolbarHeight),
    //   children: List.generate(itemCountOfWindowList(), (index){
    //     return getListItemWidget(index, tabIndex);
    //   }),
    // );
  }

  Widget getListItemWidget(int index, int tabIndex) {
    WindowModel? model;
    try {
      model = graphSharedPreferenceManagerModel.windowList.elementAt(index);
      print("Datatatatata ${model?.onChangeDate.value.toString()}");
      if (model?.onChangeDate.value == null) {
        print("Datatatatata if${model?.onChangeDate.value.toString()}");
      }
    } on Exception catch (e) {
      print(e);
    }
    if (model == null) {
      return Container();
    }
    print("model.defaultGraph.toString() ${model.defaultGraph.toString()}");
    return AutoScrollTag(
      key: ValueKey(index),
      index: index,
      controller: controller,
      child: Stack(
        children: [

          model.defaultGraph
              ? DefaultGraphs(
                  defaultGraphIndex: graphSharedPreferenceManagerModel.index,
                  index: index,
                  selectedDate: selectedDate,
                  graphTab: getGraphTypeFromDay(tabIndex),
                  graphWindow: model,
                  graphTypeList: graphTypeList,
                  graphSharedPreferenceManagerModel:
                      graphSharedPreferenceManagerModel,
                  prov: provider,
                )
              : CustomGraphs(
                  currentIndex: currentIndex,
                  index: index,
                  selectedDates: selectedDate,
                  graphTab: getGraphTypeFromDay(tabIndex),
                  graphWindow: model,
                  graphTypeList: graphTypeList,
                  graphSharedPreferenceManagerModel:
                      graphSharedPreferenceManagerModel,
                  onClickRemove: () async {
                    isGraphDeleted = true;
                    graphSharedPreferenceManagerModel.windowList[index] = null;
                    provider.graphProviderList.removeAt(index);
                    // graphSharedPreferenceManagerModel.windowList.removeAt(index);
                    await updateWindowListInPreference(deletedIndex: index);
                    setState(() {});
                  },
                  prov: provider,
                ),
        ],
      ),
    );
  }

  getGraphTypeFromDay(int tabIndex) {
    switch (tabIndex) {
      case 0:
        return GraphTab.day;
      case 1:
        return GraphTab.week;
      case 2:
        return GraphTab.month;
    }
  }

  int itemCountOfWindowList() {
    if (graphSharedPreferenceManagerModel != null &&
        graphSharedPreferenceManagerModel.windowList != null) {
      print(
          'print index ${graphSharedPreferenceManagerModel.windowList.length}');
      return graphSharedPreferenceManagerModel.windowList.length;
    }
    return 0;
  }

  Widget tabLayout() {
    return Container(
      height: 35.h,
      margin: EdgeInsets.only(left: 33.w, right: 33.w, top: 21.h),
      decoration: BoxDecoration(
          color: Theme.of(context).brightness == Brightness.dark
              ? Colors.black
              : Colors.white,
          boxShadow: [
            BoxShadow(
              color: Theme.of(context).brightness == Brightness.dark
                  ? HexColor.fromHex('#FF9E99').withOpacity(0.8)
                  : HexColor.fromHex('#9F2DBC').withOpacity(0.8),
              spreadRadius: 0.5,
              blurRadius: 3,
              offset: Offset(0, 0),
            ),
            BoxShadow(
              color: Theme.of(context).brightness == Brightness.dark
                  ? HexColor.fromHex('#000000').withOpacity(0.25)
                  : HexColor.fromHex('#00AFAA').withOpacity(0.05),
              spreadRadius: 5,
              blurRadius: 6,
              offset: Offset(10, 10),
            ),
          ],
          borderRadius: BorderRadius.all(Radius.circular(40.h))),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Expanded(
            child: InkWell(
              child: Container(
                height: 35.h,
//                padding:
//                    EdgeInsets.symmetric(vertical: 10.h, horizontal: 10.h),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(40.h),
                    topLeft: Radius.circular(40.h),
                  ),
                  gradient: currentIndex == 0
                      ? LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Theme.of(context).brightness == Brightness.dark
                                ? HexColor.fromHex('#FF9E99')
                                : HexColor.fromHex('#FF6259'),
                            Theme.of(context).brightness == Brightness.dark
                                ? HexColor.fromHex('#FF9E99')
                                : HexColor.fromHex('#FF6259'),
                            Theme.of(context).brightness == Brightness.dark
                                ? HexColor.fromHex('#FF9E99')
                                : HexColor.fromHex('#FF6259'),
                          ],
                        )
                      : LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                              Theme.of(context).brightness == Brightness.dark
                                  ? HexColor.fromHex('#111B1A')
                                      .withOpacity(0.05)
                                  : HexColor.fromHex('#FFDFDE')
                                      .withOpacity(0.2),
                              Theme.of(context).brightness == Brightness.dark
                                  ? HexColor.fromHex('#111B1A')
                                  : HexColor.fromHex('#FFDFDE')
                                      .withOpacity(0.7),
                              Theme.of(context).brightness == Brightness.dark
                                  ? HexColor.fromHex('#111B1A')
                                  : HexColor.fromHex('#FFDFDE')
                                      .withOpacity(0.7),
                              Theme.of(context).brightness == Brightness.dark
                                  ? HexColor.fromHex('#111B1A')
                                  : HexColor.fromHex('#FFDFDE')
                                      .withOpacity(0.2),
                            ]),
                ),
                child: Center(
                  child: Body1AutoText(
                    text: StringLocalization.of(context)
                        .getText(StringLocalization.day),
                    color: currentIndex == 0
                        ? Theme.of(context).brightness == Brightness.dark
                            ? HexColor.fromHex('#111B1A')
                            : Colors.white
                        : Theme.of(context).brightness == Brightness.dark
                            ? HexColor.fromHex('#FF9E99')
                            : HexColor.fromHex('#FF6259'),
                    align: TextAlign.center,
                    fontWeight: FontWeight.bold,
                    fontSize: 16.sp,
                  ),
                ),
              ),
              onTap: () async {
                currentIndex = 0;
                pageViewDayWeekMonthController.animateToPage(0,
                    duration: Duration(milliseconds: 200),
                    curve: Curves.linear);
                refreshData();
                if (mounted) {
                  setState(() {});
                }
//                  scrollToItem(scrollIndex: _currentItem);
              },
            ),
          ),
          currentIndex == 2
              ? Container(
                  width: 2.w,
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.black54
                      : Colors.white,
                )
              : Container(),
          Expanded(
            child: InkWell(
              child: Container(
                  height: 35.h,
                  decoration: BoxDecoration(
                    gradient: currentIndex == 1
                        ? LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Theme.of(context).brightness == Brightness.dark
                                  ? HexColor.fromHex('#FF9E99')
                                  : HexColor.fromHex('#FF6259'),
                              Theme.of(context).brightness == Brightness.dark
                                  ? HexColor.fromHex('#FF9E99')
                                  : HexColor.fromHex('#FF6259'),
                              Theme.of(context).brightness == Brightness.dark
                                  ? HexColor.fromHex('#FF9E99')
                                  : HexColor.fromHex('#FF6259'),
                            ],
                          )
                        : LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                                Theme.of(context).brightness == Brightness.dark
                                    ? HexColor.fromHex('#111B1A')
                                        .withOpacity(0.05)
                                    : HexColor.fromHex('#FFDFDE')
                                        .withOpacity(0.2),
                                Theme.of(context).brightness == Brightness.dark
                                    ? HexColor.fromHex('#111B1A')
                                    : HexColor.fromHex('#FFDFDE')
                                        .withOpacity(0.7),
                                Theme.of(context).brightness == Brightness.dark
                                    ? HexColor.fromHex('#111B1A')
                                    : HexColor.fromHex('#FFDFDE')
                                        .withOpacity(0.7),
                                Theme.of(context).brightness == Brightness.dark
                                    ? HexColor.fromHex('#111B1A')
                                    : HexColor.fromHex('#FFDFDE')
                                        .withOpacity(0.2),
                              ]),
                  ),
                  child: Center(
                    child: Body1AutoText(
                      text: StringLocalization.of(context)
                          .getText(StringLocalization.week),
                      color: currentIndex == 1
                          ? Theme.of(context).brightness == Brightness.dark
                              ? HexColor.fromHex('#111B1A')
                              : Colors.white
                          : Theme.of(context).brightness == Brightness.dark
                              ? HexColor.fromHex('#FF9E99')
                              : HexColor.fromHex('#FF6259'),
                      align: TextAlign.center,
                      fontWeight: FontWeight.bold,
                      fontSize: 16.sp,
                    ),
                  )),
              onTap: () async {
                currentIndex = 1;
                pageViewDayWeekMonthController.animateToPage(1,
                    duration: Duration(milliseconds: 200),
                    curve: Curves.linear);
                refreshData();
                // scrollToGraph();
                if (mounted) {
                  setState(() {});
                }
//                  scrollToItem(scrollIndex: _currentItem);
              },
            ),
          ),
          currentIndex == 0
              ? Container(
                  width: 2.w,
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.black54
                      : Colors.white,
                )
              : Container(),
          Expanded(
            child: InkWell(
              child: Container(
                  height: 35.h,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(40.h),
                      topRight: Radius.circular(40.h),
                    ),
                    gradient: currentIndex == 2
                        ? LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Theme.of(context).brightness == Brightness.dark
                                  ? HexColor.fromHex('#FF9E99')
                                  : HexColor.fromHex('#FF6259'),
                              Theme.of(context).brightness == Brightness.dark
                                  ? HexColor.fromHex('#FF9E99')
                                  : HexColor.fromHex('#FF6259'),
                              Theme.of(context).brightness == Brightness.dark
                                  ? HexColor.fromHex('#FF9E99')
                                  : HexColor.fromHex('#FF6259'),
                            ],
                          )
                        : LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                                Theme.of(context).brightness == Brightness.dark
                                    ? HexColor.fromHex('#111B1A')
                                        .withOpacity(0.05)
                                    : HexColor.fromHex('#FFDFDE')
                                        .withOpacity(0.2),
                                Theme.of(context).brightness == Brightness.dark
                                    ? HexColor.fromHex('#111B1A')
                                    : HexColor.fromHex('#FFDFDE')
                                        .withOpacity(0.7),
                                Theme.of(context).brightness == Brightness.dark
                                    ? HexColor.fromHex('#111B1A')
                                    : HexColor.fromHex('#FFDFDE')
                                        .withOpacity(0.7),
                                Theme.of(context).brightness == Brightness.dark
                                    ? HexColor.fromHex('#111B1A')
                                    : HexColor.fromHex('#FFDFDE')
                                        .withOpacity(0.2),
                              ]),
                  ),
                  child: Center(
                    child: Body1AutoText(
                      text: StringLocalization.of(context)
                          .getText(StringLocalization.month),
                      color: currentIndex == 2
                          ? Theme.of(context).brightness == Brightness.dark
                              ? HexColor.fromHex('#111B1A')
                              : Colors.white
                          : Theme.of(context).brightness == Brightness.dark
                              ? HexColor.fromHex('#FF9E99')
                              : HexColor.fromHex('#FF6259'),
                      align: TextAlign.center,
                      fontWeight: FontWeight.bold,
                      fontSize: 16.sp,
                    ),
                  )),
              onTap: () async {
                currentIndex = 2;
                pageViewDayWeekMonthController.animateToPage(2,
                    duration: Duration(milliseconds: 200),
                    curve: Curves.linear);
                refreshData();
                if (mounted) {
                  setState(() {});
                }
//                  scrollToItem(scrollIndex: _currentItem);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget dateChooserLayout() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        IconButton(
          icon: Image.asset(Theme.of(context).brightness == Brightness.dark
              ? 'asset/dark_left.png'
              : 'asset/left.png'),
          onPressed: onClickBefore,
        ),
        Container(
          width: currentIndex == 1
              ? 200.w
              : currentIndex == 0
                  ? 80.w
                  : 120.w,
          child: Center(
              child: Body1AutoText(
            text: selectedValueText(),
            minFontSize: 8,
            fontSize: 16.sp,
          )),
        ),
        nextBtn(),
        InkWell(
          child: Image.asset(
            Theme.of(context).brightness == Brightness.dark
                ? 'asset/dark_calendar_icon.png'
                : 'asset/calendar_icon.png',
          ),
          onTap: () async {
            selectedDate = await Date().selectDate(context, selectedDate);
            selectWeek(selectedDate);
            refreshData();
            if (mounted) {
              setState(() {});
            }
          },
        ),
      ],
    );
  }

  IconButton nextBtn() {
    bool isEnable = true;
    if (currentIndex == 0 &&
        selectedDate.difference(DateTime.now()).inDays == 0) {
      isEnable = false;
    }
    if (currentIndex == 1 &&
        selectedDate.difference(DateTime.now()).inDays == 0) {
      isEnable = false;
    }
    if (currentIndex == 2 &&
        selectedDate.difference(DateTime.now()).inDays == 0) {
      isEnable = false;
    }
    return IconButton(
      icon: Image.asset(Theme.of(context).brightness == Brightness.dark
          ? 'asset/dark_right.png'
          : 'asset/right.png'),
      onPressed: isEnable ? onClickNext : null,
    );
  }

  onClickNext() async {
    switch (currentIndex) {
      case 0:
        selectedDate = DateTime(
            selectedDate.year, selectedDate.month, selectedDate.day + 1);
        break;
      case 1:
        selectedDate = DateTime(
            selectedDate.year, selectedDate.month, selectedDate.day + 7);

        break;
      case 2:
        selectedDate = DateTime(
            selectedDate.year, selectedDate.month + 1, selectedDate.day);
        break;
    }
    selectWeek(selectedDate);
    refreshData();
    if (mounted) {
      setState(() {});
    }
    refreshBPData();
  }

  onClickBefore() async {
    switch (currentIndex) {
      case 0:
        selectedDate = DateTime(
            selectedDate.year, selectedDate.month, selectedDate.day - 1);
        break;
      case 1:
        selectedDate = DateTime(
            selectedDate.year, selectedDate.month, selectedDate.day - 7);
        break;
      case 2:
        selectedDate = DateTime(selectedDate.year, selectedDate.month - 1, 1);
        break;
    }
    selectWeek(selectedDate);
    refreshData();
    if (mounted) {
      setState(() {});
    }
    refreshBPData();
  }

  selectWeek(DateTime selectedDate) {
    var dayNr = (selectedDate.weekday + 7) % 7 - 1;
    firstDateOfWeek = selectedDate.subtract(Duration(days: (dayNr)));
    lastDateOfWeek = firstDateOfWeek.add(Duration(days: 6));
  }

  selectedValueText() {
    if (currentIndex == 0) {
      return txtSelectedDate();
    } else if (currentIndex == 1) {
      var first = DateFormat(DateUtil.ddMMyyyy).format(firstDateOfWeek);
      var last = DateFormat(DateUtil.ddMMyyyy).format(lastDateOfWeek);
      return '$first   to   $last';
    } else if (currentIndex == 2) {
      var date = DateFormat(DateUtil.MMMMyyyy).format(selectedDate);
      var year = date.split(' ')[1];
      date = '${Date().getSelectedMonthLocalization(date)} $year';
      return '$date';
    }
  }

  String txtSelectedDate() {
    var title = DateFormat(DateUtil.ddMMyyyyDashed).format(selectedDate);

    var now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = DateTime(now.year, now.month, now.day - 1);
    final tomorrow = DateTime(now.year, now.month, now.day + 1);
    final selected =
        DateTime(selectedDate.year, selectedDate.month, selectedDate.day);

    if (selected == today) {
      title = StringLocalization.of(context).getText(StringLocalization.today);
    } else if (selected == yesterday) {
      title =
          StringLocalization.of(context).getText(StringLocalization.yesterday);
    } else if (selected == tomorrow) {
      title =
          StringLocalization.of(context).getText(StringLocalization.tomorrow);
    }
    return '$title';
  }

  refreshData() {
//    onChangeDate.value = selectedDate;
    graphSharedPreferenceManagerModel.windowList.forEach((element) {
      print("selectedDate::: ${selectedDate.toString()}");
      element?.onChangeDate.value = selectedDate;
    });

    //scrollToItem(scrollIndex: _currentItem);
  }

  addWindow(String title) {
    WindowModel windowModel = getDefaultWindowTemplate();
    windowModel.title = title;
    if (graphSharedPreferenceManagerModel.windowList.isEmpty ||
        graphSharedPreferenceManagerModel.windowList.last == null ||
        graphSharedPreferenceManagerModel
            .windowList.last!.selectedType.isNotEmpty) {
      graphSharedPreferenceManagerModel.windowList.add(windowModel);
      updateWindowListInPreference();
    }
    if (mounted) {
      setState(() {});
    }
  }

  updateWindowListInPreference({int? deletedIndex}) async {
    preferences ??= await SharedPreferences.getInstance();
    var list = preferences!.getStringList(Constants.prefKeyForGraphPages) ?? [];
    var graphList = list
        .map((e) => GraphSharedPreferenceManagerModel.fromMap(jsonDecode(e)))
        .toList();
    if (graphList.isNotEmpty) {
      var index = graphList.lastIndexWhere((element) =>
          element.index == widget.graphSharedPreferenceManagerModel.index);
      if (index > -1) {
        graphList[index].windowList =
            graphSharedPreferenceManagerModel.windowList;
        var lst = graphList[index].windowList;
        graphList[index].windowList = [];
        var list = <WindowModel?>[];
        var j = 0;
        for (var i = 0; i < lst.length; i++) {
          if (lst[i] != null) {
            lst[i]!.index = j;
            list.add(lst[i]);
            j++;
          }
        }
        // if(deletedIndex != null) {
        //   for (var i = 0; i < list.length; i++) {
        //       list[i]?.index = i;
        //   }
        // }
        graphList[index].windowList.addAll(list);
      }
    }
    var storeList = graphList.map((e) => jsonEncode(e.toMap())).toList();
    preferences!.setStringList(Constants.prefKeyForGraphPages, storeList);
  }

  getDefaultWindowTemplate() {
    var index = 0;
    if (graphSharedPreferenceManagerModel != null &&
        graphSharedPreferenceManagerModel.windowList != null) {
      if (isGraphDeleted) {
        var graphDeleteCount = 0;
        for (var i = 0;
            i < graphSharedPreferenceManagerModel.windowList.length;
            i++) {
          if (graphSharedPreferenceManagerModel.windowList[i] == null) {
            graphDeleteCount++;
          }
        }
        index = graphSharedPreferenceManagerModel.windowList.length -
            graphDeleteCount;
      } else {
        index = graphSharedPreferenceManagerModel.windowList.length;
        isGraphDeleted = false;
      }
    }
    return WindowModel(
      // onChangeDate:ValueNotifier<DateTime?>(DateTime(
      //     DateTime.now().year,
      //     DateTime.now().month,
      //     DateTime.now().day,
      //     0,
      //     0,
      //     0,
      //     0,
      //     0)),
      index: index,
      title: '',
      selectedChartType: ChartType.bar,
      selectedType: [],
      normalization: false,
      editMode: true,
      defaultGraph: false,
      interpolation: false,
    );
  }

  Future scrollToItem({int? scrollIndex}) async {
    var index = graphSharedPreferenceManagerModel.windowList.length - 1;
    await controller.scrollToIndex(scrollIndex ?? index,
        preferPosition: AutoScrollPosition.begin);
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;
//  Future scrollToGraph() async {
//    int index = _currentItem;
//    await controller.scrollToIndex(index,
//        preferPosition: AutoScrollPosition.begin);
//  }
}
