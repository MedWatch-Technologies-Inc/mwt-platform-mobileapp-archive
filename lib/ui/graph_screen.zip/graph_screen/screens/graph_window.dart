import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;

import 'package:auto_size_text/auto_size_text.dart';
import 'package:charts_flutter/flutter.dart' as chart;
import 'package:flutter/material.dart';
import 'package:flutter/material.dart' as material;
import 'package:flutter/services.dart';
import 'package:flutter_material_color_picker/flutter_material_color_picker.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:health_gauge/models/infoModels/sleep_info_model.dart';
import 'package:health_gauge/models/measurement/measurement_history_model.dart';
import 'package:health_gauge/models/weight_measurement_model.dart';
import 'package:health_gauge/ui/graph_screen/manager/graph_item_enum.dart';
import 'package:health_gauge/ui/graph_screen/manager/graph_manager.dart';
import 'package:health_gauge/ui/graph_screen/manager/graph_shared_preference_manager_model.dart';
import 'package:health_gauge/ui/graph_screen/manager/graph_type_model.dart';
import 'package:health_gauge/utils/concave_decoration.dart';
import 'package:health_gauge/utils/constants.dart';
import 'package:health_gauge/utils/date_picker.dart';
import 'package:health_gauge/utils/date_utils.dart';
import 'package:health_gauge/utils/gloabals.dart';
import 'package:health_gauge/value/app_color.dart';
import 'package:health_gauge/value/string_localization_support/string_localization.dart';
import 'package:health_gauge/widgets/buttons.dart';
import 'package:health_gauge/widgets/custom_dialog.dart';
import 'package:health_gauge/widgets/custom_snackbar.dart';
import 'package:health_gauge/widgets/custom_switch.dart';
import 'package:health_gauge/widgets/text_utils.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../graph_item_data.dart';
import 'choose_graph_items.dart';

class GraphWindow extends StatefulWidget {
  final DateTime selectedDate;
  final GraphTab graphTab;
  final WindowModel graphWindow;
  final List<GraphTypeModel> graphTypeList;
  final GraphSharedPreferenceManagerModel graphSharedPreferenceManagerModel;
  final int index;
  final GestureTapCallback onClickRemove;

  GraphWindow(
      {required this.selectedDate,
      required this.graphTab,
      required this.graphWindow,
      required this.graphTypeList,
      required this.graphSharedPreferenceManagerModel,
      required this.index,
      required this.onClickRemove});

  @override
  GraphWindowState createState() =>
      GraphWindowState(selectedDate, graphWindow, graphTab, graphTypeList);
}

class GraphWindowState extends State<GraphWindow> {
  bool isShowLoadingScreen = true;

  late String userId;

  late DateTime startDate;
  late DateTime endDate;

  GraphTab graphTab;
  TextEditingController titleController = TextEditingController();
  late WindowModel graphWindow;

  List<GraphTypeModel> graphTypeList = [];
  List<GraphTypeModel> selectedGraphTypeList = [];
  List sleepList = [];
  List<GraphItemData> val = [];
  List<GraphItemData> graphItemList = [];
  List<GraphItemData> hrList = [];
  List<GraphItemData> oxygenList = [];
  List<GraphItemData> tempList = [];
  int sleepAxisCount = 0;
  SleepInfoModel? daySleepInfoModel;
  late GraphTypeModel model;
  ui.Color color1 = Colors.black;
  ui.Color color2 = Colors.black;
  List<MeasurementHistoryModel> measurementModelList = [];

  Widget lineChartWidget = Container();
  Widget sleepLineChartWidget = Container();
  Widget barChartWidget = Container();
  Widget lineAndBarChartWidget = Container();
  Widget bpLineChartWidget = Container();

  List<chart.Series<BloodPressure, double>> bpLineChartSeries = [];

  String graphTypeName1 = '';
  String graphTypeName2 = '';
  late ChartType chartType;

  List<chart.Series<GraphItemData, num>> lineChartSeries = [];
  List<chart.Series<GraphItemData, String>> barChartSeries = [];

  List<chart.Series<SleepGraphData, num>> sleepHRchartSeries = [];

  List<chart.Series<GraphItemData, num>> sleepLineChartSeries = [];

  List<GraphTypeModel> sleepChartTypeList = [];

  List<GraphTypeModel> sleepGraphTypeList = [];

  List<GraphItemData> sleepItemList = [];

  List<chart.Series<GraphItemData, String>> sleepBarChartSeries = [];

  Widget sleepBarChartWidget = Container();

  List<chart.Series<GraphItemData, num>> lineAndBarChartSeries = [];

  List<chart.Series<GraphItemData, num>> stepLineChartSeries = [];

  Widget stepLineChartWidget = Container();
  List<BPGraph> bpCandleData =
      []; // stores the list of bp data for candle stick
  int avgSbp = 0; // to store avg sys
  int avgDbp = 0; // to store avg dia
  int bpIndex = 0;
  Widget calorieLineChart = Container();
  Widget oxygenLineChartWidget = Container();
  Widget tempLineChartWidget = Container();

  List<chart.Series<GraphItemData, num>> calorieLineChartSeries = [];
  List<chart.Series<GraphItemData, num>> lineChartWeightSeries = [];
  List<chart.Series<SleepGraphData, num>> lineChartTemperatureSeries = [];
  List<chart.Series<SleepGraphData, num>> lineChartOxygenSeries = [];

  double startSleepTime = 0.0;

  GraphWindowState(DateTime selectedDate, this.graphWindow, this.graphTab,
      this.graphTypeList) {
    setDates(selectedDate);
  }

  BloodPressure bloodPressure =
      BloodPressure(xValue: 0.0, yValue: 0.0, color: Colors.yellow, date: '');

  MeasurementHistoryModel? selectedMeasurement;

  late bool isEditMode;

  bool isSwap = false;
  bool isInterpolationEnable = false;
  bool isNormalizationEnable = false;
  String weightLabel = '';

  List<RadioModel> graphList = [
    RadioModel(false, stringLocalization.getText(StringLocalization.lineGraph)),
    RadioModel(false, stringLocalization.getText(StringLocalization.barGraph)),
    RadioModel(
        false, stringLocalization.getText(StringLocalization.lineAndBarGraph))
  ];

  @override
  void initState() {
    isEditMode = graphWindow.editMode;
    chartType = graphWindow.selectedChartType;
    // getPreference();
    // getData();
    // getSleepDayData();
    // getSleepData();
    // getGraphTitle();
    // setWeightModel();
    isNormalizationEnable = graphWindow.normalization;
    sleepGraphTypeList = [
      graphTypeList.firstWhere((element) =>
          element.fieldName == DefaultGraphItem.lightSleep.fieldName),
      graphTypeList.firstWhere((element) =>
          element.fieldName == DefaultGraphItem.deepSleep.fieldName),
      graphTypeList.firstWhere(
          (element) => element.fieldName == DefaultGraphItem.awake.fieldName)
    ];
    // removeDeletedType();
    super.initState();
  }

  removeDeletedType() {
    try {
      List list = [];
      if (graphTypeList != null) {
        selectedGraphTypeList.forEach((element) {
          if (!graphTypeList.any((e) => e.fieldName == element.fieldName)) {
            list.add(element);
          }
        });
        list.forEach((element) {
          selectedGraphTypeList.remove(element);
        });
      }
    } catch (e) {
      print('exception in graph window screen $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).brightness == Brightness.dark
            ? HexColor.fromHex('#111B1A')
            : AppColor.backgroundColor,
        borderRadius: BorderRadius.circular(10.h),
        boxShadow: [
          BoxShadow(
            color: Theme.of(context).brightness == Brightness.dark
                ? HexColor.fromHex('#D1D9E6').withOpacity(0.07)
                : Colors.white,
            blurRadius: 4,
            spreadRadius: 0,
            offset: Offset(-4, -4),
          ),
          BoxShadow(
            color: Theme.of(context).brightness == Brightness.dark
                ? HexColor.fromHex('#000000').withOpacity(0.6)
                : HexColor.fromHex('#9F2DBC').withOpacity(0.15),
            blurRadius: 4,
            spreadRadius: 0,
            offset: Offset(4, 4),
          ),
        ],
      ),
//        elevation: 4.0,
      margin: EdgeInsets.symmetric(horizontal: 13.w, vertical: 10.h),
      child: Stack(
        children: [
          Container(
            alignment: Alignment.topRight,
            padding: EdgeInsets.only(top: 8.h, right: 20.w),
            child: graphWindow.defaultGraph
                ? Container()
                : InkWell(
                    child: Image.asset(
                      'asset/pencil_icon.png',
                      height: 20.h,
                      width: 20.h,
                    ),
                    onTap: () {
                      isEditMode = !isEditMode;
                      print('index: ${graphWindow.index}');
                      graphWindow.editMode = isEditMode;
                      updatePrefForSelectedItem();
                      if (this.mounted) setState(() {});
                    },
                  ),
          ),
          (selectedGraphTypeList != null &&
                  selectedGraphTypeList.length > 1 &&
                  selectedGraphTypeList[0].fieldName == 'approxHr' &&
                  selectedGraphTypeList[1].fieldName == 'sleepAllTime' &&
                  widget.graphTab != GraphTab.day)
              ? Align(
                  alignment: Alignment.topLeft,
                  child: InkWell(
                    onTap: () {
                      graphWindow.selectedChartType =
                          graphWindow.selectedChartType == ChartType.line
                              ? ChartType.bar
                              : ChartType.line;
                      updatePrefForSelectedItem();
                      if (mounted) setState(() {});
                    },
                    child: Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
                      child: Icon(
                        graphWindow.selectedChartType == ChartType.line
                            ? Icons.insert_chart
                            : Icons.show_chart,
                        size: 25.h,
                        color: Theme.of(context).colorScheme.secondary,
                      ),
                    ),
                  ),
                )
              : Container(),
          Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              SizedBox(height: 10.h),
              graphWindow.defaultGraph
                  ? Flexible(
                      child: SizedBox(
                        height: 25.h,
                        child: Body1AutoText(
                          text: graphWindow.title,
                          align: TextAlign.center,
                          color: Theme.of(context).brightness == Brightness.dark
                              ? AppColor.white87
                              : AppColor.color384341,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                          maxLine: 1,
                          minFontSize: 12,
                        ),
                      ),
                    )
                  : Container(
                      height: 25.h,
                      width: 270.w,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                            child: Body1Text(
                              text: graphTypeName1,
                              align: selectedGraphTypeList.length == 1
                                  ? TextAlign.center
                                  : TextAlign.right,
                              color: color1,
                              textOverflow: TextOverflow.ellipsis,
                            ),
                          ),
                          SizedBox(
                            width: 5.w,
                          ),
                          Body1Text(
                            text: selectedGraphTypeList != null &&
                                    selectedGraphTypeList.length > 1
                                ? 'Vs'
                                : '',
                            align: TextAlign.center,
                          ),
                          SizedBox(
                            width: 5.w,
                          ),
                          selectedGraphTypeList != null &&
                                  selectedGraphTypeList.length > 1
                              ? Expanded(
                                  child: Body1Text(
                                    text: graphTypeName2,
                                    align: TextAlign.left,
                                    color: color2,
                                    textOverflow: TextOverflow.ellipsis,
                                  ),
                                )
                              : Container(),
                        ],
                      ),
                    ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 8.h),
                height: heightForGraph(),
                width: MediaQuery.of(context).size.width,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Expanded(
                          child: isEditMode
                              ? selectedItemsListView()
                              : SizedBox(
                                  height: 10.h,
                                ),
                        ),
                        isEditMode &&
                                (lineChartSeries.length > 1 ||
                                    barChartSeries.length > 1)
                            ? Container(
                                padding: EdgeInsets.only(right: 20.w),
                                child: InkWell(
                                  child: Icon(
                                    Icons.swap_horizontal_circle,
                                    color: AppColor.primaryColor,
                                    size: 30.h,
                                  ),
                                  onTap: () {
                                    isSwap = true;
                                    getData();
                                    if (mounted) setState(() {});
                                  },
                                ),
                              )
                            : Container(),
                        isEditMode
                            ? Container(
                                padding: EdgeInsets.only(right: 5.w),
                                child: InkWell(
                                  child: Icon(
                                    Icons.delete,
                                    color: AppColor.primaryColor,
                                  ),
                                  onTap: deleteDialog,
                                ),
                              )
                            : Container(),
                      ],
                    ),
                    checkForLabel()
                        ? Padding(
                            padding: selectedGraphTypeList.first.fieldName ==
                                        'approxDBP' &&
                                    widget.graphTab == GraphTab.week
                                ? EdgeInsets.only(left: 5)
                                : EdgeInsets.only(left: 0),
                            child: Row(
                              children: [
                                Expanded(
                                  child: SizedBox(
                                    height: 22.h,
                                    child: AutoSizeText(
                                      fieldName(),
                                      textAlign: setTextAlign(),
                                      style: TextStyle(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? HexColor.fromHex('#FF9E99')
                                              : HexColor.fromHex('#FF6259'),
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          )
                        : Container(),
                    Expanded(
                      child: selectedGraphTypeList != null &&
                              selectedGraphTypeList.isNotEmpty
                          ? graphDataLayout()
                          : Container(),
                    ),
                    //SizedBox(height: 7.h,),
                    (widget.graphWindow.defaultGraph &&
                            selectedGraphTypeList != null &&
                            selectedGraphTypeList.length > 1 &&
                            selectedGraphTypeList.last.fieldName ==
                                'sleepAllTime' &&
                            widget.graphTab == GraphTab.day)
                        ? Align(
                            alignment: Alignment.bottomRight,
                            child: Container(
                              padding: EdgeInsets.only(right: 20.w),
                              height: 22.h,
                              child: AutoSizeText(
                                'SLEEP',
                                style: TextStyle(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? HexColor.fromHex('#FF9E99')
                                        : HexColor.fromHex('#FF6259'),
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                          )
                        : (widget.graphWindow.defaultGraph &&
                                selectedGraphTypeList != null &&
                                selectedGraphTypeList.first.fieldName ==
                                    'approxDBP')
                            ? Align(
                                alignment: Alignment.bottomRight,
                                child: Container(
                                  padding: EdgeInsets.only(right: 21.w),
                                  height: 22.h,
                                  child: AutoSizeText(
                                    'DIA',
                                    style: TextStyle(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? HexColor.fromHex('#FF9E99')
                                            : HexColor.fromHex('#FF6259'),
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),
                              )
                            : Container(),
//                    isEditMode ? GestureDetector(
//                      onTap: (){
//                        graphWindow.normalization = !graphWindow.normalization;
//                        isShowLoadingScreen = true;
//                        getData();
//                        if(this.mounted) {
//                          setState(() {});
//                        }
//                      },
//                      child : Container(
//                        height: 38.h,
//                        margin: EdgeInsets.only(top:10.h),
//                        decoration: BoxDecoration(
//                          border: Border.all(
//                            color: graphWindow.normalization?Theme.of(context).toggleableActiveColor:Theme.of(context).disabledColor
//                          )
//                        ),
//                        alignment: Alignment.center,
//                        padding: EdgeInsets.symmetric(vertical: 8.h,horizontal: 10.w,),
//                        child: Row(
//                          mainAxisSize: MainAxisSize.min,
//                          children: [
//                            Body1AutoText(text: stringLocalization.getText(StringLocalization.normalization),align: TextAlign.center,),
//                            Switch(value: graphWindow.normalization, onChanged: (value){
//                              graphWindow.normalization = value;
//                              isShowLoadingScreen = true;
//                              updatePrefForSelectedItem();
//                              getData();
//                              if(this.mounted) {
//                                setState(() {});
//                              }
//                            }),
//                          ],
//                        ),
//                      ),
//                    ):
                    (selectedGraphTypeList.length > 1 &&
                            widget.graphWindow.defaultGraph &&
                            selectedGraphTypeList[1].fieldName ==
                                'sleepAllTime')
                        ? SizedBox(
                            height: 10.h,
                          )
                        : Container(),
                    (selectedGraphTypeList != null &&
                            selectedGraphTypeList.length > 1 &&
                            widget.graphWindow.defaultGraph
                        ? selectedGraphTypeList[1].fieldName == 'step'
                            ? Container()
                            : selectedGraphTypeList[1].fieldName == 'calories'
                                ? Container()
                                : selectedGraphTypeList[1].fieldName ==
                                        'sleepAllTime'
                                    ? (widget.graphTab == GraphTab.day ||
                                            widget.graphWindow
                                                    .selectedChartType ==
                                                ChartType.bar)
                                        ? sleepLegends()
                                        : sleepIndicator()
                                    : selectedGraphTypeList.first.fieldName ==
                                            'approxSBP'
                                        ? candleGraphIndicator()
                                        : bloodPressureIndicator(
                                            bloodPressure.yValue != 0.0
                                                ? bloodPressure.yValue.toInt()
                                                : (measurementModelList !=
                                                            null &&
                                                        measurementModelList
                                                                .length >
                                                            0)
                                                    ? measurementModelList
                                                        .last.sbp
                                                    : 0,
                                            bloodPressure.xValue != 0.0
                                                ? bloodPressure.xValue.toInt()
                                                : (measurementModelList !=
                                                            null &&
                                                        measurementModelList
                                                                .length >
                                                            0)
                                                    ? measurementModelList
                                                        .last.dbp
                                                    : 0)
                        : Container()),
                    SizedBox(
                        height: selectedGraphTypeList != null &&
                                widget.graphWindow.defaultGraph &&
                                selectedGraphTypeList.first.fieldName ==
                                    'approxDBP' &&
                                widget.graphTab == GraphTab.week
                            ? 10.0
                            : 20.h),
                  ],
                ),
              ),
            ],
          ),
          isEditMode
              ? Align(
                  alignment: Alignment.topLeft,
                  child: InkWell(
                      onTap: () {
                        selectGraphType(onClickOk: () {
                          if (context != null) {
                            Navigator.of(context, rootNavigator: true).pop();
                          }
                          graphWindow.selectedChartType = chartType;
                          graphWindow.normalization = isNormalizationEnable;
                          updatePrefForSelectedItem();
                          makeOrRefreshChartWidget(context);
                          if (mounted) setState(() {});
                        });
                      },
                      child: Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: 12.w, vertical: 8.h),
                        child: Icon(
                          Icons.insert_chart,
                          color: AppColor.primaryColor,
                        ),
                      )),
                )
              : Container(),
        ],
      ),
    );
  }

  ui.TextAlign setTextAlign() {
    try {
      if (selectedGraphTypeList != null && selectedGraphTypeList.length > 1) {
        if (selectedGraphTypeList.length > 1) {
          int index = selectedGraphTypeList.indexWhere((element) =>
              element.fieldName == DefaultGraphItem.weight.fieldName);
          if (index > -1 && index == 1) {
            return TextAlign.end;
          }
        }
      }
    } catch (e) {
      print('exception in graph window screen $e');
    }
    return TextAlign.start;
  }

  bool checkForLabel() {
    return (selectedGraphTypeList != null &&
        ((selectedGraphTypeList.length > 0 &&
                selectedGraphTypeList.any((element) =>
                    element.fieldName == DefaultGraphItem.weight.fieldName)) ||
            (selectedGraphTypeList.length > 1 &&
                widget.graphWindow.defaultGraph)));
  }

  String fieldName() {
    if (selectedGraphTypeList.any(
        (element) => element.fieldName == DefaultGraphItem.weight.fieldName)) {
      if (UnitExtension.getUnitType(weightUnit) == UnitTypeEnum.imperial) {
        return '${stringLocalization.getText(StringLocalization.weight).toUpperCase()} (${stringLocalization.getText(StringLocalization.lb)})';
      } else {
        return '${stringLocalization.getText(StringLocalization.weight).toUpperCase()} (${stringLocalization.getText(StringLocalization.kg)})';
      }
    }
    if (widget.graphWindow.defaultGraph) {
      var temp = tempUnit == 0 ? '(°C)' : '(°F)';
      return selectedGraphTypeList.first.fieldName == 'approxHr'
          ? 'HR'
          : selectedGraphTypeList.first.fieldName == 'Oxygen'
              ? '${stringLocalization.getText(StringLocalization.oxygen).toUpperCase()}'
              : selectedGraphTypeList.first.fieldName == 'WeightSum'
                  ? 'WEIGHT'
                  : selectedGraphTypeList.first.fieldName == 'approxSBP'
                      ? 'BP'
                      : selectedGraphTypeList.first.fieldName == 'Temperature'
                          ? '${stringLocalization.getText(StringLocalization.bodyTemperature).toUpperCase()} $temp'
                          : 'SYS';
    }
    return '';
  }

  setWeightModel() {
    try {
      bool isWightData = selectedGraphTypeList
          .any((element) => element.fieldName.toLowerCase().contains('weight'));
      if (isWightData) {
        weightLabel = '';
        if (UnitExtension.getUnitType(weightUnit) == UnitTypeEnum.metric) {
          weightLabel = stringLocalization.getText(StringLocalization.kg);
        }
        if (UnitExtension.getUnitType(weightUnit) == UnitTypeEnum.imperial) {
          weightLabel = stringLocalization.getText(StringLocalization.lb);
        }
      }
    } catch (e) {
      print('exception in graph window screen $e');
    }
  }

  double heightForGraph() {
    if (!isEditMode &&
        selectedGraphTypeList != null &&
        selectedGraphTypeList.any((element) =>
            element.fieldName == DefaultGraphItem.weight.fieldName)) {
      if (selectedGraphTypeList.any((element) =>
          element.fieldName == DefaultGraphItem.calories.fieldName)) {
        return 465.h;
      }
      return 320.h;
    }
    if (selectedGraphTypeList != null &&
        widget.graphWindow.defaultGraph &&
        selectedGraphTypeList.length > 1) {
      if (selectedGraphTypeList.first.fieldName == 'approxHr') {
        return selectedGraphTypeList[1].fieldName == 'step'
            ? 465.h
            : (widget.graphTab == GraphTab.week ||
                    widget.graphTab == GraphTab.month)
                ? widget.graphWindow.selectedChartType == ChartType.bar
                    ? 540.h
                    : 500.h
                : 410.h + 3;
      } else if (selectedGraphTypeList.first.fieldName == 'Oxygen' ||
          selectedGraphTypeList.first.fieldName == 'Temperature') {
        if (graphTab == GraphTab.day) {
          return 410.h + 3;
        } else {
          return 500.h;
        }
      } else if (selectedGraphTypeList.first.fieldName == 'WeightSum') {
        return 465.h;
      } else {
        return selectedGraphTypeList.first.fieldName == 'approxSBP'
            ? 445.h
            : 535.h;
      }
    }
    return isEditMode ? 390.0.h : 305.h;
  }

  void showDialogToEditName() {
    titleController.text = graphWindow.title;
    showDialog(
        context: context,
        barrierDismissible: true,
        builder: (BuildContext context) {
          return AlertDialog(
            content: TextField(
              controller: titleController,
              decoration: InputDecoration(
                labelText: StringLocalization.of(context)
                    .getText(StringLocalization.editTitle),
//                 labelStyle: TextStyle(color: AppColor.green)
              ),
            ),
            title: Text(
              StringLocalization.of(context)
                  .getText(StringLocalization.editTitleOfGraph),
//            style: TextStyle(),),
            ),
            actions: <Widget>[
              TextButton(
                child: Text(StringLocalization.of(context)
                    .getText(StringLocalization.ok)),
                onPressed: () {
                  if (mounted)
                    setState(() {
                      graphWindow.title = titleController.text;
                    });
                  updatePrefForSelectedItem();
                  if (mounted) setState(() {});
                  Navigator.pop(context);
                },
              ),
              TextButton(
                child: Text(StringLocalization.of(context)
                    .getText(StringLocalization.cancel)),
                onPressed: () {
                  Navigator.pop(context);
                },
              )
            ],
          );
        });
  }

  selectedItemsListView() {
    return Wrap(
      direction: material.Axis.horizontal,
      children:
          List<Widget>.generate(selectedGraphTypeList.length + 1, (index) {
        if (index == 0) {
          if (selectedGraphTypeList.length == graphTypeList.length) {
            return Container();
          }
          return Card(
            color: AppColor.primaryColor,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(100.h)),
            child: InkWell(
              onTap: () async {
                if (graphTypeList.length != selectedGraphTypeList.length) {
                  var dialog = ChooseGraphItems(
                    typeList: graphTypeList,
                    selectedGraphType: selectedGraphTypeList,
                  );
                  GraphTypeModel graphType = await showDialog(
                      context: context, builder: (context) => dialog);
                  if (graphType != null && selectedGraphTypeList.length == 2) {
                    // Scaffold.of(context).showSnackBar(SnackBar(
                    //   content: Text(
                    //     stringLocalization
                    //         .getText(StringLocalization.addGraphRestriction),
                    //     textAlign: TextAlign.center,
                    //   ),
                    // ));

                    CustomSnackBar.buildSnackbar(
                        context,
                        stringLocalization
                            .getText(StringLocalization.addGraphRestriction),
                        3);
                    if (mounted) setState(() {});
                  }
                  if (graphType != null && selectedGraphTypeList.length < 2) {
                    selectedGraphTypeList.add(graphType);
                    if (selectedGraphTypeList.length == 1) {
                      var title = setGraphTitle(selectedGraphTypeList, 0);
                      graphTypeName1 = title;
                      graphWindow.title = graphTypeName1;
                    } else {
                      var title1 = setGraphTitle(selectedGraphTypeList, 0);
                      var title2 = setGraphTitle(selectedGraphTypeList, 1);
                      graphTypeName1 = title1;
                      graphTypeName2 = title2;
                      graphWindow.title = '$graphTypeName1 Vs $graphTypeName2';
                    }
                    updatePrefForSelectedItem();
                    getData();
                    isShowLoadingScreen = true;
                    if (mounted) setState(() {});
                  }
                }
              },
              child: Container(
                key: Key("moreIcon"),
                height: 34.h,
                width: 34.h,
                // padding: EdgeInsets.all(6.h),
                child: Icon(
                  Icons.more_vert,
                  size: 30.h,
                  color: Colors.white,
                ),
              ),
            ),
          );
        }
        if (selectedGraphTypeList != null && selectedGraphTypeList.isNotEmpty) {
          model = selectedGraphTypeList[index - 1];
        }
        if (model == null) {
          return Container();
        }
        ui.Color color = Colors.black;
        if (model.color != null) {
          color = HexColor.fromHex(model.color);
        }
        if (index - 1 == 0) {
          color1 = color;
        } else {
          color2 = color;
        }

        return Container(
          constraints: BoxConstraints(
            minWidth: 80.0.h,
          ),
          margin: EdgeInsets.all(5.h),
          decoration: BoxDecoration(
              color: Theme.of(context).brightness == Brightness.dark
                  ? HexColor.fromHex('#111B1A')
                  : HexColor.fromHex('#EEF1F1').withOpacity(0.5),
              borderRadius: BorderRadius.circular(20.h),
              border: Border.all(
                color: HexColor.fromHex('#FF9E99'),
              )),
          padding: EdgeInsets.only(top: 5.h, bottom: 5.h, left: 10.w),
          child: Container(
            height: 25.h,
            constraints: BoxConstraints(maxWidth: 200.w),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                SizedBox(width: 10.w),
                GestureDetector(
                  onTap: () {
                    if (isEditMode) {
                      selectColorDialog(
                          selectedGraphTypeList[index - 1], index);
                      updatePrefForSelectedItem();
                      getData();
                      isShowLoadingScreen = true;
                      if (this.mounted) setState(() {});
                    }
                  },
                  child: Container(
                    constraints: BoxConstraints(maxWidth: 155.w),
                    child: Body1Text(
                      text: stringLocalization.getTextFromEnglish(model.name),
                      color: color,
                      align: TextAlign.center,
                      textOverflow: TextOverflow.ellipsis,
                    ),
                  ),
                ),
                // SizedBox(
                //   width: 10.w,
                // ),
                Opacity(
                  opacity: isEditMode ? 1 : 0,
                  child: InkWell(
                    child: Container(
                      margin:
                          EdgeInsets.symmetric(vertical: 5.h, horizontal: 10.w),
                      child: Image.asset(
                        'asset/close_icon.png',
                        height: 8,
                        width: 7.5,
                      ),
                    ),
                    onTap: () {
                      if (isEditMode) {
                        selectedGraphTypeList.removeAt(index - 1);
                        if (index - 1 == 0) {
                          graphTypeName1 = selectedGraphTypeList.length == 0
                              ? ''
                              : graphTypeName2;
                          color1 = color;
                          graphWindow.title = graphTypeName1;
                        } else {
                          graphTypeName1 = selectedGraphTypeList.length == 0
                              ? ''
                              : graphTypeName1;
                          color1 = color;
                          graphWindow.title = graphTypeName1;
                        }
                        if (chartType == ChartType.pie) {
                          chartType = ChartType.bar;
                          graphWindow.selectedChartType = chartType;
                        }
                        updatePrefForSelectedItem();
                        getData();
                        isShowLoadingScreen = true;
                        if (this.mounted) setState(() {});
                      }
                    },
                  ),
                )
              ],
            ),
          ),
        );
      }),
    );
  }

  Widget graphDataLayout() {
    return ValueListenableBuilder(
      valueListenable: widget.graphWindow.onChangeDate,
      builder: (context, DateTime? selectedDate, child) {
        if (selectedDate != null) {
          refresh(selectedDate);
          // selectedDate = null;
          DateTime _temp = DateTime(
              DateTime.now().year,
              DateTime.now().month,
              DateTime.now().day,
              0,
              0,
              0,
              0,
              0);
         print("graphDataLayout data:: ${_temp}");
          widget.graphWindow.onChangeDate.value = _temp;
        }
        if (isShowLoadingScreen &&
            selectedGraphTypeList != null &&
            selectedGraphTypeList.isNotEmpty) {
          return Center(
            child: CircularProgressIndicator(),
          );
        }
        return (widget.graphWindow.defaultGraph &&
                selectedGraphTypeList != null &&
                selectedGraphTypeList.length > 1 &&
                selectedGraphTypeList.first.fieldName == 'approxSBP')
            ? bpCandleGraph()
            : selectedGraphTypeList != null &&
                    widget.graphWindow.defaultGraph &&
                    selectedGraphTypeList.length > 1 &&
                    selectedGraphTypeList[0].fieldName == 'Oxygen' &&
                    selectedGraphTypeList[1].fieldName == 'sleepAllTime' &&
                    widget.graphTab == GraphTab.day
                ? Container(
                    height: 200.h,
                    child: chartWidget(
                        isHRVsSleep: false,
                        isBP: false,
                        isOxygenVsSleep: true,
                        isTempVsSleep: false,
                        isActivity: false,
                        isCalories: false),
                  )
                : selectedGraphTypeList != null &&
                        widget.graphWindow.defaultGraph &&
                        selectedGraphTypeList.length > 1 &&
                        selectedGraphTypeList[0].fieldName == 'Temperature' &&
                        selectedGraphTypeList[1].fieldName == 'sleepAllTime' &&
                        widget.graphTab == GraphTab.day
                    ? Container(
                        height: 200.h,
                        child: chartWidget(
                            isHRVsSleep: false,
                            isBP: false,
                            isOxygenVsSleep: false,
                            isTempVsSleep: true,
                            isActivity: false,
                            isCalories: false),
                      )
                    : Container(
                        height: selectedGraphTypeList != null &&
                                widget.graphWindow.defaultGraph &&
                                selectedGraphTypeList.length > 1
                            ? selectedGraphTypeList[0].fieldName == 'WeightSum'
                                ? 380.h
                                : selectedGraphTypeList[0].fieldName ==
                                        'approxHr'
                                    ? selectedGraphTypeList[1].fieldName ==
                                            'step'
                                        ? 380.h
                                        : (widget.graphTab == GraphTab.week ||
                                                widget.graphTab ==
                                                    GraphTab.month)
                                            ? 380.h
                                            : 200.h
                                    : 250.h
                            : 250.h,
                        child: Column(
                          children: [
                            SizedBox(
                                height: selectedGraphTypeList != null &&
                                        widget.graphWindow.defaultGraph &&
                                        selectedGraphTypeList[0].fieldName ==
                                            'approxDBP'
                                    ? 250.h
                                    : (widget.graphWindow.defaultGraph &&
                                            selectedGraphTypeList.length > 1 &&
                                            (selectedGraphTypeList[0].fieldName ==
                                                'WeightSum'))
                                        ? 180.h
                                        : (widget.graphWindow.defaultGraph &&
                                                selectedGraphTypeList.length >
                                                    1 &&
                                                (selectedGraphTypeList[0].fieldName == 'approxHr' ||
                                                    selectedGraphTypeList[0].fieldName ==
                                                        'Oxygen' ||
                                                    selectedGraphTypeList[0].fieldName ==
                                                        'Temperature') &&
                                                (widget.graphTab == GraphTab.week ||
                                                    widget.graphTab ==
                                                        GraphTab.month ||
                                                    selectedGraphTypeList[1].fieldName ==
                                                        'step'))
                                            ? 180.h
                                            : 250.h,
                                width: Constants.width.w,
                                child: selectedGraphTypeList != null &&
                                        widget.graphWindow.defaultGraph &&
                                        selectedGraphTypeList.length > 1 &&
                                        selectedGraphTypeList[0].fieldName ==
                                            'approxDBP' &&
                                        selectedGraphTypeList[1].fieldName ==
                                            'approxSBP'
                                    ? chartWidget(
                                        isHRVsSleep: false,
                                        isBP: true,
                                        isActivity: false,
                                        isCalories: false,
                                        isOxygenVsSleep: false,
                                        isTempVsSleep: false,
                                      )
                                    : selectedGraphTypeList != null &&
                                            widget.graphWindow.defaultGraph &&
                                            selectedGraphTypeList.length > 1 &&
                                            selectedGraphTypeList[0].fieldName ==
                                                'WeightSum'
                                        ? chartWidget(
                                            isActivity: false,
                                            isBP: false,
                                            isHRVsSleep: false,
                                            isOxygenVsSleep: false,
                                            isTempVsSleep: false,
                                            isCalories: false)
                                        : chartWidget(isHRVsSleep: false, isBP: false, isOxygenVsSleep: false, isTempVsSleep: false, isActivity: false, isCalories: false)),
                            selectedGraphTypeList != null &&
                                    widget.graphWindow.defaultGraph &&
                                    selectedGraphTypeList.length > 1 &&
                                    ((selectedGraphTypeList[0].fieldName ==
                                                    'approxHr' ||
                                                selectedGraphTypeList[0]
                                                        .fieldName ==
                                                    'Oxygen' ||
                                                selectedGraphTypeList[0]
                                                        .fieldName ==
                                                    'Temperature') &&
                                            (selectedGraphTypeList[1]
                                                        .fieldName ==
                                                    'step' ||
                                                (widget.graphTab ==
                                                        GraphTab.week ||
                                                    widget.graphTab ==
                                                        GraphTab.month)) ||
                                        selectedGraphTypeList[1].fieldName ==
                                            'calories')
                                ? SizedBox(height: 15.h)
                                : Container(),
                            selectedGraphTypeList != null &&
                                    widget.graphWindow.defaultGraph &&
                                    selectedGraphTypeList.length > 1 &&
                                    ((selectedGraphTypeList[0].fieldName ==
                                                    'approxHr' ||
                                                selectedGraphTypeList[0]
                                                        .fieldName ==
                                                    'Oxygen' ||
                                                selectedGraphTypeList[0]
                                                        .fieldName ==
                                                    'Temperature') &&
                                            (selectedGraphTypeList[1]
                                                        .fieldName ==
                                                    'step' ||
                                                (widget.graphTab ==
                                                        GraphTab.week ||
                                                    widget.graphTab ==
                                                        GraphTab.month)) ||
                                        selectedGraphTypeList[0].fieldName ==
                                            'WeightSum')
                                ? Align(
                                    alignment: Alignment.bottomLeft,
                                    child: SizedBox(
                                      height: 22.h,
                                      child: AutoSizeText(
                                        selectedGraphTypeList[1].fieldName ==
                                                'step'
                                            ? 'STEP'
                                            : selectedGraphTypeList[0]
                                                        .fieldName ==
                                                    'WeightSum'
                                                ? 'CALORIES'
                                                : 'SLEEP',
                                        style: TextStyle(
                                            color: Theme.of(context)
                                                        .brightness ==
                                                    Brightness.dark
                                                ? HexColor.fromHex('#FF9E99')
                                                : HexColor.fromHex('#FF6259'),
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  )
                                : Container(),
                            selectedGraphTypeList != null &&
                                    widget.graphWindow.defaultGraph &&
                                    selectedGraphTypeList.length > 1 &&
                                    ((selectedGraphTypeList[0].fieldName ==
                                                    'approxHr' ||
                                                selectedGraphTypeList[0]
                                                        .fieldName ==
                                                    'Oxygen' ||
                                                selectedGraphTypeList[0]
                                                        .fieldName ==
                                                    'Temperature') &&
                                            (selectedGraphTypeList[1]
                                                        .fieldName ==
                                                    'step' ||
                                                (widget.graphTab ==
                                                        GraphTab.week ||
                                                    widget.graphTab ==
                                                        GraphTab.month)) ||
                                        selectedGraphTypeList[0].fieldName ==
                                            'WeightSum')
                                ? SizedBox(
                                    height: 180.h,
                                    width: Constants.width.w,
                                    child: selectedGraphTypeList[0].fieldName ==
                                                'approxHr' &&
                                            selectedGraphTypeList[1].fieldName ==
                                                'sleepAllTime'
                                        ? chartWidget(
                                            isHRVsSleep: true,
                                            isBP: false,
                                            isTempVsSleep: false,
                                            isOxygenVsSleep: false,
                                            isActivity: false,
                                            isCalories: false)
                                        : selectedGraphTypeList[0].fieldName ==
                                                    'Oxygen' &&
                                                selectedGraphTypeList[1]
                                                        .fieldName ==
                                                    'sleepAllTime'
                                            ? chartWidget(
                                                isHRVsSleep: true,
                                                isBP: false,
                                                isOxygenVsSleep: true,
                                                isTempVsSleep: false,
                                                isActivity: false,
                                                isCalories: false)
                                            : selectedGraphTypeList[0].fieldName ==
                                                        'Temperature' &&
                                                    selectedGraphTypeList[1]
                                                            .fieldName ==
                                                        'sleepAllTime'
                                                ? chartWidget(
                                                    isHRVsSleep: true,
                                                    isBP: false,
                                                    isTempVsSleep: false,
                                                    isOxygenVsSleep: false,
                                                    isActivity: false,
                                                    isCalories: false)
                                                : selectedGraphTypeList[0]
                                                            .fieldName ==
                                                        'WeightSum'
                                                    ? chartWidget(
                                                        isHRVsSleep: false,
                                                        isBP: false,
                                                        isOxygenVsSleep: false,
                                                        isTempVsSleep: false,
                                                        isActivity: false,
                                                        isCalories: true)
                                                    : chartWidget(
                                                        isHRVsSleep: false,
                                                        isBP: false,
                                                        isOxygenVsSleep: false,
                                                        isTempVsSleep: false,
                                                        isActivity: true,
                                                        isCalories: false),
                                  )
                                : Container(),
                          ],
                        ),
                      );
      },
    );
  }

  Widget chartWidget(
      {required bool isHRVsSleep,
      required bool isBP,
      required bool isActivity,
      required bool isCalories,
      required bool isOxygenVsSleep,
      required bool isTempVsSleep}) {
    if (widget.graphWindow.defaultGraph &&
        widget.graphTab == GraphTab.day &&
        selectedGraphTypeList.length > 1 &&
        selectedGraphTypeList[1].fieldName == 'sleepAllTime') {
      graphWindow.selectedChartType = ChartType.line;
    }

    if (graphTypeList == null || graphTypeList.length == 0) {
      return Center(
        child: Body1AutoText(
            text: stringLocalization.getText(StringLocalization.noDataFound)),
      );
    }
    switch (graphWindow.selectedChartType) {
      case ChartType.line:
        return isHRVsSleep
            ? sleepLineChartWidget
            : isBP
                ? bpLineChartWidget
                : isActivity
                    ? stepLineChartWidget
                    : isCalories
                        ? calorieLineChart
                        : isOxygenVsSleep
                            ? oxygenLineChartWidget
                            : isTempVsSleep
                                ? tempLineChartWidget
                                : lineChartWidget;
      case ChartType.bar:
        return isHRVsSleep ? sleepBarChartWidget : barChartWidget;
      case ChartType.pie:
        return lineAndBarChartWidget;
      default:
        return Container();
    }
  }

  int xAxisCount() {
    if (widget.graphTab == GraphTab.day) {
      return 24;
    } else if (widget.graphTab == GraphTab.week) {
      return 7;
    } else if (widget.graphTab == GraphTab.month) {
      return daysInMonth(startDate);
    }
    return startDate.difference(endDate).inDays;
  }

  int daysInMonth(DateTime date) {
    if (date != null) {
      var firstDayNextMonth = DateTime(date.year, date.month + 1, 0);
      return firstDayNextMonth.day;
    }
    return 31;
  }

  String _formattXAxis(num? year) {
    if (widget.graphTab == GraphTab.week) {
      DateTime date = DateTime.now();
      var lastMonday =
          date.subtract(Duration(days: date.weekday - year!.toInt()));
      return DateFormat(DateUtil.EEE).format(lastMonday); // prints Tuesday
    }
    int value = year!.toInt() + startSleepTime.toInt();
    if (value < 24) {
      value -= 12;
      return '$value\npm';
    } else if (value == 24) {
      value -= 12;
      return '$value\nam';
    } else {
      value -= 24;
      return '$value\nam';
    }
  }

  String _sleepFormatterXAxis(num year) {
    if (widget.graphTab == GraphTab.week) {
      DateTime date = DateTime.now();
      var lastMonday =
          date.subtract(Duration(days: date.weekday - year.toInt()));
      return DateFormat(DateUtil.EEE).format(lastMonday); // prints Tuesday
    }
    int value = year.toInt();
    if (value % 2 == 0) {
      return '';
    }
    return '$value';
  }

  String _formatterYAxis(num? year) {
    int value2 = ((year! ~/ 5) + 4) * 10;
    if (value2 == 40 ||
        value2 == 90 ||
        value2 == 120 ||
        value2 == 140 ||
        value2 == 160 ||
        value2 == 180) {
      //value2 = value2 + 10;
      return '$value2';
    }
    return '';
    // return '$year$weightLabel';
  }

  String _formatterXAxis(num? year) {
    if (widget.graphTab == GraphTab.week) {
      DateTime date = DateTime.now();
      var lastMonday =
          date.subtract(Duration(days: date.weekday - year!.toInt()));
      return DateFormat(DateUtil.EEE).format(lastMonday); // prints Tuesday
    }
    int value = year!.toInt();
    if (value % 2 == 0) {
      return '';
    }
    return '$value';
  }

  String _formatterAxis(num? year) {
    int value = (year!.toInt() + 8) * 5;
    if (value == 60 ||
        value == 80 ||
        value == 90 ||
        value == 100 ||
        value == 120) {
      //value = value + 5;
      return '$value';
    }
    return '';
  }

  String getTitle() {
    String title = stringLocalization.getText(StringLocalization.unknown);
    if (graphWindow != null &&
        graphWindow.title != null &&
        graphWindow.title.toLowerCase() != 'null') {
      title = graphWindow.title;
    }
    return title;
  }

  refreshData() {
    isShowLoadingScreen = true;
    getData();
    // setState(() {});
  }

  weekDates(DateTime selectedDate) {
    var dayNr = (selectedDate.weekday + 7) % 7 - 1;
    startDate = selectedDate.subtract(Duration(days: (dayNr)));
    endDate = startDate.add(Duration(days: 6));
  }

  setDates(DateTime selectedDate) {
    if (graphTab != null) {
      if (graphTab == GraphTab.week) {
        var dayNr = (selectedDate.weekday + 7) % 7 - 1;
        startDate = selectedDate.subtract(Duration(days: (dayNr)));
        startDate =
            DateTime(startDate.year, startDate.month, startDate.day, 0, 0, 0);
        endDate = startDate.add(Duration(days: 6));
        endDate = DateTime(endDate.year, endDate.month, endDate.day + 1);
      } else if (graphTab == GraphTab.month) {
        startDate = DateTime(selectedDate.year, selectedDate.month, 1);
        endDate = DateTime(selectedDate.year, selectedDate.month + 1, 1);
      } else {
        startDate =
            DateTime(selectedDate.year, selectedDate.month, selectedDate.day);
        endDate = DateTime(
            selectedDate.year, selectedDate.month, selectedDate.day + 1);
      }
    }
  }

  Future getData() async {
    removeDeletedType();
    if (userId == null) {
      await getPreference();
    }
    if (startDate != null && endDate != null) {
      late int unit;
      if (UnitExtension.getUnitType(weightUnit) == UnitTypeEnum.metric) {
        unit = 1;
      }
      if (UnitExtension.getUnitType(weightUnit) == UnitTypeEnum.imperial) {
        unit = 2;
      }
      graphItemList = await GraphDataManager().graphManager(
          userId: userId,
          startDate: startDate,
          endDate: endDate,
          selectedGraphTypes: selectedGraphTypeList,
          isEnableNormalize: false,
          unitType: unit);
      sleepItemList = await GraphDataManager().graphManager(
          userId: userId,
          startDate: startDate,
          endDate: endDate,
          selectedGraphTypes: sleepGraphTypeList,
          isEnableNormalize: false,
          unitType: unit);
      var distinct = <GraphItemData>[];
      var distinct2 = <GraphItemData>[];
      for (var d in sleepItemList) {
        GraphItemData value = sleepItemList
            .where((element) {
              return (element.label == d.label &&
                  element.xValueStr == d.xValueStr &&
                  element.yValue == d.yValue);
            })
            .toList()
            .last;
        if (!distinct2.contains(value)) {
          distinct2.add(value);
        }
      }

      if (graphItemList != null && graphItemList.isNotEmpty) {
        for (var d in graphItemList) {
          GraphItemData value = graphItemList
              .where((element) {
                return (element.label == d.label &&
                    element.xValueStr == d.xValueStr &&
                    element.yValue == d.yValue);
              })
              .toList()
              .last;
          if (!distinct.contains(value)) {
            distinct.add(value);
          }
        }
      }
      try {
        if (selectedGraphTypeList != null &&
            widget.graphWindow.defaultGraph &&
            selectedGraphTypeList.length > 1 &&
            (selectedGraphTypeList.first.fieldName == 'approxDBP' ||
                selectedGraphTypeList.first.fieldName == 'approxSBP')) {
          await getMeasurementData();
        }
      } catch (e) {
        print(e);
      }
      if (distinct2.isNotEmpty) {
        sleepItemList = distinct2;
        sleepItemList.forEach((element) {
          element.yValue = element.yValue / 60;
        });
      }
      for (int i = 0; i < distinct.length; i++) {
        if (distinct[i].yValue == 0) {
          distinct.removeAt(i);
          i--;
        }
      }
      distinct.sort((a, b) => a.date!.compareTo(b.date!));
      distinct.sort((a, b) => a.label.compareTo(b.label));
      var dayAvgList = <GraphItemData>[];
      if (graphWindow.selectedChartType == ChartType.bar &&
          graphTab == GraphTab.day) {
        double yVal = 0;
        int count = 0;
        if (distinct.length > 1) {
          for (int i = 0; i < distinct.length - 1; i++) {
            DateTime date1 = Date().convertDateFromString(distinct[i].date!);
            DateTime date2 =
                Date().convertDateFromString(distinct[i + 1].date!);
            if (i == distinct.length - 2) {
              if (date1.hour == date2.hour &&
                  distinct[i].label == distinct[i + 1].label) {
                yVal = yVal + distinct[i].yValue + distinct[i + 1].yValue;
                yVal = yVal / (count + 2);
                dayAvgList.add(GraphItemData(
                  type: distinct[i].type,
                  date: distinct[i].date,
                  edate: distinct[i].edate,
                  yValue: yVal,
                  xValue: distinct[i].xValue,
                  colorCode: distinct[i].colorCode,
                  label: distinct[i].label,
                  xValueStr: distinct[i].xValueStr,
                ));
              } else {
                yVal = yVal + distinct[i].yValue;
                count++;
                yVal = yVal / count;
                dayAvgList.add(GraphItemData(
                  type: distinct[i].type,
                  date: distinct[i].date,
                  edate: distinct[i].edate,
                  yValue: yVal,
                  xValue: distinct[i].xValue,
                  colorCode: distinct[i].colorCode,
                  label: distinct[i].label,
                  xValueStr: distinct[i].xValueStr,
                ));
                dayAvgList.add(GraphItemData(
                  type: distinct[i + 1].type,
                  date: distinct[i + 1].date,
                  edate: distinct[i].edate,
                  yValue: distinct[i + 1].yValue,
                  xValue: distinct[i + 1].xValue,
                  colorCode: distinct[i + 1].colorCode,
                  label: distinct[i + 1].label,
                  xValueStr: distinct[i + 1].xValueStr,
                ));
              }
            } else if (date1.hour == date2.hour &&
                distinct[i].label == distinct[i + 1].label) {
              yVal = yVal + distinct[i].yValue;
              count++;
            } else {
              yVal = yVal + distinct[i].yValue;
              count++;
              yVal = yVal / count;
              dayAvgList.add(GraphItemData(
                type: distinct[i].type,
                date: distinct[i].date,
                edate: distinct[i].edate,
                yValue: yVal,
                xValue: distinct[i].xValue,
                colorCode: distinct[i].colorCode,
                label: distinct[i].label,
                xValueStr: distinct[i].xValueStr,
              ));
              yVal = 0;
              count = 0;
            }
          }

          distinct = dayAvgList;
        }
      }

      if (distinct.isNotEmpty) graphItemList = distinct;

      makeOrRefreshChartWidget(context);
    }
    isShowLoadingScreen = false;
    isSwap = false;

    Future.delayed(Duration(milliseconds: 400)).then((value) {
      if (mounted) {
        setState(() {});
      }
    });
  }

  ///Added by: Shahzad
  ///Added on: 19/10/2020
  /// this method is used to get the light and deep sleep data
  Future getSleepData() async {
    if (userId == null) {
      await getPreference();
    }

    if (startDate != null && endDate != null) {
      late int unit;
      if (UnitExtension.getUnitType(weightUnit) == UnitTypeEnum.metric) {
        unit = 1;
      }
      if (UnitExtension.getUnitType(weightUnit) == UnitTypeEnum.imperial) {
        unit = 2;
      }
      val = await GraphDataManager().graphManager(
        userId: userId,
        startDate: startDate,
        endDate: endDate,
        selectedGraphTypes: sleepGraphTypeList,
        isEnableNormalize: graphWindow.normalization,
        unitType: unit,
      );

      var distinct = <GraphItemData>[];
      for (var d in val) {
        GraphItemData value = val
            .where((element) {
              return (element.label == d.label &&
                  element.xValueStr == d.xValueStr &&
                  element.yValue == d.yValue);
            })
            .toList()
            .last;
        if (!distinct.contains(value)) {
          distinct.add(value);
        }
      }
      val = distinct;
      //makeOrRefreshChartWidget();
    }
//    isShowLoadingScreen = false;
//
//    Future.delayed(Duration(milliseconds: 400)).then((value) {
//      if (this.mounted) {
//        setState(() {});
//      }
//    });
  }

  /// Static List for background Color
  List<BloodPressure> bpStaticList = [
    BloodPressure(xValue: 16, color: HexColor.fromHex('#9F2DBC'), yValue: 70),
    BloodPressure(xValue: 12, color: HexColor.fromHex('#BD78CE'), yValue: 60),
    BloodPressure(xValue: 10, color: HexColor.fromHex('#D3A5DF'), yValue: 50),
    BloodPressure(xValue: 8, color: HexColor.fromHex('#00AFAA'), yValue: 40),
    BloodPressure(
        xValue: 4,
        yValue: 25,
        color: HexColor.fromHex('#99D9D9').withOpacity(0.5)),
  ];

  List<BloodPressure> addBpData() {
    List<BloodPressure> bpList = [];
    bpList.addAll(bpStaticList);

    if (bloodPressure.xValue == 0.0 &&
        bloodPressure.yValue == 0.0 &&
        measurementModelList.isNotEmpty) {
      bloodPressure.xValue = measurementModelList[0].dbp != null
          ? measurementModelList[0].dbp!.toDouble()
          : 0.0;
      bloodPressure.yValue = measurementModelList[0].sbp != null
          ? measurementModelList[0].sbp!.toDouble()
          : 0.0;
      bloodPressure.date = measurementModelList[0].date;
      selectedMeasurement = measurementModelList[0];
    }

    for (int i = 0; i < measurementModelList.length; i++) {
      if (measurementModelList[i].sbp != null &&
          measurementModelList[i].sbp != 0 &&
          measurementModelList[i].dbp != null &&
          measurementModelList[i].dbp != 0) {
        BloodPressure bpData = BloodPressure(
            xValue:
                (measurementModelList[i].dbp! - 40) / 5, // to maintain x axis
            yValue:
                (measurementModelList[i].sbp! - 40) / 2, // to maintain y axis
            color: (bloodPressure.xValue == measurementModelList[i].dbp! &&
                    bloodPressure.yValue == measurementModelList[i].sbp!)
                ? bloodPressure.color
                : Colors.red,
            pointID: 'point',
            date: measurementModelList[i].date);
        bpList.add(bpData);
      }
    }
    return bpList;
  }

  getMeasurementData() async {
    bloodPressure.xValue = 0.0;
    bloodPressure.yValue = 0.0;
    measurementModelList = await dbHelper.getMeasurementHistoryDataForBpGraph(
        userId, startDate.toString(), endDate.toString());
    // measurementModelList = removeHourlyHrData(measurementModelList);
    int totalDbp = 0;
    int totalSbp = 0;
    measurementModelList.forEach((element) {
      totalDbp += element.dbp!;
      totalSbp += element.sbp!;
    });
    avgSbp = 0;
    avgDbp = 0;
    if (measurementModelList.isNotEmpty) {
      avgSbp = totalSbp ~/ measurementModelList.length;
      avgDbp = totalDbp ~/ measurementModelList.length;
      bpIndex = 0;
    }
    await bpCandleGraphData(measurementModelList);
  }

  /// added by: Shahzad
  /// added on: 30th dec 2020
  /// this function gives a list of data according to date
  Future<void> bpCandleGraphData(
      List<MeasurementHistoryModel> measurementModelList) async {
    bpCandleData = [];
    int times = 0;
    if (widget.graphTab == GraphTab.day) {
      times = 24;
    } else {
      times = endDate.difference(startDate).inDays;
    }
    for (int i = 0; i < times; i++) {
      List<MeasurementHistoryModel> temp = [];
      if (widget.graphTab == GraphTab.day) {
        DateTime day = startDate.add(Duration(hours: i + 1));
        // DateTime day = startDate.add(Duration(days: i));
        temp = measurementModelList
            .where((element) =>
                DateTime.parse(element.date!).hour == day.hour &&
                (element.dbp! < 200 && element.dbp! > 50) &&
                (element.sbp! < 200 && element.sbp! > 50))
            .toList();
      } else {
        DateTime day = startDate.add(Duration(days: i));
        temp = measurementModelList
            .where((element) =>
                DateTime.parse(element.date!).day == day.day &&
                (element.dbp! < 200 && element.dbp! > 50) &&
                (element.sbp! < 200 && element.sbp! > 50))
            .toList();
      }
      BPGraph data = BPGraph(dbpMax: 0, dbpMin: 0, sbpMax: 0, sbpMin: 0);
      if (temp != null && temp.length > 0) {
        Map minMax = await getMinMax(temp);
        data.sbpMin = minMax['sbpMin'];
        data.sbpMax = minMax['sbpMax'];
        data.dbpMin = minMax['dbpMin'];
        data.dbpMax = minMax['dbpMax'];
        if (data.sbpMin < data.dbpMax) {
          data.dbpMax = data.sbpMin;
        }
        bpCandleData.add(data);
      } else {
        bpCandleData.add(data);
      }
    }
  }

  /// added by: Shahzad
  /// added on: 30th dec 2020
  /// this function returns max and min of sys and dia
  Future<Map> getMinMax(List<MeasurementHistoryModel> temp) async {
    int sbpMax = 50;
    int dbpMax = 50;
    int sbpMin = 201;
    int dbpMin = 201;
    temp.forEach((element) {
      if (element.dbp! > dbpMax) {
        dbpMax = element.dbp!;
      }
      if (element.dbp! < dbpMin) {
        dbpMin = element.dbp!;
      }
      if (element.sbp! > sbpMax) {
        sbpMax = element.sbp!;
      }
      if (element.sbp! < sbpMin) {
        sbpMin = element.sbp!;
      }
    });
    Map tempMap = {
      'sbpMax': sbpMax,
      'sbpMin': sbpMin,
      'dbpMax': dbpMax,
      'dbpMin': dbpMin,
    };
    return tempMap;
  }

  List<MeasurementHistoryModel> removeHourlyHrData(
      List<MeasurementHistoryModel> data) {
    data.removeWhere((element) {
      try {
        return (element == null ||
            (element.ppg == null && element.ecg == null) ||
            (element.ppg!.length == 0 && element.ecg!.length == 0) ||
            (element.ppg!.length == 1 && element.ecg!.length == 1) ||
            (element.ppg![0] == null || element.ecg![0] == null) ||
            (element.ppg![0].isEmpty && element.ecg![0].isEmpty) ||
            (element.ppg![0] == '[]' && element.ecg![0] == '[]') ||
            (element.dbp! > 120 || element.sbp! > 180));
      } catch (e) {
        print('exception in graph window screen $e');
        return false;
      }
      return false;
    });

    List<MeasurementHistoryModel> distinctList = [];

    data.forEach((element) {
      var isExist = distinctList.any((data) {
        try {
          return element == data ||
              element.ppg.toString() == data.ppg.toString() ||
              element.ecg.toString() == data.ecg.toString();
        } catch (e) {
          print('exception in graph window screen $e');
          return false;
        }
      });
      if (!isExist) {
        distinctList.add(element);
      }
    });

    data = distinctList;

//      List<MeasurementHistoryModel> tempReverseList = [];
//      int j = 0;
//      for(int i = data.length; i >= 0; i--){
//        tempReverseList[j] = data[i];
//        j++;
//      }
//      data = tempReverseList;
    //endregion
    print('data $data');
    return data;
  }

  List<chart.Series<BloodPressure, double>> generateBPLineChartData() {
    List<BloodPressure> bPList = addBpData();

    return List.generate(bPList.length, (index) {
      BloodPressure typeModel = bPList[index];
      List<BloodPressure> bpDataList = [];

      if (index < 5) {
        /// adding static BP list values
        bpDataList.add(typeModel);
        BloodPressure temp = BloodPressure(
            xValue: 0, yValue: typeModel.yValue, color: typeModel.color);
        bpDataList.add(temp);
      } else {
        /// adding BP list values
        bpDataList.add(typeModel);
        BloodPressure demo = BloodPressure(
            xValue: 0, yValue: typeModel.yValue, color: Colors.transparent);
        bpDataList.add(demo);
      }

      /// assigning the final list to the Graph.
      return chart.Series<BloodPressure, double>(
        id: 'demo',
        colorFn: (BloodPressure data, __) => chart.Color(
            a: data.color.alpha,
            r: data.color.red,
            g: data.color.green,
            b: data.color.blue),
        domainFn: (BloodPressure data, _) => data.xValue,
        measureFn: (BloodPressure data, _) => data.yValue,
        data: bpDataList,
      )..setAttribute(chart.rendererIdKey, 'demo');
    });
  }

  List<chart.Series<GraphItemData, num>> generateLineChartData(
      {String? field}) {
    List<GraphTypeModel> newGraphTypeList = [];
    if (field != null) {
      if (field == 'hr') {
        newGraphTypeList = [
          graphTypeList.firstWhere(
              (element) => element.fieldName == DefaultGraphItem.hr.fieldName)
        ];
      } else if (field == 'step') {
        newGraphTypeList = [
          graphTypeList.firstWhere(
              (element) => element.fieldName == DefaultGraphItem.step.fieldName)
        ];
      } else if (field == 'calories') {
        newGraphTypeList = [
          graphTypeList.firstWhere((element) =>
              element.fieldName == DefaultGraphItem.calories.fieldName)
        ];
      } else if (field == 'weight') {
        newGraphTypeList = [
          graphTypeList.firstWhere((element) =>
              element.fieldName == DefaultGraphItem.weight.fieldName)
        ];
      } else if (field == 'oxygen') {
        newGraphTypeList = [
          graphTypeList.firstWhere((element) =>
              element.fieldName == DefaultGraphItem.oxygen.fieldName)
        ];
      } else if (field == 'temperature') {
        newGraphTypeList = [
          graphTypeList.firstWhere((element) =>
              element.fieldName == DefaultGraphItem.temperature.fieldName)
        ];
      }
    } else {
      newGraphTypeList = selectedGraphTypeList;
    }
    return List.generate(newGraphTypeList.length, (index) {
      GraphTypeModel typeModel = newGraphTypeList[index];
      String colorCode = '#009C92';
      if (typeModel.color.isNotEmpty) {
        colorCode = typeModel.color;
      }
      if (colorCode.length > 4 && colorCode[3] == 'f' && colorCode[4] == 'f') {
        colorCode = colorCode.replaceRange(3, 5, '');
      }
      Color materialColor = HexColor.fromHex(colorCode);

      List<GraphItemData> list = [];
      list = graphItemList
          .where((element) => element.label == typeModel.fieldName)
          .toList();
      list.sort(
          (GraphItemData a, GraphItemData b) => a.xValue.compareTo(b.xValue));

      return chart.Series<GraphItemData, double>(
        id: typeModel.id.toString(),
        colorFn: (GraphItemData data, __) => chart.Color(
            a: materialColor.alpha,
            r: materialColor.red,
            g: materialColor.green,
            b: materialColor.blue),
        domainFn: (GraphItemData data, _) => data.xValue,
        measureFn: (GraphItemData data, _) => data.yValue,
        data: list,
      )..setAttribute(chart.rendererIdKey, typeModel.fieldName);
    });
  }

  List<chart.Series<SleepGraphData, num>> generateSleepChartData(
      String graphType) {
    if (graphType == 'hr') {
      sleepChartTypeList = [
        graphTypeList.firstWhere(
            (element) => element.fieldName == DefaultGraphItem.hr.fieldName)
      ];
    } else if (graphType == 'Oxygen') {
      sleepChartTypeList = [
        graphTypeList.firstWhere(
            (element) => element.fieldName == DefaultGraphItem.oxygen.fieldName)
      ];
    } else if (graphType == 'Temperature') {
      sleepChartTypeList = [
        graphTypeList.firstWhere((element) =>
            element.fieldName == DefaultGraphItem.temperature.fieldName)
      ];
    }
    return List.generate(sleepChartTypeList.length, (index) {
      GraphTypeModel typeModel = sleepChartTypeList[index];
      String colorCode = '#009C92';
      if (typeModel.color.isNotEmpty) {
        colorCode = typeModel.color;
      }
      if (colorCode.length > 4 && colorCode[3] == 'f' && colorCode[4] == 'f') {
        colorCode = colorCode.replaceRange(3, 5, '');
      }

      sleepList = makeListOfTypeByHours() ?? [];
      if (sleepList.isEmpty) {
        hrList = [];
        oxygenList = [];
        tempList = [];
      }
      List<SleepGraphData> sleepDataList = [];
      if (graphType == 'hr') {
        sleepDataList = getSleepChartList(hrList, colorCode, graphType);
      } else if (graphType == 'Oxygen') {
        sleepDataList = getSleepChartList(oxygenList, colorCode, graphType);
      } else {
        sleepDataList = getSleepChartList(tempList, colorCode, graphType);
      }

      return chart.Series<SleepGraphData, double>(
        id: typeModel.id.toString(),
        colorFn: (SleepGraphData data, __) => chart.Color(
            a: data.color.alpha,
            r: data.color.red,
            g: data.color.green,
            b: data.color.blue),
        domainFn: (SleepGraphData data, _) => data.xValue,
        measureFn: (SleepGraphData data, _) => data.yValue,
        data: sleepDataList,
      )..setAttribute(chart.rendererIdKey, typeModel.fieldName);
    });
  }

  /// Added by Shahzad
  /// Added on 23rd Aug
  /// mapping sleep data to SleepGraphData model
  /// then this model will be assigned to graph
  List<SleepGraphData> getSleepChartList(
      List<GraphItemData> list, String colorCode, String graphType) {
    Color materialColor = HexColor.fromHex(colorCode);
    if (list.isNotEmpty) {
      for (var i = 0; i < list.length; i++) {
        if (list[i].xValue < 12) {
          list[i].xValue += 24;
        }
      }
    }
    var sleepGraphData = <SleepGraphData>[];
    if (sleepList.isNotEmpty) {
      if (sleepList.last['time'].split(':')[1] != '00') {
        if (int.parse(sleepList.last['time'].split(':')[0]) <
            int.parse(sleepList.first['time'].split(':')[0])) {
          sleepAxisCount = int.parse(sleepList.last['time'].split(':')[0]) +
              24 -
              int.parse(sleepList.first['time'].split(':')[0]) +
              1;
        } else {
          sleepAxisCount = int.parse(sleepList.last['time'].split(':')[0]) -
              int.parse(sleepList.first['time'].split(':')[0]) +
              1;
        }
      } else {
        if (int.parse(sleepList.last['time'].split(':')[0]) <
            int.parse(sleepList.first['time'].split(':')[0])) {
          sleepAxisCount = int.parse(sleepList.last['time'].split(':')[0]) +
              24 -
              int.parse(sleepList.first['time'].split(':')[0]);
        } else {
          sleepAxisCount = int.parse(sleepList.last['time'].split(':')[0]) -
              int.parse(sleepList.first['time'].split(':')[0]);
        }
      }

      for (int i = 0; i < sleepList.length; i++) {
        int flag = 0;
        for (int j = 0; j < list.length; j++) {
          if (list[j].xValueStr == sleepList[i]['time'].split(':')[0] &&
              sleepList[i]['time'].split(':')[1] == '00') {
            list[j].type = sleepList[i]['type'];
            list[j].xValue = stringTimeToDouble(sleepList[i]['time']);
            flag = 1;
            break;
          }
        }
        if (flag == 0) {
          GraphItemData temp = GraphItemData(
            xValue: stringTimeToDouble(sleepList[i]['time']),
            yValue: 0,
            type: sleepList[i]['type'],
            xValueStr: '',
            label: '',
            date: '',
          );
          list.add(temp);
        }
      }

      list.sort(
          (GraphItemData a, GraphItemData b) => a.xValue.compareTo(b.xValue));
      startSleepTime = stringTimeToDouble(sleepList.first['time']);
      List<GraphItemData> tempGraphList = [];
      for (var i = 0; i < list.length; i++) {
        if (list[i].xValue >= startSleepTime) {
          tempGraphList.add(list[i]);
        }
      }

      for (var i = 0; i < tempGraphList.length; i++) {
        if (i == 0 && tempGraphList[i].type != null) {
          if (tempGraphList[i].yValue == 0) {
            tempGraphList[i].yValue = graphType == 'hr'
                ? 72
                : graphType == 'Oxygen'
                    ? 95
                    : 37;
          }
        } else if (tempGraphList[i].type == null) {
          if (i == 0) {
            {
              tempGraphList[i].type = '5';
            }
            if (tempGraphList[i].yValue == 0) {
              tempGraphList[i].yValue = graphType == 'hr'
                  ? 72
                  : graphType == 'Oxygen'
                      ? 95
                      : 37;
            }
          } else {
            for (var k = i; k >= 0; k--) {
              if (tempGraphList[k].type != null) {
                tempGraphList[i].type = tempGraphList[k].type;
                break;
              }
            }
          }
        }
      }
      var timeDifference = stringTimeToDouble(sleepList.first['time']).toInt();
      tempGraphList.first.xValue = tempGraphList.first.xValue - timeDifference;
      for (int i = 1; i < tempGraphList.length; i++) {
        tempGraphList[i].xValue = tempGraphList[i].xValue - timeDifference;
        if (tempGraphList[i].yValue == 0) {
          tempGraphList[i].yValue = tempGraphList[i - 1].yValue;
        }
      }
      print(tempGraphList);
      tempGraphList.forEach((element) {
        SleepGraphData data = SleepGraphData(
            xValue: element.xValue,
            yValue: element.yValue,
            color: getColorByType(element.type ?? '0'));
        sleepGraphData.add(data);
      });
    } else {
      list.forEach((element) {
        SleepGraphData data = SleepGraphData(
            xValue: element.xValue,
            yValue: element.yValue,
            color: materialColor);
        sleepGraphData.add(data);
      });
    }
    return sleepGraphData;
  }

  List<chart.Series<GraphItemData, num>> generateWeekAndMonthSleepHrChartData(
      String fieldName) {
    List<GraphTypeModel> graphWeekTypeList = [];
    if (fieldName == 'sleep') {
      sleepGraphTypeList = [
        graphTypeList.firstWhere((element) =>
            element.fieldName == DefaultGraphItem.lightSleep.fieldName),
        graphTypeList.firstWhere((element) =>
            element.fieldName == DefaultGraphItem.deepSleep.fieldName)
      ];
      graphWeekTypeList = sleepGraphTypeList;
    } else if (fieldName == 'Oxygen') {
      sleepChartTypeList = [
        graphTypeList.firstWhere(
            (element) => element.fieldName == DefaultGraphItem.oxygen.fieldName)
      ];
      graphWeekTypeList = sleepChartTypeList;
    } else if (fieldName == 'Temperature') {
      sleepChartTypeList = [
        graphTypeList.firstWhere((element) =>
            element.fieldName == DefaultGraphItem.temperature.fieldName)
      ];
      graphWeekTypeList = sleepChartTypeList;
    } else {
      sleepChartTypeList = [
        graphTypeList.firstWhere(
            (element) => element.fieldName == DefaultGraphItem.hr.fieldName)
      ];
      graphWeekTypeList = sleepChartTypeList;
    }
    return List.generate(graphWeekTypeList.length, (index) {
      GraphTypeModel typeModel = graphWeekTypeList[index];
      String colorCode = '#009C92';
      if (typeModel.color != null && typeModel.color.isNotEmpty) {
        colorCode = typeModel.color;
      }
      if (colorCode.length > 4 && colorCode[3] == 'f' && colorCode[4] == 'f') {
        colorCode = colorCode.replaceRange(3, 5, '');
      }
      Color materialColor = HexColor.fromHex(colorCode);

      List<GraphItemData> list = [];
      if (fieldName == 'sleep') {
        list = sleepItemList
            .where((element) => element.label == typeModel.fieldName)
            .toList();
      } else {
        list = graphItemList
            .where((element) => element.label == typeModel.fieldName)
            .toList();
      }
      list.sort(
          (GraphItemData a, GraphItemData b) => a.xValue.compareTo(b.xValue));

      return chart.Series<GraphItemData, int>(
        id: typeModel.id.toString(),
        colorFn: (GraphItemData data, __) => chart.Color(
            a: materialColor.alpha,
            r: materialColor.red,
            g: materialColor.green,
            b: materialColor.blue),
        domainFn: (GraphItemData data, _) => data.xValue.toInt(),
        measureFn: (GraphItemData data, _) => data.yValue,
        data: list,
      )..setAttribute(chart.rendererIdKey, typeModel.fieldName);
    });
  }

  List<chart.Series<GraphItemData, String>>
      generateWeekAndMonthSleepHrBarChartData(String fieldName) {
    List<GraphTypeModel> graphWeekTypeList = [];
    if (fieldName == 'sleep') {
      sleepGraphTypeList = [
        graphTypeList.firstWhere(
            (element) => element.fieldName == DefaultGraphItem.awake.fieldName),
        graphTypeList.firstWhere((element) =>
            element.fieldName == DefaultGraphItem.deepSleep.fieldName),
        graphTypeList.firstWhere((element) =>
            element.fieldName == DefaultGraphItem.lightSleep.fieldName),
      ];
      graphWeekTypeList = sleepGraphTypeList;
    } else {
      sleepChartTypeList = [
        graphTypeList.firstWhere(
            (element) => element.fieldName == DefaultGraphItem.hr.fieldName)
      ];
      graphWeekTypeList = sleepChartTypeList;
    }
    return List.generate(graphWeekTypeList.length, (index) {
      GraphTypeModel typeModel = graphWeekTypeList[index];
      String colorCode = '#009C92';
      if (typeModel.color != null && typeModel.color.isNotEmpty) {
        colorCode = typeModel.color;
      }
      var materialColor = HexColor.fromHex(colorCode);

      List<GraphItemData> list = [];
      if (fieldName == 'sleep') {
        list = sleepItemList
            .where((element) => element.label == typeModel.fieldName)
            .toList();
      } else {
        list = graphItemList
            .where((element) => element.label == typeModel.fieldName)
            .toList();
      }
      list.sort(
          (GraphItemData a, GraphItemData b) => a.xValue.compareTo(b.xValue));
      return chart.Series<GraphItemData, String>(
        id: typeModel.id.toString(),
        colorFn: (GraphItemData data, __) => chart.Color(
            a: materialColor.alpha,
            r: materialColor.red,
            g: materialColor.green,
            b: materialColor.blue),
        domainFn: (GraphItemData data, _) => data.xValue.toInt().toString(),
        measureFn: (GraphItemData data, _) => data.yValue,
        data: list,
      );
    });
  }

  List<chart.Series<GraphItemData, String>> generateBarChartData() {
    return List.generate(selectedGraphTypeList.length, (index) {
      GraphTypeModel typeModel = selectedGraphTypeList[index];
      String colorCode = '#009C92';
      if (typeModel.color != null && typeModel.color.isNotEmpty) {
        colorCode = typeModel.color;
      }
      var materialColor = HexColor.fromHex(colorCode);

      List<GraphItemData> list = [];
      list = graphItemList
          .where((element) => element.label == typeModel.fieldName)
          .toList();
      if (typeModel != null && typeModel.fieldName == 'sleepAllTime') {
        sleepList = [
          graphTypeList.firstWhere((element) =>
              element.fieldName == DefaultGraphItem.lightSleep.fieldName),
          graphTypeList.firstWhere((element) =>
              element.fieldName == DefaultGraphItem.deepSleep.fieldName),
        ];
        getSleepData();
      }
      list.sort(
          (GraphItemData a, GraphItemData b) => a.xValue.compareTo(b.xValue));
      return chart.Series<GraphItemData, String>(
        id: typeModel.id.toString(),
        colorFn: (GraphItemData data, __) => chart.Color(
            a: materialColor.alpha,
            r: materialColor.red,
            g: materialColor.green,
            b: materialColor.blue),
        domainFn: (GraphItemData data, _) => data.xValue.toInt().toString(),
        measureFn: (GraphItemData data, _) => data.yValue,
        data: list,
      );
    });
  }

  Future getPreference() async {
    if (preferences == null) {
      preferences = await SharedPreferences.getInstance();
    }
    userId = preferences!.getString(Constants.prefUserIdKeyInt) ?? '';
    selectedGraphTypeList.addAll(graphWindow.selectedType);
    removeDeletedType();
    return Future.value();
  }

  makeOrRefreshChartWidget(BuildContext context) {
    makeDefaultValueForXAxisToBarChart();
    graphItemList.sort(
        (GraphItemData a, GraphItemData b) => a.xValue.compareTo(b.xValue));
    print(
        'graphItemX ${graphItemList.map((e) => double.parse(e.xValueStr)).toList().toString()}');
    print(
        'graphItemY ${graphItemList.map((e) => e.yValue).toList().toString()}');
    print(
        'sbp ${graphItemList.where((e) => e.label == 'approxSBP').toList().map((e) => e.yValue).toList().toString()}');
    print(
        'dbp ${graphItemList.where((e) => e.label == 'approxDBP').toList().map((e) => e.yValue).toList().toString()}');

    setWeightModel();

    if (isSwap) {
      var temp = selectedGraphTypeList[0];
      selectedGraphTypeList[0] = selectedGraphTypeList[1];
      selectedGraphTypeList[1] = temp;
      var title1 = setGraphTitle(selectedGraphTypeList, 0);
      var title2 = setGraphTitle(selectedGraphTypeList, 1);
      graphTypeName1 = title1;
      graphTypeName2 = title2;
      graphWindow.title = '$graphTypeName1 Vs $graphTypeName2';
    }

    //region line chart
    try {
      lineChartSeries = generateLineChartData();
      lineChartSeries.forEach((element) {
        print('Line chart : ');
        element.data.forEach((element) {
          print('${element.label} : ${element.xValue} : ${element.yValue}');
        });
      });
      if (lineChartSeries.length > 1) {
        if (isNormalizationEnable) {
          lineChartSeries[1]
            ..setAttribute(
              chart.measureAxisIdKey,
              chart.Axis.secondaryMeasureAxisId,
            );
        }
      }
      interpolationInLineChart();
      var radius = 2.0;
      if (selectedGraphTypeList.isNotEmpty) {
        if (selectedGraphTypeList[0].fieldName == 'approxHr') {
          radius = 1.0;
        } else if (selectedGraphTypeList.length > 1 &&
            selectedGraphTypeList[1].fieldName == 'approxHr') {
          radius = 1.0;
        }
      }
      // if (lineChartSeries.length > 1) {
      lineChartWidget = chart.LineChart(
        lineChartSeries,
        animate: true,
        customSeriesRenderers:
            List.generate(selectedGraphTypeList.length, (index) {
          return chart.LineRendererConfig(
            customRendererId: selectedGraphTypeList[index].fieldName,
            includeArea: false,
            stacked: true,
            includePoints: true,
            includeLine: true,
            roundEndCaps: true,
            radiusPx: radius,
            strokeWidthPx: 1.0,
          );
        }),
        primaryMeasureAxis: chart.NumericAxisSpec(
          renderSpec: chart.GridlineRendererSpec(
              labelStyle: chart.TextStyleSpec(
                  fontSize: 10,
                  color: Theme.of(context).brightness == Brightness.dark
                      ? chart.MaterialPalette.white
                      : chart.MaterialPalette.black)),
          tickProviderSpec: chart.BasicNumericTickProviderSpec(
              desiredTickCount: 5, zeroBound: true),
        ),
        secondaryMeasureAxis: chart.NumericAxisSpec(
          renderSpec: chart.GridlineRendererSpec(
              labelStyle: chart.TextStyleSpec(
                  fontSize: 10,
                  color: Theme.of(context).brightness == Brightness.dark
                      ? chart.MaterialPalette.white
                      : chart.MaterialPalette.black)),
          tickProviderSpec: chart.BasicNumericTickProviderSpec(
            desiredTickCount: 5,
            zeroBound: true,
          ),
        ),
        domainAxis: chart.NumericAxisSpec(
          tickProviderSpec: chart.BasicNumericTickProviderSpec(
            zeroBound: true,
            desiredTickCount: xAxisCount(),
          ),
          tickFormatterSpec: chart.BasicNumericTickFormatterSpec(
            _formatterXAxis,
          ),
          renderSpec: chart.GridlineRendererSpec(
            tickLengthPx: 0,
            labelOffsetFromAxisPx: 10,
            labelStyle: chart.TextStyleSpec(
                fontSize: 10,
                color: Theme.of(context).brightness == Brightness.dark
                    ? chart.MaterialPalette.white
                    : chart.MaterialPalette.black),
          ),
          viewport: chart.NumericExtents(0, xAxisCount() - 1),
        ),
      );
      // } else {
      //   interpolationInLineChart();
      //   lineChartWidget  =  CustomLineChart(
      //     graphTab: graphTab,
      //     list: graphItemList,
      //     isInterpolationEnable: isInterpolationEnable,
      //     selectedGraphTypeList: selectedGraphTypeList,
      //     selectedDate: widget.selectedDate,
      //   );
      //   //region temp commented for check graph
      //   /*lineChartWidget = chart.LineChart(
      //     lineChartSeries,
      //     animate: true,
      //     customSeriesRenderers: [
      //       selectedGraphTypeList.length == 1
      //           ? chart.LineRendererConfig(
      //               customRendererId: selectedGraphTypeList[0].fieldName,
      //               includeArea: false,
      //               stacked: true,
      //               includePoints: true,
      //               includeLine: true,
      //               roundEndCaps: true,
      //               radiusPx: 1.0,
      //               strokeWidthPx: 1.0,
      //             )
      //           : []
      //     ],
      //     primaryMeasureAxis: chart.NumericAxisSpec(
      //       renderSpec: chart.GridlineRendererSpec(
      //           labelStyle: chart.TextStyleSpec(
      //               fontSize: 10,
      //               color: Theme.of(context).brightness == Brightness.dark
      //                   ? chart.MaterialPalette.white
      //                   : chart.MaterialPalette.black)),
      //       tickProviderSpec: chart.BasicNumericTickProviderSpec(
      //           desiredTickCount: 5, zeroBound: true),
      //     ),
      //     secondaryMeasureAxis: chart.NumericAxisSpec(
      //       renderSpec: chart.GridlineRendererSpec(
      //           labelStyle: chart.TextStyleSpec(
      //               fontSize: 10,
      //               color: Theme.of(context).brightness == Brightness.dark
      //                   ? chart.MaterialPalette.white
      //                   : chart.MaterialPalette.black)),
      //       tickProviderSpec: chart.BasicNumericTickProviderSpec(
      //         desiredTickCount: 5,
      //         zeroBound: false,
      //       ),
      //     ),
      //     domainAxis: chart.NumericAxisSpec(
      //       tickProviderSpec: chart.BasicNumericTickProviderSpec(
      //         zeroBound: false,
      //         desiredTickCount: xAxisCount(),
      //       ),
      //       tickFormatterSpec: chart.BasicNumericTickFormatterSpec(
      //         _formatterXAxis,
      //       ),
      //       renderSpec: chart.GridlineRendererSpec(
      //         tickLengthPx: 0,
      //         labelOffsetFromAxisPx: 10,
      //         labelStyle: chart.TextStyleSpec(
      //             fontSize: 10,
      //             color: Theme.of(context).brightness == Brightness.dark
      //                 ? chart.MaterialPalette.white
      //                 : chart.MaterialPalette.black),
      //       ),
      //       viewport: chart.NumericExtents(0, xAxisCount() - 1),
      //     ),
      //   );*/
      //   //endregion
      // }
    } catch (e) {
      print('exception in graph window screen $e');
    }

    //endregion

    //region bar chart
    try {
      barChartSeries = generateBarChartData();
      print(barChartSeries);
      if (barChartSeries.length > 1) {
        if (isNormalizationEnable) {
          barChartSeries[1]
            ..setAttribute(
              chart.measureAxisIdKey,
              chart.Axis.secondaryMeasureAxisId,
            );
        }
      }
//      double maxXValue  = graphItemList.reduce((current, next) => current.xValue > next.xValue?current:next).xValue;
      graphItemList.sort(
          (GraphItemData a, GraphItemData b) => a.xValue.compareTo(b.xValue));
      barChartWidget = chart.BarChart(
        barChartSeries,
        animate: true,
        selectionModels: [
          chart.SelectionModelConfig(
            changedListener: (chart.SelectionModel model) {
              double xPos = -1.0;
              int count = 1;
              barChartSeries.forEach((element) {
                if (model.hasDatumSelection &&
                    model.selectedSeries[0].data[0].label == 'sleepAllTime') {
                  double value = 0.0;
                  value = model.selectedSeries[0]
                      .measureFn(model.selectedDatum[0].index)!
                      .toDouble();
                  var data = model.selectedSeries[0].data;
                  for (int i = 0; i < data.length; i++) {
                    if (data[i].yValue == value) {
                      xPos = data[i].xValue;
                      break;
                    }
                  }
                  if (count == 1) showDataDialogue(xPos);
                  count++;
                }
              });
            },
          )
        ],
        barGroupingType: chart.BarGroupingType.grouped,
        primaryMeasureAxis: chart.NumericAxisSpec(
          renderSpec: chart.GridlineRendererSpec(
              labelStyle: chart.TextStyleSpec(
                  fontSize: 10,
                  color: Theme.of(context).brightness == Brightness.dark
                      ? chart.MaterialPalette.white
                      : chart.MaterialPalette.black)),
          tickProviderSpec: chart.BasicNumericTickProviderSpec(
            desiredTickCount: 5,
            zeroBound: false,
            dataIsInWholeNumbers: false,
          ),
//          viewport: NumericExtents(0,100)
        ),
        secondaryMeasureAxis: chart.NumericAxisSpec(
          renderSpec: chart.GridlineRendererSpec(
              labelStyle: chart.TextStyleSpec(
                  fontSize: 10,
                  color: Theme.of(context).brightness == Brightness.dark
                      ? chart.MaterialPalette.white
                      : chart.MaterialPalette.black)),
          tickProviderSpec: chart.BasicNumericTickProviderSpec(
            desiredTickCount: 5,
            zeroBound: false,
          ),
        ),
        domainAxis: chart.OrdinalAxisSpec(
          tickProviderSpec:
              chart.StaticOrdinalTickProviderSpec(graphItemList.map((e) {
            return chart.TickSpec(e.xValue.toInt().toString(),
                label: _formatterXAxis(e.xValue.toInt()),
                style: chart.TextStyleSpec(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? chart.MaterialPalette.white
                        : chart.MaterialPalette.black
//                    label: e.xValue.toInt() % 2 ==0?e.xValue.toInt().toString():'',
                    ));
          }).toList()),
          renderSpec: chart.GridlineRendererSpec(
            tickLengthPx: 0,
            labelOffsetFromAxisPx: 10,
            labelStyle: chart.TextStyleSpec(
                fontSize: 10,
                color: Theme.of(context).brightness == Brightness.dark
                    ? chart.MaterialPalette.white
                    : chart.MaterialPalette.black),
          ),
        ),
      );
    } catch (e) {
      print('exception in graph window screen $e');
    }

    try {
      lineAndBarChartSeries = generateLineChartData();
      if (lineAndBarChartSeries.isNotEmpty &&
          lineAndBarChartSeries.length > 1) {
        lineAndBarChartSeries[1]
          ..setAttribute(
            chart.rendererIdKey,
            'customLine',
          );
      }
      if (lineAndBarChartSeries.isNotEmpty &&
          lineAndBarChartSeries.length > 1) {
        if (isNormalizationEnable) {
          lineAndBarChartSeries[1]
            ..setAttribute(
              chart.measureAxisIdKey,
              chart.Axis.secondaryMeasureAxisId,
            );
        }
      }
//      double maxXValue  = graphItemList.reduce((current, next) => current.xValue > next.xValue?current:next).xValue;
      graphItemList.sort(
          (GraphItemData a, GraphItemData b) => a.xValue.compareTo(b.xValue));
      lineAndBarChartWidget = chart.LineChart(
        lineAndBarChartSeries,
        animate: true,
        customSeriesRenderers: [
          chart.LineRendererConfig(
            customRendererId: selectedGraphTypeList[0].fieldName,
            includeArea: false,
            stacked: true,
            includePoints: true,
            includeLine: true,
            roundEndCaps: true,
            radiusPx: 2.0,
            strokeWidthPx: 1.0,
          ),
          chart.BarRendererConfig(
            customRendererId: 'customLine',
            //strokeWidthPx: 1.0,
          ),
        ],
        primaryMeasureAxis: chart.NumericAxisSpec(
          renderSpec: chart.GridlineRendererSpec(
              labelStyle: chart.TextStyleSpec(
                  fontSize: 10,
                  color: Theme.of(context).brightness == Brightness.dark
                      ? chart.MaterialPalette.white
                      : chart.MaterialPalette.black)),
          tickProviderSpec: chart.BasicNumericTickProviderSpec(
              desiredTickCount: 5, zeroBound: false),
        ),
        secondaryMeasureAxis: chart.NumericAxisSpec(
          renderSpec: chart.GridlineRendererSpec(
              labelStyle: chart.TextStyleSpec(
                  fontSize: 10,
                  color: Theme.of(context).brightness == Brightness.dark
                      ? chart.MaterialPalette.white
                      : chart.MaterialPalette.black)),
          tickProviderSpec: chart.BasicNumericTickProviderSpec(
            desiredTickCount: 5,
            zeroBound: false,
          ),
        ),
        domainAxis: chart.NumericAxisSpec(
          tickProviderSpec: chart.BasicNumericTickProviderSpec(
            zeroBound: false,
            desiredTickCount: xAxisCount(),
          ),
          tickFormatterSpec: chart.BasicNumericTickFormatterSpec(
            _formatterXAxis,
          ),
          renderSpec: chart.GridlineRendererSpec(
            tickLengthPx: 0,
            labelOffsetFromAxisPx: 10,
            labelStyle: chart.TextStyleSpec(
                fontSize: 10,
                color: Theme.of(context).brightness == Brightness.dark
                    ? chart.MaterialPalette.white
                    : chart.MaterialPalette.black),
          ),
          viewport: chart.NumericExtents(0, xAxisCount() - 1),
        ),
      );
//      chart.BarChart(
//        lineAndBarChartSeries,
//        animate: true,
//        customSeriesRenderers: [
//          chart.LineRendererConfig(
//              customRendererId: 'customLine')
//        ],
//        barGroupingType: chart.BarGroupingType.grouped,
//        primaryMeasureAxis: chart.NumericAxisSpec(
//          renderSpec: chart.GridlineRendererSpec(labelStyle: chart.TextStyleSpec(fontSize: 10, color: Theme.of(context).brightness == Brightness.dark ? chart.MaterialPalette.white : chart.MaterialPalette.black)),
//          tickProviderSpec: chart.BasicNumericTickProviderSpec(
//            desiredTickCount: 5,
//            zeroBound: true,
//          ),
////          viewport: NumericExtents(0,100)
//        ),
//        secondaryMeasureAxis: chart.NumericAxisSpec(
//          renderSpec: chart.GridlineRendererSpec(labelStyle: chart.TextStyleSpec(fontSize: 10, color: Theme.of(context).brightness == Brightness.dark ? chart.MaterialPalette.white : chart.MaterialPalette.black)),
//          tickProviderSpec: chart.BasicNumericTickProviderSpec(
//            desiredTickCount: 5,
//            zeroBound: true,
//          ),
//        ),
//        domainAxis: chart.OrdinalAxisSpec(
//          tickProviderSpec:
//          chart.StaticOrdinalTickProviderSpec(graphItemList.map((e) {
//            return chart.TickSpec(
//              e.xValue.toInt().toString(),
//              label: _formatterXAxis(e.xValue.toInt()),
////                    label: e.xValue.toInt() % 2 ==0?e.xValue.toInt().toString():'',
//            );
//          }).toList()),
//        ),
//      );
    } catch (e) {
      print('exception in graph window screen $e');
    }
    //endregion

    try {
      calorieLineChartSeries = generateLineChartData(field: 'calories');
      if (selectedGraphTypeList != null &&
          widget.graphWindow.defaultGraph &&
          selectedGraphTypeList.length > 1 &&
          selectedGraphTypeList[0].fieldName == 'WeightSum') {
        lineChartWeightSeries = generateLineChartData(field: 'weight');
        interpolateWeightGraph(lineChartWeightSeries);
        lineChartWidget = chart.LineChart(
          lineChartWeightSeries,
          animate: true,
          customSeriesRenderers:
              List.generate(selectedGraphTypeList.length, (index) {
            return chart.LineRendererConfig(
                customRendererId: selectedGraphTypeList[index].fieldName,
                includeArea: true,
                stacked: true,
                includePoints: true,
                includeLine: true,
                roundEndCaps: true,
                radiusPx: 2.0,
                strokeWidthPx: 1.0,
                areaOpacity: Theme.of(context).brightness == Brightness.dark
                    ? 0.8
                    : 0.2);
          }),
          primaryMeasureAxis: chart.NumericAxisSpec(
            renderSpec: chart.GridlineRendererSpec(
                labelStyle: chart.TextStyleSpec(
                    fontSize: 10,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? chart.MaterialPalette.white
                        : chart.MaterialPalette.black)),
            tickProviderSpec: chart.BasicNumericTickProviderSpec(
                desiredTickCount: 5, zeroBound: false),
          ),
          domainAxis: chart.NumericAxisSpec(
            tickProviderSpec: chart.BasicNumericTickProviderSpec(
              zeroBound: false,
              desiredTickCount: xAxisCount(),
            ),
            tickFormatterSpec: chart.BasicNumericTickFormatterSpec(
              _formatterXAxis,
            ),
            renderSpec: chart.GridlineRendererSpec(
              tickLengthPx: 0,
              labelOffsetFromAxisPx: 10,
              labelStyle: chart.TextStyleSpec(
                  fontSize: 10,
                  color: Theme.of(context).brightness == Brightness.dark
                      ? chart.MaterialPalette.white
                      : chart.MaterialPalette.black),
            ),
            viewport: chart.NumericExtents(0, xAxisCount() - 1),
          ),
        );

        calorieLineChart = chart.LineChart(
          calorieLineChartSeries,
          animate: true,
          customSeriesRenderers: List.generate(1, (index) {
            return chart.LineRendererConfig(
                customRendererId: selectedGraphTypeList[1].fieldName,
                includeArea: true,
                stacked: true,
                includePoints: true,
                includeLine: true,
                roundEndCaps: true,
                radiusPx: 2.0,
                strokeWidthPx: 1.0,
                areaOpacity: Theme.of(context).brightness == Brightness.dark
                    ? 0.8
                    : 0.3);
          }),
          primaryMeasureAxis: chart.NumericAxisSpec(
            renderSpec: chart.GridlineRendererSpec(
                labelStyle: chart.TextStyleSpec(
                    fontSize: 10,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? chart.MaterialPalette.white
                        : chart.MaterialPalette.black)),
            tickProviderSpec: chart.BasicNumericTickProviderSpec(
                desiredTickCount: 5, zeroBound: false),
          ),
          domainAxis: chart.NumericAxisSpec(
            tickProviderSpec: chart.BasicNumericTickProviderSpec(
              zeroBound: false,
              desiredTickCount: xAxisCount(),
            ),
            tickFormatterSpec: chart.BasicNumericTickFormatterSpec(
              _formatterXAxis,
            ),
            renderSpec: chart.GridlineRendererSpec(
              tickLengthPx: 0,
              labelOffsetFromAxisPx: 10,
              labelStyle: chart.TextStyleSpec(
                  fontSize: 10,
                  color: Theme.of(context).brightness == Brightness.dark
                      ? chart.MaterialPalette.white
                      : chart.MaterialPalette.black),
            ),
            viewport: chart.NumericExtents(0, xAxisCount() - 1),
          ),
        );
      }
    } catch (e) {
      print('exception in graph window screen $e');
    }

    try {
      lineChartOxygenSeries = generateSleepChartData('Oxygen');
      if (selectedGraphTypeList != null &&
          widget.graphWindow.defaultGraph &&
          selectedGraphTypeList.length > 1 &&
          selectedGraphTypeList[1].fieldName == 'sleepAllTime') {
        lineChartTemperatureSeries = generateSleepChartData('Temperature');
        if (tempUnit == 1) {
          lineChartTemperatureSeries[0].data.forEach((element) {
            if (element.yValue != 0) {
              element.yValue = element.yValue * (9 / 5) + 32;
            }
          });
        }
        tempLineChartWidget = chart.LineChart(
          lineChartTemperatureSeries,
          animate: false,
          customSeriesRenderers: [
            chart.LineRendererConfig(
              customRendererId: selectedGraphTypeList[0].fieldName,
              includeArea: true,
              stacked: true,
              includePoints: false,
              includeLine: true,
              roundEndCaps: true,
              radiusPx: 2.0,
              strokeWidthPx: 1.0,
              areaOpacity:
                  Theme.of(context).brightness == Brightness.dark ? 0.8 : 0.3,
            )
          ],
          primaryMeasureAxis: chart.NumericAxisSpec(
            renderSpec: chart.GridlineRendererSpec(
                labelStyle: chart.TextStyleSpec(
                    fontSize: 10,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? chart.MaterialPalette.white
                        : chart.MaterialPalette.black)),
            tickProviderSpec: chart.BasicNumericTickProviderSpec(
                desiredTickCount: 6, zeroBound: true),
          ),
          domainAxis: chart.NumericAxisSpec(
            tickProviderSpec: chart.BasicNumericTickProviderSpec(
                zeroBound: false, desiredTickCount: sleepAxisCount),
            tickFormatterSpec: chart.BasicNumericTickFormatterSpec(
              _formattXAxis,
            ),
            renderSpec: chart.GridlineRendererSpec(
              tickLengthPx: 0,
              labelOffsetFromAxisPx: 10,
              labelStyle: chart.TextStyleSpec(
                  fontSize: 10,
                  color: Theme.of(context).brightness == Brightness.dark
                      ? chart.MaterialPalette.white
                      : chart.MaterialPalette.black),
            ),
            viewport: chart.NumericExtents(0.0, sleepAxisCount),
          ),
        );

        oxygenLineChartWidget = chart.LineChart(
          lineChartOxygenSeries,
          animate: false,
          customSeriesRenderers: [
            chart.LineRendererConfig(
              customRendererId: selectedGraphTypeList[0].fieldName,
              includeArea: true,
              stacked: true,
              includePoints: false,
              includeLine: true,
              roundEndCaps: true,
              radiusPx: 2.0,
              strokeWidthPx: 1.0,
              areaOpacity:
                  Theme.of(context).brightness == Brightness.dark ? 0.8 : 0.3,
            )
          ],
          primaryMeasureAxis: chart.NumericAxisSpec(
            renderSpec: chart.GridlineRendererSpec(
                labelStyle: chart.TextStyleSpec(
                    fontSize: 10,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? chart.MaterialPalette.white
                        : chart.MaterialPalette.black)),
            tickProviderSpec: chart.BasicNumericTickProviderSpec(
                desiredTickCount: 6, zeroBound: true),
          ),
          domainAxis: chart.NumericAxisSpec(
            tickProviderSpec: chart.BasicNumericTickProviderSpec(
                zeroBound: false, desiredTickCount: sleepAxisCount),
            tickFormatterSpec: chart.BasicNumericTickFormatterSpec(
              _formattXAxis,
            ),
            renderSpec: chart.GridlineRendererSpec(
              tickLengthPx: 0,
              labelOffsetFromAxisPx: 10,
              labelStyle: chart.TextStyleSpec(
                  fontSize: 10,
                  color: Theme.of(context).brightness == Brightness.dark
                      ? chart.MaterialPalette.white
                      : chart.MaterialPalette.black),
            ),
            viewport: chart.NumericExtents(0.0, sleepAxisCount),
          ),
        );
      }
    } catch (e) {
      print('exception in graph window screen $e');
    }

    try {
      if (selectedGraphTypeList != null &&
          widget.graphWindow.defaultGraph &&
          selectedGraphTypeList.length > 1 &&
          (selectedGraphTypeList[0].fieldName == 'approxHr' ||
              selectedGraphTypeList[0].fieldName == 'Oxygen' ||
              selectedGraphTypeList[0].fieldName == 'Temperature')) {
        if (widget.graphTab == GraphTab.week ||
            widget.graphTab == GraphTab.month ||
            selectedGraphTypeList[1].fieldName == 'step') {
          if (selectedGraphTypeList[1].fieldName == 'step') {
            lineChartSeries = generateLineChartData(field: 'hr');
          } else if (selectedGraphTypeList[0].fieldName == 'Oxygen') {
            lineChartSeries = generateWeekAndMonthSleepHrChartData('Oxygen');
          } else if (selectedGraphTypeList[0].fieldName == 'Temperature') {
            lineChartSeries =
                generateWeekAndMonthSleepHrChartData('Temperature');
          } else {
            lineChartSeries = generateWeekAndMonthSleepHrChartData('hr');
          }

          lineChartWidget = chart.LineChart(
            lineChartSeries,
            animate: true,
            customSeriesRenderers:
                List.generate(selectedGraphTypeList.length, (index) {
              return chart.LineRendererConfig(
                  customRendererId: selectedGraphTypeList[index].fieldName,
                  includeArea: true,
                  stacked: true,
                  includePoints: true,
                  includeLine: true,
                  roundEndCaps: true,
                  radiusPx: 1.0,
                  strokeWidthPx: 1.0,
                  areaOpacity: Theme.of(context).brightness == Brightness.dark
                      ? 0.8
                      : 0.3);
            }),
            primaryMeasureAxis: chart.NumericAxisSpec(
              renderSpec: chart.GridlineRendererSpec(
                  labelStyle: chart.TextStyleSpec(
                      fontSize: 10,
                      color: Theme.of(context).brightness == Brightness.dark
                          ? chart.MaterialPalette.white
                          : chart.MaterialPalette.black)),
              tickProviderSpec: chart.BasicNumericTickProviderSpec(
                  desiredTickCount: 5, zeroBound: false),
            ),
            domainAxis: chart.NumericAxisSpec(
              tickProviderSpec: chart.BasicNumericTickProviderSpec(
                zeroBound: false,
                desiredTickCount: xAxisCount(),
              ),
              tickFormatterSpec: chart.BasicNumericTickFormatterSpec(
                _formatterXAxis,
              ),
              renderSpec: chart.GridlineRendererSpec(
                tickLengthPx: 0,
                labelOffsetFromAxisPx: 10,
                labelStyle: chart.TextStyleSpec(
                    fontSize: 10,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? chart.MaterialPalette.white
                        : chart.MaterialPalette.black),
              ),
              viewport: chart.NumericExtents(0, xAxisCount() - 1),
            ),
          );

          stepLineChartSeries = generateLineChartData(field: 'step');
          sleepLineChartSeries = generateWeekAndMonthSleepHrChartData('sleep');
          sleepLineChartWidget = chart.LineChart(
            sleepLineChartSeries,
            animate: true,
            customSeriesRenderers:
                List.generate(sleepGraphTypeList.length, (index) {
              return chart.LineRendererConfig(
                  customRendererId: sleepGraphTypeList[index].fieldName,
                  includeArea: true,
                  stacked: true,
                  includePoints: true,
                  includeLine: true,
                  roundEndCaps: true,
                  radiusPx: 2.0,
                  strokeWidthPx: 1.0,
                  areaOpacity: Theme.of(context).brightness == Brightness.dark
                      ? 0.8
                      : 0.3);
            }),
            primaryMeasureAxis: chart.NumericAxisSpec(
              renderSpec: chart.GridlineRendererSpec(
                  labelStyle: chart.TextStyleSpec(
                      fontSize: 10,
                      color: Theme.of(context).brightness == Brightness.dark
                          ? chart.MaterialPalette.white
                          : chart.MaterialPalette.black)),
              tickProviderSpec: chart.BasicNumericTickProviderSpec(
                  desiredTickCount: 6, zeroBound: false),
            ),
            domainAxis: chart.NumericAxisSpec(
              tickProviderSpec: chart.BasicNumericTickProviderSpec(
                zeroBound: false,
                desiredTickCount: xAxisCount(),
              ),
              tickFormatterSpec: chart.BasicNumericTickFormatterSpec(
                _formatterXAxis,
              ),
              renderSpec: chart.GridlineRendererSpec(
                tickLengthPx: 0,
                labelOffsetFromAxisPx: 10,
                labelStyle: chart.TextStyleSpec(
                    fontSize: 10,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? chart.MaterialPalette.white
                        : chart.MaterialPalette.black),
              ),
              viewport: chart.NumericExtents(0, xAxisCount() - 1),
            ),
          );

          stepLineChartWidget = chart.LineChart(
            stepLineChartSeries,
            animate: true,
            customSeriesRenderers: List.generate(1, (index) {
              return chart.LineRendererConfig(
                  customRendererId: selectedGraphTypeList[1].fieldName,
                  includeArea: true,
                  stacked: true,
                  includePoints: true,
                  includeLine: true,
                  roundEndCaps: true,
                  radiusPx: 2.0,
                  strokeWidthPx: 1.0,
                  areaOpacity: Theme.of(context).brightness == Brightness.dark
                      ? 0.8
                      : 0.1);
            }),
            primaryMeasureAxis: chart.NumericAxisSpec(
              renderSpec: chart.GridlineRendererSpec(
                  labelStyle: chart.TextStyleSpec(
                      fontSize: 10,
                      color: Theme.of(context).brightness == Brightness.dark
                          ? chart.MaterialPalette.white
                          : chart.MaterialPalette.black)),
              tickProviderSpec: chart.BasicNumericTickProviderSpec(
                  desiredTickCount: 5, zeroBound: false),
            ),
            domainAxis: chart.NumericAxisSpec(
              tickProviderSpec: chart.BasicNumericTickProviderSpec(
                zeroBound: false,
                desiredTickCount: xAxisCount(),
              ),
              tickFormatterSpec: chart.BasicNumericTickFormatterSpec(
                _formatterXAxis,
              ),
              renderSpec: chart.GridlineRendererSpec(
                tickLengthPx: 0,
                labelOffsetFromAxisPx: 10,
                labelStyle: chart.TextStyleSpec(
                    fontSize: 10,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? chart.MaterialPalette.white
                        : chart.MaterialPalette.black),
              ),
              viewport: chart.NumericExtents(0, xAxisCount() - 1),
            ),
          );
        } else {
          sleepHRchartSeries = generateSleepChartData('hr');
          // interpolationInSleepLineChart();
          lineChartWidget = chart.LineChart(
            sleepHRchartSeries,
            animate: false,
            customSeriesRenderers: [
              chart.LineRendererConfig(
                customRendererId: selectedGraphTypeList[0].fieldName,
                includeArea: true,
                stacked: true,
                includePoints: false,
                includeLine: true,
                roundEndCaps: true,
                radiusPx: 2.0,
                strokeWidthPx: 1.0,
                areaOpacity:
                    Theme.of(context).brightness == Brightness.dark ? 0.8 : 0.3,
              )
            ],
            primaryMeasureAxis: chart.NumericAxisSpec(
              renderSpec: chart.GridlineRendererSpec(
                  labelStyle: chart.TextStyleSpec(
                      fontSize: 10,
                      color: Theme.of(context).brightness == Brightness.dark
                          ? chart.MaterialPalette.white
                          : chart.MaterialPalette.black)),
              tickProviderSpec: chart.BasicNumericTickProviderSpec(
                  desiredTickCount: 6, zeroBound: true),
            ),
            domainAxis: chart.NumericAxisSpec(
              tickProviderSpec: chart.BasicNumericTickProviderSpec(
                  zeroBound: false, desiredTickCount: sleepAxisCount),
              tickFormatterSpec: chart.BasicNumericTickFormatterSpec(
                _formattXAxis,
              ),
              renderSpec: chart.GridlineRendererSpec(
                tickLengthPx: 0,
                labelOffsetFromAxisPx: 10,
                labelStyle: chart.TextStyleSpec(
                    fontSize: 10,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? chart.MaterialPalette.white
                        : chart.MaterialPalette.black),
              ),
              viewport: chart.NumericExtents(0.0, sleepAxisCount),
            ),
          );
        }
      }
    } catch (e) {
      print('exception in graph window screen $e');
    }

    try {
      if (selectedGraphTypeList != null &&
          selectedGraphTypeList.length > 1 &&
          selectedGraphTypeList[0].fieldName == 'approxHr' &&
          selectedGraphTypeList[1].fieldName == 'sleepAllTime') {
        if (widget.graphTab == GraphTab.week ||
            widget.graphTab == GraphTab.month) {
          barChartSeries = generateWeekAndMonthSleepHrBarChartData('hr');
//      double maxXValue  = graphItemList.reduce((current, next) => current.xValue > next.xValue?current:next).xValue;
          graphItemList.sort((GraphItemData a, GraphItemData b) =>
              a.xValue.compareTo(b.xValue));
          barChartWidget = chart.BarChart(
            barChartSeries,
            animate: true,
            barGroupingType: chart.BarGroupingType.grouped,
            primaryMeasureAxis: chart.NumericAxisSpec(
              renderSpec: chart.GridlineRendererSpec(
                  labelStyle: chart.TextStyleSpec(
                      fontSize: 10,
                      color: Theme.of(context).brightness == Brightness.dark
                          ? chart.MaterialPalette.white
                          : chart.MaterialPalette.black)),
              tickProviderSpec: chart.BasicNumericTickProviderSpec(
                desiredTickCount: 5,
                zeroBound: true,
              ),
//          viewport: NumericExtents(0,100)
            ),
            domainAxis: chart.OrdinalAxisSpec(
              tickProviderSpec:
                  chart.StaticOrdinalTickProviderSpec(graphItemList.map((e) {
                return chart.TickSpec(
                  e.xValue.toInt().toString(),
                  label: _formatterXAxis(e.xValue.toInt()),
//                    label: e.xValue.toInt() % 2 ==0?e.xValue.toInt().toString():'',
                );
              }).toList()),
            ),
          );

          sleepBarChartSeries =
              generateWeekAndMonthSleepHrBarChartData('sleep');
//      double maxXValue  = graphItemList.reduce((current, next) => current.xValue > next.xValue?current:next).xValue;
          sleepItemList.sort((GraphItemData a, GraphItemData b) =>
              a.xValue.compareTo(b.xValue));
          sleepBarChartWidget = chart.BarChart(
            sleepBarChartSeries,
            animate: true,
            barGroupingType: chart.BarGroupingType.groupedStacked,
            primaryMeasureAxis: chart.NumericAxisSpec(
              renderSpec: chart.GridlineRendererSpec(
                  labelStyle: chart.TextStyleSpec(
                      fontSize: 10,
                      color: Theme.of(context).brightness == Brightness.dark
                          ? chart.MaterialPalette.white
                          : chart.MaterialPalette.black)),
              tickProviderSpec: chart.BasicNumericTickProviderSpec(
                desiredTickCount: 6,
                zeroBound: true,
              ),
//          viewport: NumericExtents(0,100)
            ),
            domainAxis: chart.OrdinalAxisSpec(
              tickProviderSpec:
                  chart.StaticOrdinalTickProviderSpec(sleepItemList.map((e) {
                return chart.TickSpec(
                  e.xValue.toInt().toString(),
                  label: _formatterXAxis(e.xValue.toInt()),
//                    label: e.xValue.toInt() % 2 ==0?e.xValue.toInt().toString():'',
                );
              }).toList()),
            ),
          );
        }
      }
    } catch (e) {
      print('exception in graph window screen $e');
    }
    if (selectedGraphTypeList != null &&
        selectedGraphTypeList.length > 1 &&
        selectedGraphTypeList.first.fieldName == 'approxDBP' &&
        selectedGraphTypeList.last.fieldName == 'approxSBP') {
      try {
        bpLineChartSeries = generateBPLineChartData();
        bpLineChartSeries.forEach((element) {
          print('Line chart : ');
          element.data.forEach((element) {
            print(element.yValue);
          });
        });

        for (int i = 0; i < bpLineChartSeries.length; i++) {
          if (i > 4) {
            bpLineChartSeries[i]
              ..setAttribute(
                chart.rendererIdKey,
                'customLine',
              );
          }
        }

        bpLineChartWidget = chart.LineChart(
          bpLineChartSeries,
          animate: false,
          customSeriesRenderers: [
            chart.LineRendererConfig(
              customRendererId: 'demo',
              includeArea: true,
              stacked: false,
              includePoints: false,
              includeLine: false,
              roundEndCaps: true,
              radiusPx: 5.0,
              strokeWidthPx: 1.0,
              areaOpacity: 0.8,
              //layoutPaintOrder: 0,
            ),
            chart.LineRendererConfig(
              customRendererId: 'customLine',
              includeArea: false,
              stacked: false,
              includePoints: true,
              includeLine: false,
              roundEndCaps: true,
              radiusPx: 5.0,
              strokeWidthPx: 1.0,
              areaOpacity: 1,
            )
          ],
          selectionModels: [
            chart.SelectionModelConfig(
                type: chart.SelectionModelType.info,
                changedListener: (chart.SelectionModel model) {
                  for (var element in model.selectedDatum) {
                    if (model.hasDatumSelection &&
                        element.datum.pointID == 'point') {
                      showBPSelectedItemData(
                          element.datum.xValue, element.datum.yValue);
                      break;
                    }
                  }
                })
          ],
          primaryMeasureAxis: chart.NumericAxisSpec(
            renderSpec: chart.GridlineRendererSpec(
                labelStyle: chart.TextStyleSpec(
                    fontSize: 10,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? chart.MaterialPalette.white
                        : chart.MaterialPalette.black)),
            tickProviderSpec: chart.BasicNumericTickProviderSpec(
                desiredTickCount: 15, zeroBound: true),
            tickFormatterSpec: chart.BasicNumericTickFormatterSpec(
              _formatterYAxis,
            ),
          ),
          domainAxis: chart.NumericAxisSpec(
            tickProviderSpec: chart.BasicNumericTickProviderSpec(
              zeroBound: true,
              desiredTickCount: 17,
            ),
            tickFormatterSpec: chart.BasicNumericTickFormatterSpec(
              _formatterAxis,
            ),
            renderSpec: chart.GridlineRendererSpec(
              tickLengthPx: 0,
              labelOffsetFromAxisPx: 10,
              labelStyle: chart.TextStyleSpec(
                  fontSize: 10,
                  color: Theme.of(context).brightness == Brightness.dark
                      ? chart.MaterialPalette.white
                      : chart.MaterialPalette.black),
            ),
            //viewport: chart.NumericExtents(1.0, 17),
          ),
        );
      } catch (e) {
        print('exception in graph window screen $e');
      }
    }

    interpolationInLineChart();

    // Future.delayed(Duration(milliseconds: 100)).then((value) {
    //   if (this.mounted) {
    //     setState(() {});
    //   }
    // });
  }

  void interpolationInLineChart() {
    bool isHeartRateGraph = false;
    try {
      isHeartRateGraph = selectedGraphTypeList
          .any((element) => element.fieldName == DefaultGraphItem.hr.fieldName);
    } catch (e) {
      print('exception in graph window screen $e');
    }
    try {
      if (isHeartRateGraph || isInterpolationEnable || weightLabel.isNotEmpty) {
        lineChartSeries.forEach(
          (element) {
            element.data.removeWhere((element) => element.yValue < 1);
          },
        );
        print(lineChartSeries);
      }
    } catch (e) {
      print('exception in graph window screen $e');
    }
  }

  void interpolationInSleepLineChart() {
    try {
      sleepHRchartSeries.forEach(
        (element) {
          element.data.removeWhere((element) => element.yValue < 1);
        },
      );
      print(sleepHRchartSeries);
    } catch (e) {
      print('exception in graph window screen $e');
    }
  }

  showBPSelectedItemData(var xValue, var yValue) {
    bloodPressure.xValue = (xValue * 5) + 40;
    bloodPressure.yValue = (yValue * 2) + 40;
    makeOrRefreshChartWidget(context);
  }

  updatePrefForSelectedItem() async {
    graphWindow.selectedType = selectedGraphTypeList;
    if (preferences == null) {
      preferences = await SharedPreferences.getInstance();
    }
    var listOfPages =
        preferences!.getStringList(Constants.prefKeyForGraphPages);
    if (listOfPages != null && listOfPages.isNotEmpty) {
      List<GraphSharedPreferenceManagerModel> listOfPagesFromPreference =
          listOfPages
              .map((e) =>
                  GraphSharedPreferenceManagerModel.fromMap(jsonDecode(e)))
              .toList();
      int index = listOfPagesFromPreference.indexWhere((element) =>
          element.index == widget.graphSharedPreferenceManagerModel.index);

      GraphSharedPreferenceManagerModel graphSharedPreferenceManagerModel =
          listOfPagesFromPreference[index];
      int i = graphSharedPreferenceManagerModel.windowList
          .indexWhere((element) => element?.index == widget.graphWindow.index);

      graphSharedPreferenceManagerModel.windowList[i] = graphWindow;

      preferences!.setStringList(Constants.prefKeyForGraphPages,
          listOfPagesFromPreference.map((e) => jsonEncode(e.toMap())).toList());
    }
  }

  makeDefaultValueForXAxisToBarChart() {
    int loopLength = 0;
    if (graphTab != null) {
      if (graphTab == GraphTab.day) {
        loopLength = 24;
      } else if (graphTab == GraphTab.week) {
        loopLength = 7;
      } else if (graphTab == GraphTab.month) {
        loopLength = DateTime(startDate.day, startDate.month + 1, 0).day;
      }
    }
    List<GraphItemData> unAvailableXValues = [];
    selectedGraphTypeList.forEach((element) {
      for (int i = 1; i <= loopLength; i++) {
        bool valueIsAlreadyExistForThisAxis = graphItemList
            .any((e) => e.label == element.fieldName && e.xValue.toInt() == i);
        if (!valueIsAlreadyExistForThisAxis) {
          GraphItemData emptyGraphItem = GraphItemData(
              label: element.fieldName,
              yValue: 0,
              xValue: i.toDouble(),
              xValueStr: i.toInt().toString());
          unAvailableXValues.add(emptyGraphItem);
        }
      }
    });
    graphItemList.addAll(unAvailableXValues);
    /*try {
      graphItemList.removeWhere((element) => element.yValue == 0);
      graphItemList.insert(0,GraphItemData(
          label: graphItemList.first.label,
          yValue: 0,
          xValue: 1.toDouble(),
          xValueStr: 1.toInt().toString(),
      ));
    } catch (e) {
      print('exception in graph window screen $e');
    }*/
    List<GraphItemData> unAvailableXValuesOfSleep = [];
    sleepGraphTypeList.forEach((element) {
      for (int i = 1; i <= loopLength; i++) {
        bool valueIsAlreadyExistForThisAxis = sleepItemList
            .any((e) => e.label == element.fieldName && e.xValue.toInt() == i);
        if (!valueIsAlreadyExistForThisAxis) {
          GraphItemData emptyGraphItem = GraphItemData(
              label: element.fieldName,
              yValue: 0,
              xValue: i.toDouble(),
              xValueStr: i.toInt().toString());
          unAvailableXValuesOfSleep.add(emptyGraphItem);
        }
      }
    });

    sleepItemList.addAll(unAvailableXValuesOfSleep);
  }

  void refresh(selectedDate) {
    // widget.graphWindow.onChangeDate!.value = null;
    isShowLoadingScreen = true;
    setDates(selectedDate);
    getSleepDayData();
    getData();
  }

  ///Added by: Shahzad
  ///Added on: 19/10/2020
  /// this method shows the information of light and deep sleep of particular event
  showDataDialogue(double xPos) {
    List lightSleepList = [];
    List deepSleepList = [];
    val.forEach((element) {
      if (element.label == 'allTime') {
        lightSleepList.add(element);
      } else {
        deepSleepList.add(element);
      }
    });
    double deepSleepValue = 0.0;
    double lightSleepValue = 0.0;

    lightSleepList.forEach((element) {
      if (element.xValue == xPos) {
        lightSleepValue = element.yValue;
      }
    });

    deepSleepList.forEach((element) {
      if (element.xValue == xPos) {
        deepSleepValue = element.yValue;
      }
    });

    var dialog = AlertDialog(
      title: Text(
          StringLocalization.of(context).getText(StringLocalization.sleepData)),
      content: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Text(
                '${stringLocalization.getText(StringLocalization.lightSleep)} : ${lightSleepValue.toStringAsFixed(2)}'),
            SizedBox(height: 15.0.h),
            Text(
                '${stringLocalization.getText(StringLocalization.deepSleep)} : ${deepSleepValue.toStringAsFixed(2)}'),
            SizedBox(height: 15.0.h),
            Row(
              children: <Widget>[
                Expanded(
                  child: RaisedBtn(
                    onPressed: () {
                      if (context != null) {
                        Navigator.of(context, rootNavigator: true).pop();
                      }
                    },
                    text: StringLocalization.of(context)
                        .getText(StringLocalization.ok),
                    elevation: 0,
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
    showDialog(
        context: context,
        useRootNavigator: true,
        builder: (context) => dialog,
        barrierDismissible: false);
  }

  void deleteDialog() {
    var dialog = CustomDialog(
      title: stringLocalization.getText(StringLocalization.delete),
      subTitle: stringLocalization.getText(StringLocalization.deleteInfo),
      onClickNo: () {
        if (context != null) {
          Navigator.of(context, rootNavigator: true).pop();
        }
      },
      onClickYes: () {
        widget.onClickRemove();
        Navigator.of(context, rootNavigator: true).pop();
      },
      maxLine: 2,
    );
    // var dialog = Dialog(
    //     shape: RoundedRectangleBorder(
    //       borderRadius: BorderRadius.circular(10),
    //     ),
    //     elevation: 0,
    //     backgroundColor: Theme.of(context).brightness == Brightness.dark
    //         ? HexColor.fromHex('#111B1A')
    //         : AppColor.backgroundColor,
    //     child: Container(
    //         decoration: BoxDecoration(
    //             color: Theme.of(context).brightness == Brightness.dark
    //                 ? HexColor.fromHex('#111B1A')
    //                 : AppColor.backgroundColor,
    //             borderRadius: BorderRadius.circular(10),
    //             boxShadow: [
    //               BoxShadow(
    //                 color: Theme.of(context).brightness == Brightness.dark
    //                     ? HexColor.fromHex('#D1D9E6').withOpacity(0.1)
    //                     : HexColor.fromHex('#DDE3E3').withOpacity(0.3),
    //                 blurRadius: 5,
    //                 spreadRadius: 0,
    //                 offset: Offset(-5, -5),
    //               ),
    //               BoxShadow(
    //                 color: Theme.of(context).brightness == Brightness.dark
    //                     ? HexColor.fromHex('#000000').withOpacity(0.75)
    //                     : HexColor.fromHex('#384341').withOpacity(0.9),
    //                 blurRadius: 5,
    //                 spreadRadius: 0,
    //                 offset: Offset(5, 5),
    //               ),
    //             ]),
    //         padding: EdgeInsets.only(top: 27, left: 16, right: 10),
    //         height: 188,
    //         width: 309,
    //         child:
    //             Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    //           Padding(
    //               padding: const EdgeInsets.symmetric(horizontal: 10),
    //               child: Text(
    //                 stringLocalization.getText(StringLocalization.delete),
    //                 style: TextStyle(
    //                     fontSize: 20,
    //                     fontWeight: FontWeight.bold,
    //                     color: Theme.of(context).brightness == Brightness.dark
    //                         ? HexColor.fromHex('#FFFFFF').withOpacity(0.87)
    //                         : HexColor.fromHex('#384341')),
    //               )),
    //           Container(
    //               padding: EdgeInsets.only(
    //                 top: 16,
    //               ),
    //               child: Column(
    //                 crossAxisAlignment: CrossAxisAlignment.start,
    //                 children: <Widget>[
    //                   Padding(
    //                     padding: const EdgeInsets.symmetric(horizontal: 10),
    //                     child: SizedBox(
    //                       height: 55,
    //                       child: Body1AutoText(
    //                           text: stringLocalization
    //                               .getText(StringLocalization.deleteInfo),
    //                           maxLine: 2,
    //                           fontSize: 16,
    //                           color: Theme.of(context).brightness ==
    //                                   Brightness.dark
    //                               ? HexColor.fromHex('#FFFFFF')
    //                                   .withOpacity(0.87)
    //                               : HexColor.fromHex('#384341')),
    //                     ),
    //                   ),
    //                   SizedBox(
    //                     height: 15,
    //                   ),
    //                   Row(
    //                     mainAxisAlignment: MainAxisAlignment.end,
    //                     children: [
    //                       Align(
    //                         alignment: Alignment.bottomCenter,
    //                         child: FlatButton(
    //                           onPressed: () {
    //                             if (context != null) {
    //                               Navigator.of(context, rootNavigator: true)
    //                                   .pop();
    //                             }
    //                           },
    //                           child: Text(
    //                             stringLocalization
    //                                 .getText(StringLocalization.cancel)
    //                                 .toUpperCase(),
    //                             style: TextStyle(
    //                               fontWeight: FontWeight.bold,
    //                               fontSize: 14,
    //                               color: HexColor.fromHex('#00AFAA'),
    //                             ),
    //                           ),
    //                         ),
    //                       ),
    //                       Align(
    //                         alignment: Alignment.bottomRight,
    //                         child: FlatButton(
    //                           onPressed: () {
    //                             widget.onClickRemove();
    //                             Navigator.of(context, rootNavigator: true)
    //                                 .pop();
    //                           },
    //                           child: Text(
    //                             stringLocalization
    //                                 .getText(StringLocalization.yes)
    //                                 .toUpperCase(),
    //                             style: TextStyle(
    //                               fontWeight: FontWeight.bold,
    //                               fontSize: 14,
    //                               color: HexColor.fromHex('#00AFAA'),
    //                             ),
    //                           ),
    //                         ),
    //                       ),
    //                     ],
    //                   ),
    //                 ],
    //               ))
    //         ])));
    showDialog(
        context: context,
        useRootNavigator: true,
        builder: (context) => dialog,
        barrierDismissible: false);
  }

//    void deleteDialog() {
//      var dialog = AlertDialog(
//        title: Text(StringLocalization.of(context)
//            .getText(StringLocalization.delete)
//            .toUpperCase()),
//        content: SingleChildScrollView(
//          child: Column(
//            mainAxisAlignment: MainAxisAlignment.start,
//            crossAxisAlignment: CrossAxisAlignment.stretch,
//            children: <Widget>[
//              Body1Text(
//                  text: StringLocalization.of(context)
//                      .getText(StringLocalization.deleteGraph),
//                  fontSize: 18,
//                  maxLine: 2),
//              SizedBox(height: 15.0.h),
//              Row(
//                children: <Widget>[
//                  Expanded(
//                    child: RaisedBtn(
//                      onPressed: () {
//                        if (context != null) {
//                          Navigator.of(context, rootNavigator: true).pop();
//                        }
//                      },
//                      text: StringLocalization.of(context)
//                          .getText(StringLocalization.no),
//                      elevation: 0,
//                    ),
//                  ),
//                  SizedBox(width: 100.0.w),
//                  Expanded(
//                    child: RaisedBtn(
//                      onPressed: () {
//                        widget.onClickRemove();
//                        Navigator.of(context, rootNavigator: true).pop();
//                      },
//                      text: StringLocalization.of(context)
//                          .getText(StringLocalization.yes),
//                      elevation: 0,
//                    ),
//                  ),
//                ],
//              )
//            ],
//          ),
//        ),
//      );
//      showDialog(
//          context: context,
//          useRootNavigator: true,
//          builder: (context) => dialog,
//          barrierDismissible: false);
//    }

  void getGraphTitle() {
    if (graphWindow.title != null) {
      List<String> name = graphWindow.title.split('Vs');
      if (name != null && name.isNotEmpty) {
        if (name.length == 1) {
          graphTypeName1 = name[0];
        } else {
          graphTypeName1 = name[0];
          graphTypeName2 = name[1];
        }
      }
    }
    if (selectedGraphTypeList != null && selectedGraphTypeList.isNotEmpty) {
      if (selectedGraphTypeList.length == 1) {
        color1 = selectedGraphTypeList[0].color != null
            ? HexColor.fromHex(selectedGraphTypeList[0].color)
            : Colors.black;
      } else {
        color1 = selectedGraphTypeList[0].color != null
            ? HexColor.fromHex(selectedGraphTypeList[0].color)
            : Colors.black;
        color2 = selectedGraphTypeList[1].color != null
            ? HexColor.fromHex(selectedGraphTypeList[1].color)
            : Colors.black;
      }
    }
  }

  void selectColorDialog(GraphTypeModel model, int index) {
    ui.Color selectedColor = HexColor.fromHex(model.color);
    var dialog = AlertDialog(
      title: Text(StringLocalization.of(context)
          .getText(StringLocalization.selectColor)),
      content: SingleChildScrollView(
        child: Container(
          height: 300.h,
          color: Theme.of(context).cardColor,
          child: Column(
            children: [
              Expanded(
                child: MaterialColorPicker(
                  shrinkWrap: true,
                  circleSize: 30.h,
                  colors: fullMaterialColors,
                  selectedColor: selectedColor,
                  onMainColorChange: (color) {
                    if (this.mounted) setState(() {});
                  },
                  onColorChange: (Color color) {
                    selectedColor = color;
                    if (this.mounted) setState(() {});
                  },
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                mainAxisSize: MainAxisSize.max,
                children: [
                  FlatBtn(
                    onPressed: () {
                      Navigator.of(context, rootNavigator: true).pop();
                    },
                    text: stringLocalization.getText(StringLocalization.cancel),
                    color: AppColor.black,
                  ),
                  FlatBtn(
                    onPressed: () {
                      if (index - 1 == 0) {
                        color1 = selectedColor;
                        model.color = selectedColor.toHex();
                      } else {
                        model.color = selectedColor.toHex();
                        color2 = selectedColor;
                      }
                      updatePrefForSelectedItem();
                      getData();
                      isShowLoadingScreen = true;
                      if (this.mounted) setState(() {});
                      Navigator.of(context, rootNavigator: true).pop();
                    },
                    text: stringLocalization.getText(StringLocalization.ok),
                    color: AppColor.primaryColor,
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
    showDialog(
        context: context,
        useRootNavigator: true,
        builder: (context) => dialog,
        barrierDismissible: false);
  }

  selectGraphType({required GestureTapCallback onClickOk}) {
    showDialog(
        context: context,
        useRootNavigator: true,
        builder: (context) {
          return StatefulBuilder(builder: (context, setState) {
            Widget customRadio(
                {required int index,
                required Color color,
                required String unitText}) {
              return GestureDetector(
                onTap: () {
                  chartType = index == 0
                      ? ChartType.line
                      : index == 1
                          ? ChartType.bar
                          : ChartType.pie;
                  if (mounted) setState(() {});
                },
                child: Container(
                  height: 28.h,
                  child: Row(
                    children: [
                      Container(
                        height: 28.h,
                        width: 28.h,
                        decoration: ConcaveDecoration(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(28.h)),
                            depression: 4,
                            colors: [
                              Theme.of(context).brightness == Brightness.dark
                                  ? Colors.black.withOpacity(0.8)
                                  : HexColor.fromHex('#D1D9E6'),
                              Theme.of(context).brightness == Brightness.dark
                                  ? HexColor.fromHex('#D1D9E6').withOpacity(0.1)
                                  : Colors.white,
                            ]),
                        child: Container(
                          margin: EdgeInsets.all(6.h),
                          decoration: BoxDecoration(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? HexColor.fromHex('#111B1A')
                                  : AppColor.backgroundColor,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? HexColor.fromHex('#D1D9E6')
                                          .withOpacity(0.1)
                                      : Colors.white,
                                  blurRadius: 3,
                                  spreadRadius: 0,
                                  offset: Offset(-3, -3),
                                ),
                                BoxShadow(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.black.withOpacity(0.75)
                                      : HexColor.fromHex('#D1D9E6'),
                                  blurRadius: 3,
                                  spreadRadius: 0,
                                  offset: Offset(3, 3),
                                ),
                              ]),
                          child: Container(
                              margin: EdgeInsets.all(3.h),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: color,
                              )),
                        ),
                      ),
                      SizedBox(
                        width: 9.w,
                      ),
                      unitText != ''
                          ? Flexible(
                              child: SizedBox(
                                height: 23.h,
                                child: Body1AutoText(
                                  overflow: TextOverflow.ellipsis,
                                  text: unitText,
                                  fontSize: 16.sp,
                                  minFontSize: 10,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white.withOpacity(0.6)
                                      : HexColor.fromHex('#5D6A68'),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            )
                          : Container()
                    ],
                  ),
                ),
              );
            }

            ChartType chartType2 = chartType;
            return Dialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.h),
              ),
              elevation: 0,
              backgroundColor: Theme.of(context).brightness == Brightness.dark
                  ? HexColor.fromHex('#111B1A')
                  : AppColor.backgroundColor,
              child: Container(
                decoration: BoxDecoration(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? AppColor.darkBackgroundColor
                        : AppColor.backgroundColor,
                    borderRadius: BorderRadius.circular(10.h),
                    boxShadow: [
                      BoxShadow(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? HexColor.fromHex('#D1D9E6').withOpacity(0.1)
                            : HexColor.fromHex('#DDE3E3').withOpacity(0.3),
                        blurRadius: 5,
                        spreadRadius: 0,
                        offset: Offset(-5, -5),
                      ),
                      BoxShadow(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? HexColor.fromHex('#000000').withOpacity(0.75)
                            : HexColor.fromHex('#384341').withOpacity(0.9),
                        blurRadius: 5,
                        spreadRadius: 0,
                        offset: Offset(5, 5),
                      ),
                    ]),
                padding: EdgeInsets.only(top: 27.h, left: 20.w, right: 20.w),
                // height: selectedGraphTypeList.length == 2 ? 310.h : 248.h,
                width: 309.w,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 25,
                      child: AutoSizeText(
                        StringLocalization.of(context)
                            .getText(StringLocalization.selectGraphType),
                        style: TextStyle(
                            fontSize: 20.sp,
                            fontWeight: FontWeight.bold,
                            color: Theme.of(context).brightness ==
                                    Brightness.dark
                                ? HexColor.fromHex('#FFFFFF').withOpacity(0.87)
                                : HexColor.fromHex('#384341')),
                      ),
                    ),
                    SizedBox(height: 25.0.h),
                    Container(
                      // width: MediaQuery.of(context).size.width,
                      alignment: Alignment.topLeft,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            // flex: 5,
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  GridView.builder(
                                      gridDelegate:
                                          SliverGridDelegateWithFixedCrossAxisCount(
                                        crossAxisCount: 1,
                                        childAspectRatio: 2.8,
                                      ),
                                      physics: NeverScrollableScrollPhysics(),
                                      itemCount:
                                          selectedGraphTypeList.length == 2
                                              ? graphList.length
                                              : 2,
                                      shrinkWrap: true,
                                      itemBuilder: (context, index) {
                                        return Container(
                                          height: 28.h,
                                          child: customRadio(
                                            index: index,
                                            color: index + 1 ==
                                                    (chartType2 ==
                                                            ChartType.line
                                                        ? 1
                                                        : chartType2 ==
                                                                ChartType.bar
                                                            ? 2
                                                            : 3)
                                                ? HexColor.fromHex('FF6259')
                                                : Colors.transparent,
                                            unitText: graphList[index].text,
                                          ),
                                        );
                                      })
                                ]),
                          ),
                          Expanded(
                              // flex: 5,
                              child: Padding(
                            padding: EdgeInsets.only(top: 14.h),
                            child: Column(
                              children: [
                                Row(
                                  // crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Expanded(
                                      child: SizedBox(
                                        height: 23.h,
                                        child: Body1AutoText(
                                          overflow: TextOverflow.ellipsis,
                                          text: stringLocalization
                                              .getText(StringLocalization
                                                  .interpolation)
                                              .toUpperCase(),
                                          fontSize: 14.sp,
                                          minFontSize: 8,
                                          fontWeight: FontWeight.bold,
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white.withOpacity(0.87)
                                              : HexColor.fromHex('#5D6A68'),
                                        ),
                                      ),
                                    ),
                                    Flexible(
                                      child: SizedBox(
                                        height: 23.h,
                                        child: CustomSwitch(
                                          value: isInterpolationEnable,
                                          onChanged: (value) {
                                            isInterpolationEnable = value;
                                            if (mounted) {
                                              setState(() {});
                                            }
                                          },
                                          activeColor:
                                              HexColor.fromHex('#00AFAA'),
                                          inactiveTrackColor:
                                              Theme.of(context).brightness ==
                                                      Brightness.dark
                                                  ? AppColor.darkBackgroundColor
                                                  : HexColor.fromHex('#E7EBF2'),
                                          inactiveThumbColor: Theme.of(context)
                                                      .brightness ==
                                                  Brightness.dark
                                              ? Colors.white.withOpacity(0.6)
                                              : HexColor.fromHex('#D1D9E6'),
                                          activeTrackColor:
                                              Theme.of(context).brightness ==
                                                      Brightness.dark
                                                  ? AppColor.darkBackgroundColor
                                                  : HexColor.fromHex('#E7EBF2'),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 30.h,
                                ),
                                Row(
                                  // crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Expanded(
                                      child: Body1Text(
                                        text: stringLocalization
                                            .getText(StringLocalization
                                                .graphNormalization)
                                            .toUpperCase(),
                                        fontSize: 14.sp,
                                        maxLine: 2,
                                        fontWeight: FontWeight.bold,
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white.withOpacity(0.87)
                                            : HexColor.fromHex('#5D6A68'),
                                      ),
                                    ),
                                    Flexible(
                                      child: SizedBox(
                                        height: 23.h,
                                        child: Checkbox(
                                          value: isNormalizationEnable,
                                          onChanged: (value) {
                                            isNormalizationEnable =
                                                value ?? false;
                                            if (mounted) {
                                              setState(() {});
                                            }
                                          },
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ))
                        ],
                      ),
                    ),
                    SizedBox(height: 5.h),
                    Align(
                      alignment: Alignment.bottomRight,
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: onClickOk,
                          child: Container(
                            margin: EdgeInsets.only(right: 7.w),
                            width: 30.w,
                            height: 23.h,
                            child: AutoSizeText(
                              stringLocalization
                                  .getText(StringLocalization.ok)
                                  .toUpperCase(),
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 14.sp,
                                color: HexColor.fromHex('#00AFAA'),
                              ),
                              textAlign: TextAlign.right,
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 27.h),
                  ],
                ),
              ),
            );
          });
        },
        barrierDismissible: false);
  }

  String setGraphTitle(List<GraphTypeModel> selectedGraphList, int index) {
    switch (selectedGraphTypeList[index].fieldName) {
      case 'approxSBP':
        return 'Systolic BP';
      case 'approxDBP':
        return 'Diastolic BP';
      case 'HeartRate':
        return Platform.isIOS ? 'HealthKit HR' : 'GoogleFit HR';
      case 'DiastolicBloodPressure':
        return Platform.isIOS ? 'HealthKit DBP' : 'GoogleFit DBP';
      case 'SystolicBloodPressure':
        return Platform.isIOS ? 'HealthKit SBP' : 'GoogleFit SBP';
      default:
        return selectedGraphTypeList[index].name;
    }
  }

  getSleepDayData() async {
    DateTime nextDay = DateTime(widget.selectedDate.year,
        widget.selectedDate.month, widget.selectedDate.day + 1);
    String last = DateFormat(DateUtil.yyyyMMdd).format(nextDay);
    String first = DateFormat(DateUtil.yyyyMMdd).format(widget.selectedDate);
    List<SleepInfoModel> list =
        await dbHelper.getSleepDataDateWise(first, last, userId);
    daySleepInfoModel = null;
    var distinctList = <SleepInfoModel>[];
    list.forEach((element) {
      if (element.data.isNotEmpty) {
        distinctList.add(element);
      }
    });
    list = distinctList;
    if (list.isNotEmpty && list[0].data != null && list[0].data.isNotEmpty) {
      daySleepInfoModel = list[0];
      if (daySleepInfoModel != null)
        daySleepInfoModel = trimSleep(daySleepInfoModel!);
    }

    // to get Hr data from start time of sleep to the end time of sleep.
    if (daySleepInfoModel != null) {
      // hrList = await dbHelper.getHrData(userId, daySleepInfoModel!.data.first.dateTime.toString(),  daySleepInfoModel!.data.last.dateTime.toString());
      hrList = await GraphDataManager().graphManager(
          userId: userId,
          startDate: daySleepInfoModel!.data.first.dateTime!,
          endDate: daySleepInfoModel!.data.last.dateTime!,
          selectedGraphTypes: [
            graphTypeList.firstWhere(
                (element) => element.fieldName == DefaultGraphItem.hr.fieldName)
          ],
          isEnableNormalize: false,
          unitType: 1);
      oxygenList = await GraphDataManager().graphManager(
          userId: userId,
          startDate: daySleepInfoModel!.data.first.dateTime!,
          endDate: daySleepInfoModel!.data.last.dateTime!,
          selectedGraphTypes: [
            graphTypeList.firstWhere((element) =>
                element.fieldName == DefaultGraphItem.oxygen.fieldName)
          ],
          isEnableNormalize: false,
          unitType: 1);
      tempList = await GraphDataManager().graphManager(
          userId: userId,
          startDate: daySleepInfoModel!.data.first.dateTime!,
          endDate: daySleepInfoModel!.data.last.dateTime!,
          selectedGraphTypes: [
            graphTypeList.firstWhere((element) =>
                element.fieldName == DefaultGraphItem.temperature.fieldName)
          ],
          isEnableNormalize: false,
          unitType: 1);
      tempList.removeWhere((element) => element.yValue <= 1);
    }
    // makeOrRefreshChartWidget();
    //setState(() {});
  }

  List? makeListOfTypeByHours() {
    var current = DateTime.now();
    if (daySleepInfoModel != null && daySleepInfoModel!.data != null) {
      SleepDataInfoModel firstModel = daySleepInfoModel!.data.first;
      int? firstHour;
      int? firstMinute;
      DateTime? now;
      if (firstModel.time != null) {
        firstHour = int.parse(firstModel.time!.split(':')[0]);
        firstMinute = int.parse(firstModel.time!.split(':')[1]);
        now = DateTime(
            current.year,
            current.month,
            firstHour > 12 ? current.day - 1 : current.day,
            firstHour,
            firstMinute);
      }

      SleepDataInfoModel lastModel = daySleepInfoModel!.data.last;
      int? lastHour;
      int? lastMinute;
      DateTime? last;
      if (lastModel.time != null) {
        lastHour = int.parse(lastModel.time!.split(':')[0]);
        lastMinute = int.parse(lastModel.time!.split(':')[1]);
        last = DateTime(
            current.year,
            current.month,
            lastHour > 12 ? current.day - 1 : current.day,
            lastHour,
            lastMinute);
      }

      List listWithColorAndPercentage = [];
      for (int i = 0; i < daySleepInfoModel!.data.length; i++) {
        if (i == daySleepInfoModel!.data.length - 1) {
          break;
        }
        SleepDataInfoModel model = daySleepInfoModel!.data[i];
        SleepDataInfoModel nextModel = daySleepInfoModel!.data[i + 1];
        int? nowHour;
        int? nowMinute;
        if (model.time != null) {
          nowHour = int.parse(model.time!.split(':')[0]);
          nowMinute = int.parse(model.time!.split(':')[1]);
        }

        int? nextHour;
        int? nextMinute;
        if (model.time != null) {
          nextHour = int.parse(nextModel.time!.split(':')[0]);
          nextMinute = int.parse(nextModel.time!.split(':')[1]);
        }
        DateTime current = DateTime.now();

        if (nowHour != null &&
            nowMinute != null &&
            nextHour != null &&
            nextMinute != null) {
          DateTime nowDateTime = DateTime(current.year, current.month,
              nowHour > 12 ? current.day - 1 : current.day, nowHour, nowMinute);
          DateTime nextDateTime = DateTime(
              current.year,
              current.month,
              nextHour > 12 ? current.day - 1 : current.day,
              nextHour,
              nextMinute);
          listWithColorAndPercentage.add({
            'type': model.type,
            'time': model.time,
            'percentage':
                ((nextDateTime.difference(nowDateTime).inMinutes * 100) ~/
                    (daySleepInfoModel!.sleepAllTime == 0
                        ? 1
                        : daySleepInfoModel!.sleepAllTime)),
          });
        }
      }
      listWithColorAndPercentage.add({
        'type': daySleepInfoModel!.data.last.type,
        'time': daySleepInfoModel!.data.last.time,
        'percentage': 1
      });
      return listWithColorAndPercentage;
    }
    return null;
  }

  getColorByType(String type) {
    switch (type) {
      case '0': //stay up all night
        return AppColor.purpleColor;
      case '1': //sleep
        return AppColor.deepSleepColor;
      case '2': //light sleep
        return AppColor.lightSleepColor;
      case '3': //deep sleep
        return AppColor.deepSleepColor;
      case '4': //wake up half
        return AppColor.purpleColor;
      case '5': //wake up
        return AppColor.purpleColor;
    }
  }

  double stringTimeToDouble(String time) {
    double t = 0;
    t += double.parse(time.split(':')[0]);
    double temp = double.parse(time.split(':')[1]);
    temp = (temp / 60);
    if (t < 12) {
      t += 24;
    }
    t += temp;
    t.toStringAsFixed(1);
    return t;
  }

  Widget sleepLegends() {
    int awakePercentage = 0;
    int deepSleepPercentage = 0;
    int lightSleepPercentage = 0;
    if (widget.graphTab == GraphTab.day) {
      if (daySleepInfoModel != null) {
        // int totalMinutes = sleepModel.sleepAllTime??1;
        daySleepInfoModel = trimSleep(daySleepInfoModel!);
        int totalMinutes = (daySleepInfoModel!.lightTime) +
            (daySleepInfoModel!.deepTime) +
            (daySleepInfoModel!.stayUpTime);
        if (totalMinutes != 0) {
          lightSleepPercentage =
              ((daySleepInfoModel!.lightTime * 100) / totalMinutes).floor();
          deepSleepPercentage =
              ((daySleepInfoModel!.deepTime * 100) / totalMinutes).ceil();
          // deepSleepPercentage = ((sleepModel.deepTime * 100) / totalMinutes).ceil();
          if (lightSleepPercentage < 0) {
            lightSleepPercentage = 0;
          }
          if (deepSleepPercentage < 0) {
            deepSleepPercentage = 0;
          }
          awakePercentage = 100 - (lightSleepPercentage + deepSleepPercentage);
          if (awakePercentage < 0) {
            awakePercentage = 0;
          }
        }
      }
    } else {
      if (sleepItemList != null) {
        int totalMinutes = 0;
        int lightSleepMinutes = 0;
        int deepSleepMinutes = 0;
        int awakeMinutes = 0;

        sleepItemList.forEach((element) {
          if (element.label == 'lightTime') {
            lightSleepMinutes += (element.yValue * 60).toInt();
            totalMinutes += (element.yValue * 60).toInt();
          } else if (element.label == 'deepTime') {
            deepSleepMinutes += (element.yValue * 60).toInt();
            totalMinutes += (element.yValue * 60).toInt();
          } else if (element.label == 'stayUpTime') {
            awakeMinutes += (element.yValue * 60).toInt();
            totalMinutes += (element.yValue * 60).toInt();
          }
        });
        if (totalMinutes == 0) {
          totalMinutes = 1;
        }
        lightSleepPercentage =
            ((lightSleepMinutes * 100) / totalMinutes).round();
        deepSleepPercentage = ((deepSleepMinutes * 100) / totalMinutes).round();
        awakePercentage = ((awakeMinutes * 100) / totalMinutes).round();
        if ((lightSleepPercentage != 0 &&
                deepSleepPercentage != 0 &&
                awakePercentage != 0) &&
            (lightSleepPercentage + deepSleepPercentage + awakePercentage !=
                100)) {
          awakePercentage += 100 -
              (lightSleepPercentage + deepSleepPercentage + awakePercentage);
        }
      }
    }
    bool noSleepData = ((awakePercentage == 0) &&
        (deepSleepPercentage == 0) &&
        (lightSleepPercentage == 0));
    return Column(
      //mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          margin: EdgeInsets.symmetric(vertical: 15.h, horizontal: 20.w),
          decoration: BoxDecoration(
            //border: Border.all(color: Colors.black38),
            borderRadius: BorderRadius.circular(15.h),
            boxShadow: [
              BoxShadow(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? HexColor.fromHex('#000000').withOpacity(0.25)
                      : Colors.white,
                  blurRadius: 4,
                  spreadRadius: 2,
                  offset: Offset(-5, -5)),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(15.h),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  flex: lightSleepPercentage > 0.0
                      ? lightSleepPercentage.ceil()
                      : noSleepData
                          ? 1
                          : 0,
                  child: Container(
                    height: 12.h,
                    padding: EdgeInsets.symmetric(vertical: 1.h),
                    decoration: BoxDecoration(
                      color: AppColor.progressColor,
                    ),
                  ),
                ),
                Expanded(
                  flex: deepSleepPercentage > 0.0
                      ? deepSleepPercentage.floor()
                      : noSleepData
                          ? 1
                          : 0,
                  child: Container(
                    height: 12.h,
                    padding: EdgeInsets.symmetric(vertical: 1.h),
                    decoration: BoxDecoration(
                      color: AppColor.deepSleepColor,
                    ),
                  ),
                ),
                Expanded(
                  flex: awakePercentage > 0.0
                      ? awakePercentage.toInt()
                      : noSleepData
                          ? 1
                          : 0,
                  child: Container(
                    height: 12.h,
                    decoration: BoxDecoration(
                      color: AppColor.purpleColor,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        Container(
          margin: EdgeInsets.symmetric(horizontal: 20.w),
          //color: Colors.yellow,
          child: Row(
            children: [
              Expanded(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      height: 12.h,
                      width: 12.h,
                      decoration: BoxDecoration(
                        color: AppColor.progressColor,
                        shape: BoxShape.circle,
                      ),
                    ),
                    SizedBox(width: 8.w),
                    Expanded(
                      child: Text(
                        '$lightSleepPercentage% ${stringLocalization.getText(StringLocalization.light)}'
                            .toUpperCase(),
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.left,
                        style: TextStyle(
                            fontSize: 12.sp,
                            color: Theme.of(context).brightness ==
                                    Brightness.dark
                                ? HexColor.fromHex('#FFFFFF').withOpacity(0.6)
                                : HexColor.fromHex('#5D6A68'),
                            fontWeight: FontWeight.bold),
                      ),
                    )
                  ],
                ),
              ),
              //SizedBox(width: 20.w),
              Expanded(
                child: Align(
                  alignment: Alignment.center,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        height: 12.h,
                        width: 12.h,
                        decoration: BoxDecoration(
                          color: AppColor.deepSleepColor,
                          shape: BoxShape.circle,
                        ),
                      ),
                      SizedBox(width: 8.w),
                      Expanded(
                        child: Text(
                          '$deepSleepPercentage% ${stringLocalization.getText(StringLocalization.deep)}'
                              .toUpperCase(),
                          textAlign: TextAlign.left,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontSize: 12.sp,
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? HexColor.fromHex('#FFFFFF').withOpacity(0.6)
                                  : HexColor.fromHex('#5D6A68'),
                              fontWeight: FontWeight.bold),
                        ),
                      )
                    ],
                  ),
                ),
              ),
              //SizedBox(width: 20.w),
              Expanded(
                child: Align(
                  alignment: Alignment.centerRight,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        height: 12.h,
                        width: 12.h,
                        decoration: BoxDecoration(
                          color: AppColor.purpleColor,
                          shape: BoxShape.circle,
                        ),
                      ),
                      SizedBox(width: 8.w),
                      Expanded(
                        child: Text(
                          '$awakePercentage% ${stringLocalization.getText(StringLocalization.awake)}'
                              .toUpperCase(),
                          textAlign: TextAlign.left,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontSize: 12.sp,
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? HexColor.fromHex('#FFFFFF').withOpacity(0.6)
                                  : HexColor.fromHex('#5D6A68'),
                              fontWeight: FontWeight.bold),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        )
      ],
    );
  }

  SleepInfoModel trimSleep(SleepInfoModel mSleepInfo) {
    List<SleepDataInfoModel> listOfRemoveItems = [];
    if (mSleepInfo.data != null) {
      List<String> strList =
          mSleepInfo.data.map((e) => jsonEncode(e.toMap())).toSet().toList();
      mSleepInfo.data = strList
          .map((e) => SleepDataInfoModel.fromMap(jsonDecode(e)))
          .toList();

      try {
        mSleepInfo.data.forEach((element) {
          if (element.time != null && element.time.toString().isNotEmpty) {
            int firstItemHour = int.parse(element.time!.split(':')[0]);
            int firstItemMinute = int.parse(element.time!.split(':')[1]);
            DateTime current = startDate;
            DateTime tempStartDate = DateTime(
                current.year,
                current.month,
                firstItemHour > 12 ? current.day - 1 : current.day,
                firstItemHour,
                firstItemMinute);
            element.dateTime = tempStartDate;
          }
        });

        mSleepInfo.data.sort((a, b) => a.dateTime!.compareTo(b.dateTime!));
      } catch (e) {
        print(e);
      }

      for (int i = 0; i < mSleepInfo.data.length; i++) {
        SleepDataInfoModel sleepDataInfoModel = mSleepInfo.data[i];
        if (sleepDataInfoModel.type == '2' || sleepDataInfoModel.type == '3') {
          break;
        }
        listOfRemoveItems.add(sleepDataInfoModel);
      }
      try {
        for (int i = mSleepInfo.data.length - 1; i >= 0; i--) {
          SleepDataInfoModel sleepDataInfoModel = mSleepInfo.data[i];
          if (sleepDataInfoModel.type == '2' ||
              sleepDataInfoModel.type == '3') {
            break;
          }
          listOfRemoveItems.add(sleepDataInfoModel);
        }
      } catch (e) {
        print(e);
      }
      listOfRemoveItems.forEach((element) {
        mSleepInfo.data.remove(element);
      });
    }

    mSleepInfo.stayUpTime = getTotalsFromSleepData(mSleepInfo).stayUpTime;
    mSleepInfo.lightTime = getTotalsFromSleepData(mSleepInfo).lightTime;
    mSleepInfo.deepTime = getTotalsFromSleepData(mSleepInfo).deepTime;

    return mSleepInfo;
  }

  SleepInfoModel getTotalsFromSleepData(SleepInfoModel mSleepInfo) {
    try {
      var sleepInfoModel = SleepInfoModel.clone(mSleepInfo);
      int awake = 0;
      int deep = 0;
      int light = 0;

      for (int i = 0; i < sleepInfoModel.data.length; i++) {
        var element = sleepInfoModel.data[i];
        if (element.time != null && element.time.toString().isNotEmpty) {
          int firstItemHour = int.parse(element.time!.split(':')[0]);
          int firstItemMinute = int.parse(element.time!.split(':')[1]);
          DateTime current = DateTime.now();
          DateTime startDate = DateTime(
              current.year,
              current.month,
              firstItemHour > 12 ? current.day - 1 : current.day,
              firstItemHour,
              firstItemMinute);
          element.dateTime = startDate;
        }
      }
      sleepInfoModel.data.sort((a, b) => a.dateTime!.compareTo(b.dateTime!));

      for (int i = 0; i < sleepInfoModel.data.length; i++) {
        SleepDataInfoModel model = sleepInfoModel.data[i];
        if (i == (sleepInfoModel.data.length - 1)) {
          break;
        }
        SleepDataInfoModel nextModel = sleepInfoModel.data[i + 1];
        if (model.dateTime != null) {
          switch (model.type) {
            case '2': //light sleep
              light +=
                  nextModel.dateTime!.difference(model.dateTime!).inMinutes;
              break;
            case '3': //deep sleep
              deep += nextModel.dateTime!.difference(model.dateTime!).inMinutes;
              break;
            default:
              awake +=
                  nextModel.dateTime!.difference(model.dateTime!).inMinutes;
              break;
          }
        }
      }
      sleepInfoModel.stayUpTime = awake;
      sleepInfoModel.lightTime = light;
      sleepInfoModel.deepTime = deep;
      return sleepInfoModel;
    } catch (e) {
      print('exception in graph window screen $e');
    }
    return mSleepInfo;
  }

  Widget sleepChart() {
    return ValueListenableBuilder(
      valueListenable: widget.graphWindow.onChangeDate,
      builder: (context, DateTime? selectedDate, child) {
        if (selectedDate != null) {
          refresh(selectedDate);
        }
        if (isShowLoadingScreen) {
          return Center(
            child: CircularProgressIndicator(),
          );
        }
        return SizedBox(
          height: 250.h,
          width: Constants.width.w,
          child: sleepChartWidget(),
        );
      },
    );
  }

  Widget sleepChartWidget() {
    if (graphTypeList == null || graphTypeList.length == 0) {
      return Center(
        child: Body1AutoText(
            text: stringLocalization.getText(StringLocalization.noDataFound)),
      );
    }
    switch (graphWindow.selectedChartType) {
      case ChartType.line:
        return sleepLineChartWidget;
      case ChartType.bar:
        return barChartWidget;
      case ChartType.pie:
        return lineAndBarChartWidget;
      default:
        return Container();
    }
  }

  Widget bloodPressureIndicator(var sbp, var dbp) {
    String bpDateTime = '';
    if (selectedMeasurement?.date?.split('.')[0].isNotEmpty ?? false) {
      bpDateTime = selectedMeasurement!.date!.split('.')[0];
    } else {
      bpDateTime = stringLocalization.getText(StringLocalization.noData);
    }
    if (measurementModelList == null || measurementModelList.isEmpty) {
      sbp = 0;
      dbp = 0;
      bpDateTime = stringLocalization.getText(StringLocalization.noData);
    }
    return Container(
      margin: EdgeInsets.only(top: 18.h),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: 12.h,
                width: 12.h,
                decoration: BoxDecoration(
                    color: Colors.yellow,
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.black)),
              ),
              SizedBox(width: 8.w),
              SizedBox(
                height: 20.h,
                child: Body1AutoText(
                  text: stringLocalization.getText(StringLocalization.yourBp),
                  color: Theme.of(context).brightness == Brightness.dark
                      ? HexColor.fromHex('#FFFFFF').withOpacity(0.6)
                      : HexColor.fromHex('#5D6A68'),
                  fontSize: 16.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(width: 8.w),
              SizedBox(
                height: 25.h,
                child: Body1AutoText(
                    text: '$sbp/$dbp',
                    color: Theme.of(context).brightness == Brightness.dark
                        ? HexColor.fromHex('#FFFFFF').withOpacity(0.87)
                        : HexColor.fromHex('#384341'),
                    fontSize: 24.0,
                    fontWeight: FontWeight.bold),
              ),
              SizedBox(width: 8.w),
              SizedBox(
                height: 20.h,
                child: Body1AutoText(
                    text: 'mmHg',
                    color: Theme.of(context).brightness == Brightness.dark
                        ? HexColor.fromHex('#FFFFFF').withOpacity(0.6)
                        : HexColor.fromHex('#5D6A68'),
                    fontSize: 16.0,
                    fontWeight: FontWeight.bold),
              ),
            ],
          ),
          widget.graphTab == GraphTab.day
              ? Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    !(measurementModelList == null ||
                            measurementModelList.isEmpty)
                        ? SizedBox(
                            height: 30.h,
                            child: IconButton(
                              padding: EdgeInsets.zero,
                              icon: Icon(
                                Icons.arrow_back_ios,
                                size: 14,
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? HexColor.fromHex('#FFFFFF')
                                        .withOpacity(0.87)
                                    : HexColor.fromHex('#384341'),
                              ),
                              onPressed: () {
                                if (bpIndex == 0) {
                                  bpIndex = measurementModelList.length - 1;
                                } else {
                                  bpIndex = bpIndex - 1;
                                }
                                bloodPressureArrowButtonClicked();
                              },
                            ),
                          )
                        : Container(),
                    !(measurementModelList == null ||
                            measurementModelList.isEmpty)
                        ? Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                height: 25.h,
                                child: Body1AutoText(
                                  text: 'Time:',
                                  maxLine: 1,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? HexColor.fromHex('#FFFFFF')
                                          .withOpacity(0.6)
                                      : HexColor.fromHex('#5D6A68'),
                                  fontSize: 16.0,
                                ),
                              ),
                              SizedBox(
                                width: 5.w,
                              ),
                              SizedBox(
                                height: 25.h,
                                child: Body1AutoText(
                                  text: bpDateTime.split(' ')[1],
                                  maxLine: 1,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? HexColor.fromHex('#FFFFFF')
                                          .withOpacity(0.87)
                                      : HexColor.fromHex('#384341'),
                                  fontSize: 16.0,
                                ),
                              ),
                            ],
                          )
                        : SizedBox(
                            height: 25.h,
                            child: Body1AutoText(
                              text: bpDateTime,
                              maxLine: 1,
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? HexColor.fromHex('#FFFFFF').withOpacity(0.6)
                                  : HexColor.fromHex('#384341'),
                              fontSize: 16.0,
                              align: TextAlign.center,
                            ),
                          ),
                    !(measurementModelList == null ||
                            measurementModelList.isEmpty)
                        ? SizedBox(
                            height: 30.h,
                            child: IconButton(
                              padding: EdgeInsets.zero,
                              icon: Icon(
                                Icons.arrow_forward_ios,
                                size: 14,
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? HexColor.fromHex('#FFFFFF')
                                        .withOpacity(0.87)
                                    : HexColor.fromHex('#384341'),
                              ),
                              onPressed: () {
                                if (bpIndex ==
                                    measurementModelList.length - 1) {
                                  bpIndex = 0;
                                } else {
                                  bpIndex = bpIndex + 1;
                                }
                                bloodPressureArrowButtonClicked();
                              },
                            ),
                          )
                        : Container(),
                  ],
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    !(measurementModelList == null ||
                            measurementModelList.isEmpty)
                        ? SizedBox(
                            width: 25.w,
                            child: IconButton(
                              icon: Icon(
                                Icons.arrow_back_ios,
                                size: 14,
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? HexColor.fromHex('#FFFFFF')
                                        .withOpacity(0.87)
                                    : HexColor.fromHex('#384341'),
                              ),
                              onPressed: () {
                                if (bpIndex == 0) {
                                  bpIndex = measurementModelList.length - 1;
                                } else {
                                  bpIndex = bpIndex - 1;
                                }
                                bloodPressureArrowButtonClicked();
                              },
                            ),
                          )
                        : Container(),
                    !(measurementModelList == null ||
                            measurementModelList.isEmpty)
                        ? Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                height: 25.h,
                                child: Body1AutoText(
                                  text: 'Date:',
                                  maxLine: 1,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? HexColor.fromHex('#FFFFFF')
                                          .withOpacity(0.6)
                                      : HexColor.fromHex('#5D6A68'),
                                  fontSize: 16.0,
                                ),
                              ),
                              SizedBox(
                                width: 5.w,
                              ),
                              SizedBox(
                                height: 25.h,
                                child: Body1AutoText(
                                  text: bpDateTime.split(' ')[0],
                                  maxLine: 1,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? HexColor.fromHex('#FFFFFF')
                                          .withOpacity(0.87)
                                      : HexColor.fromHex('#384341'),
                                  fontSize: 16.0,
                                ),
                              ),
                              SizedBox(
                                width: 5.w,
                              ),
                              SizedBox(
                                height: 25.h,
                                child: Body1AutoText(
                                  text: 'Time:',
                                  maxLine: 1,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? HexColor.fromHex('#FFFFFF')
                                          .withOpacity(0.6)
                                      : HexColor.fromHex('#5D6A68'),
                                  fontSize: 16.0,
                                ),
                              ),
                              SizedBox(
                                width: 5.w,
                              ),
                              SizedBox(
                                height: 25.h,
                                child: Body1AutoText(
                                  text: bpDateTime.split(' ')[1],
                                  maxLine: 1,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? HexColor.fromHex('#FFFFFF')
                                          .withOpacity(0.87)
                                      : HexColor.fromHex('#384341'),
                                  fontSize: 16.0,
                                ),
                              ),
                            ],
                          )
                        : SizedBox(
                            height: 25.h,
                            child: Body1AutoText(
                              text: bpDateTime,
                              maxLine: 1,
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? HexColor.fromHex('#FFFFFF').withOpacity(0.6)
                                  : HexColor.fromHex('#384341'),
                              fontSize: 16.0,
                              align: TextAlign.center,
                            ),
                          ),
                    !(measurementModelList == null ||
                            measurementModelList.isEmpty)
                        ? SizedBox(
                            width: 25.w,
                            child: IconButton(
                              icon: Icon(
                                Icons.arrow_forward_ios,
                                size: 14,
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? HexColor.fromHex('#FFFFFF')
                                        .withOpacity(0.87)
                                    : HexColor.fromHex('#384341'),
                              ),
                              onPressed: () {
                                if (bpIndex ==
                                    measurementModelList.length - 1) {
                                  bpIndex = 0;
                                } else {
                                  bpIndex = bpIndex + 1;
                                }
                                bloodPressureArrowButtonClicked();
                              },
                            ),
                          )
                        : Container(),
                  ],
                ),
          SizedBox(
              height:
                  (measurementModelList == null || measurementModelList.isEmpty)
                      ? 30.h
                      : 10.h),
          Container(
            margin: EdgeInsets.only(left: 15.h, right: 15.h),
            height: 1,
            color: HexColor.fromHex('#BDC7C5'),
          ),
          Container(
            margin: EdgeInsets.only(left: 15.h, right: 15.h, top: 15.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          height: 12.h,
                          width: 12.h,
                          decoration:
                              BoxDecoration(color: HexColor.fromHex('#99D9D9')),
                        ),
                        SizedBox(width: 8.w),
                        SizedBox(
                          height: 18.h,
                          child: Body1AutoText(
                              text: 'Low',
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? HexColor.fromHex('#FFFFFF').withOpacity(0.6)
                                  : HexColor.fromHex('#5D6A68'),
                              fontSize: 12.0,
                              fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 19.h,
                    ),
                    Row(
                      children: [
                        Container(
                          height: 12.h,
                          width: 12.h,
                          decoration:
                              BoxDecoration(color: HexColor.fromHex('#D3A5DF')),
                        ),
                        SizedBox(width: 8.w),
                        SizedBox(
                          height: 18.h,
                          child: Body1AutoText(
                              text: 'Hyper',
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? HexColor.fromHex('#FFFFFF').withOpacity(0.6)
                                  : HexColor.fromHex('#5D6A68'),
                              fontSize: 12.0,
                              fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          height: 12.h,
                          width: 12.h,
                          decoration:
                              BoxDecoration(color: HexColor.fromHex('#00AFAA')),
                        ),
                        SizedBox(width: 8.w),
                        SizedBox(
                          height: 18.h,
                          child: Body1AutoText(
                              text: 'Ideal',
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? HexColor.fromHex('#FFFFFF').withOpacity(0.6)
                                  : HexColor.fromHex('#5D6A68'),
                              fontSize: 12.0,
                              fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 19.h,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          height: 12.h,
                          width: 12.h,
                          decoration:
                              BoxDecoration(color: HexColor.fromHex('#BD78CE')),
                        ),
                        SizedBox(width: 8.w),
                        SizedBox(
                          height: 18.h,
                          child: Body1AutoText(
                              text: 'Hyper (stage 1)',
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? HexColor.fromHex('#FFFFFF').withOpacity(0.6)
                                  : HexColor.fromHex('#5D6A68'),
                              fontSize: 12.0,
                              fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          height: 12.h,
                          width: 12.h,
                          decoration: BoxDecoration(color: Colors.transparent),
                        ),
                        SizedBox(width: 8.w),
                        SizedBox(
                            height: 18.h,
                            child: Body1AutoText(
                                text: 'Ideal', color: Colors.transparent)),
                      ],
                    ),
                    SizedBox(
                      height: 19.h,
                    ),
                    Row(
                      children: [
                        Container(
                          height: 12.h,
                          width: 12.h,
                          decoration:
                              BoxDecoration(color: HexColor.fromHex('#9F2DBC')),
                        ),
                        SizedBox(width: 8.w),
                        SizedBox(
                          height: 18.h,
                          child: Body1AutoText(
                              text: 'Hyper (stage 2)',
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? HexColor.fromHex('#FFFFFF').withOpacity(0.6)
                                  : HexColor.fromHex('#5D6A68'),
                              fontSize: 12.0,
                              fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  bloodPressureArrowButtonClicked() {
    if (bpIndex != null) {
      bloodPressure.xValue = measurementModelList[bpIndex].dbp!.toDouble();
      bloodPressure.yValue = measurementModelList[bpIndex].sbp!.toDouble();
      bloodPressure.date = measurementModelList[bpIndex].date;
      selectedMeasurement = measurementModelList[bpIndex];
      if (mounted) {
        setState(() {
          makeOrRefreshChartWidget(context);
        });
      }
    }
  }

  Widget sleepIndicator() {
    return Align(
      alignment: Alignment.center,
      child: Container(
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              height: 12.h,
              width: 12.h,
              decoration: BoxDecoration(
                color: AppColor.progressColor,
                shape: BoxShape.circle,
              ),
            ),
            SizedBox(width: 10.w),
            Text(
              '${stringLocalization.getText(StringLocalization.light)}'
                  .toUpperCase(),
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 12.h,
                  color: Theme.of(context).brightness == Brightness.dark
                      ? HexColor.fromHex('#FFFFFF').withOpacity(0.6)
                      : HexColor.fromHex('#5D6A68'),
                  fontWeight: FontWeight.bold),
            ),
            SizedBox(
              width: 40.w,
            ),
            Container(
              height: 12.h,
              width: 12.h,
              decoration: BoxDecoration(
                color: AppColor.deepSleepColor,
                shape: BoxShape.circle,
              ),
            ),
            SizedBox(width: 10.w),
            Text(
              '${stringLocalization.getText(StringLocalization.deep)}'
                  .toUpperCase(),
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 12.h,
                  color: Theme.of(context).brightness == Brightness.dark
                      ? HexColor.fromHex('#FFFFFF').withOpacity(0.6)
                      : HexColor.fromHex('#5D6A68'),
                  fontWeight: FontWeight.bold),
            )
          ],
        ),
      ),
    );
  }

  /// added by: Shahzad
  /// added on: 29th dec 2020
  /// container for candle stick graph
  bpCandleGraph() {
    return Container(
      //color: Colors.blue,
      height: 240.h,
      margin: widget.graphTab == GraphTab.week
          ? EdgeInsets.only(top: 10.h, left: 5.w)
          : EdgeInsets.only(top: 10.h),
      child: Center(
        child: Row(
          children: [
            Expanded(
                flex: 1,
                child: Column(
                  children: [
                    Container(
                      // padding: EdgeInsets.only(left: 10),
                      height: 210.h,
//                      color: Colors.green,
                      child: Row(
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                  child: Text(
                                '200',
                                style: TextStyle(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? HexColor.fromHex('#FFFFFF')
                                            .withOpacity(0.87)
                                        : HexColor.fromHex('#384341'),
                                    fontSize: 10),
                              )),
                              Container(
                                  child: Text(
                                '150',
                                style: TextStyle(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? HexColor.fromHex('#FFFFFF')
                                            .withOpacity(0.87)
                                        : HexColor.fromHex('#384341'),
                                    fontSize: 10),
                              )),
                              Container(
                                  child: Text(
                                '100',
                                style: TextStyle(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? HexColor.fromHex('#FFFFFF')
                                            .withOpacity(0.87)
                                        : HexColor.fromHex('#384341'),
                                    fontSize: 10),
                              )),
                              Container(
                                  child: Text(
                                '  50',
                                style: TextStyle(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? HexColor.fromHex('#FFFFFF')
                                            .withOpacity(0.87)
                                        : HexColor.fromHex('#384341'),
                                    fontSize: 10),
                              )),
                            ],
                          ),
                          SizedBox(
                            width: 5.w,
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 8.h, bottom: 5.h),
                            color: Theme.of(context).brightness ==
                                    Brightness.dark
                                ? HexColor.fromHex('#FFFFFF').withOpacity(0.15)
                                : HexColor.fromHex('#D9E0E0'),
                            height: 200,
                            width: 1.w,
                          ),
                          Expanded(
                            child: Align(
                              alignment: Alignment.bottomLeft,
                              child: Container(
                                margin: EdgeInsets.only(bottom: 5.h),
                                height: 1.h,
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? HexColor.fromHex('#FFFFFF')
                                        .withOpacity(0.15)
                                    : HexColor.fromHex('#D9E0E0'),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 20.h,
                    )
                  ],
                )),
            Expanded(
              flex: widget.graphTab == GraphTab.day
                  ? 10
                  : widget.graphTab == GraphTab.week
                      ? 8
                      : 11,
              child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: bpCandleData.length,
                  itemBuilder: (BuildContext context, int index) {
                    return candleContainer(index + 1);
                  }),
            ),
          ],
        ),
      ),
    );
  }

  /// added by: Shahzad
  /// added on: 29th dec 2020
  /// container for a single candle stick
  Widget candleContainer(int index) {
    return Column(
      children: [
        Container(
          height: 210.h,
          width: widget.graphTab == GraphTab.day
              ? 12.w
              : widget.graphTab == GraphTab.week
                  ? 40.w
                  : 9.5.w,
          child: Container(
            child: Column(
              children: [
                candleSingleGraph(bpCandleData[index - 1]),
                Expanded(
                  child: Align(
                    alignment: Alignment.bottomLeft,
                    child: Container(
                      margin: EdgeInsets.only(bottom: 5.h),
                      height: 1.h,
                      width: widget.graphTab == GraphTab.day
                          ? 12.w
                          : widget.graphTab == GraphTab.week
                              ? 40.w
                              : 9.5.w,
                      color: Theme.of(context).brightness == Brightness.dark
                          ? HexColor.fromHex('#FFFFFF').withOpacity(0.15)
                          : HexColor.fromHex('#D9E0E0'),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
        Container(
          height: 20.h,
          width: widget.graphTab == GraphTab.day
              ? 12.w
              : widget.graphTab == GraphTab.week
                  ? 40.w
                  : 9.5.w,
          child: Body1AutoText(
            text: widget.graphTab == GraphTab.week
                ? weekDays(index)
                : index % 2 != 0
                    ? index.toString()
                    : '',
            color: Theme.of(context).brightness == Brightness.dark
                ? HexColor.fromHex('#FFFFFF').withOpacity(0.87)
                : HexColor.fromHex('#384341'),
            fontSize: widget.graphTab == GraphTab.day
                ? 8.sp
                : widget.graphTab == GraphTab.week
                    ? 12.sp
                    : 8.sp,
            align: TextAlign.center,
            maxLine: 1,
            minFontSize: 5,
          ),
        )
      ],
    );
  }

  /// added by: Shahzad
  /// added on: 29th dec 2020
  /// adding properties to a single candle stick
  Widget candleSingleGraph(BPGraph bpGraph) {
    Color color = candleColor(bpGraph.sbpMax, bpGraph.dbpMax);
    return Container(
      margin: EdgeInsets.only(top: 6.h),
      height: 198.h,
      child: Container(
        margin: EdgeInsets.only(top: candleHeight(200, bpGraph.sbpMax)),
        child: Column(
          children: [
            Container(
              height: candleHeight(bpGraph.sbpMax, bpGraph.sbpMin),
              width: widget.graphTab == GraphTab.week ? 6.w : 5.w,
              decoration: candleHeight(bpGraph.sbpMax, bpGraph.sbpMin) < 5
                  ? BoxDecoration(
                      borderRadius: BorderRadius.vertical(
                          top: Radius.circular(
                              candleHeight(bpGraph.sbpMax, bpGraph.sbpMin)),
                          bottom: Radius.circular(
                              candleHeight(bpGraph.sbpMax, bpGraph.sbpMin))),
                      color: color,
                    )
                  : BoxDecoration(
                      borderRadius: BorderRadius.vertical(
                          top: Radius.circular(4.h),
                          bottom: Radius.circular(4.h)),
                      border: Border.all(color: color, width: 2.w)),
            ),
            Container(
                height: candleHeight(bpGraph.sbpMin, bpGraph.dbpMax),
                width: 2.w,
                color: color),
            Container(
              height: candleHeight(bpGraph.dbpMax, bpGraph.dbpMin),
              width: widget.graphTab == GraphTab.week ? 6.w : 5.w,
              decoration: candleHeight(bpGraph.dbpMax, bpGraph.dbpMin) < 5
                  ? BoxDecoration(
                      borderRadius: BorderRadius.vertical(
                          top: Radius.circular(
                              candleHeight(bpGraph.dbpMax, bpGraph.dbpMin)),
                          bottom: Radius.circular(
                              candleHeight(bpGraph.sbpMax, bpGraph.sbpMin))),
                      color: color,
                    )
                  : BoxDecoration(
                      border: Border.all(color: color, width: 2.w),
                      borderRadius: BorderRadius.vertical(
                          top: Radius.circular(4.h),
                          bottom: Radius.circular(4.h)),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  double candleHeight(int value1, int value2) {
    if (value1 < value2) {
      return 0.0;
    }
    double height = 0;
    height = ((value1 - 50) - (value2 - 50)) / 150 * 198;
    return height.h > 198.h ? 0 : height.h;
  }

  /// added by: Shahzad
  /// added on: 30th dec 2020
  /// this function returns color of the candle stick
  Color candleColor(int sbp, int dbp) {
    if (sbp < 90 && dbp < 60) {
      return HexColor.fromHex('#99D9D9');
    } else if (sbp < 120 && dbp < 80) {
      return HexColor.fromHex('#00AFAA');
    } else if (sbp < 140 && dbp < 90) {
      return HexColor.fromHex('#D3A5DF');
    } else if (sbp < 160 && dbp < 100) {
      return HexColor.fromHex('#BD78CE');
    } else if (sbp <= 180 && dbp <= 120) {
      return HexColor.fromHex('#9F2DBC');
    } else {
      return Colors.transparent;
    }
  }

  /// added by: Shahzad
  /// added on: 29th dec 2020
  /// this function return name of week days
  String weekDays(int index) {
    switch (index) {
      case 1:
        return 'Mon';
      case 2:
        return 'Tue';
      case 3:
        return 'Wed';
      case 4:
        return 'Thu';
      case 5:
        return 'Fri';
      case 6:
        return 'Sat';
      case 7:
        return 'Sun';
    }
    return '';
  }

  /// added by: Shahzad
  /// added on: 29th dec 2020
  /// container of avg sys and dia
  Widget candleGraphIndicator() {
    return Container(
      padding: EdgeInsets.only(top: 10.h),
      height: 80.h,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Flexible(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  stringLocalization.getText(StringLocalization.sysAvg),
                  // minFontSize: 12,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: Theme.of(context).brightness == Brightness.dark
                          ? HexColor.fromHex('#FFFFFF').withOpacity(0.6)
                          : HexColor.fromHex('#5D6A68')),
                ),
                SizedBox(
                  height: 2.h,
                ),
                Expanded(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        avgSbp.toString(),
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                            color: Theme.of(context).brightness ==
                                    Brightness.dark
                                ? HexColor.fromHex('#FFFFFF').withOpacity(0.87)
                                : HexColor.fromHex('#384341')),
                      ),
                      SizedBox(
                        width: 2.h,
                      ),
                      Text(
                        'mmHg',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: Theme.of(context).brightness ==
                                    Brightness.dark
                                ? HexColor.fromHex('#FFFFFF').withOpacity(0.6)
                                : HexColor.fromHex('#5D6A68')),
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            width: 30.w,
          ),
          Flexible(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  stringLocalization.getText(StringLocalization.diaAvg),
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: Theme.of(context).brightness == Brightness.dark
                          ? HexColor.fromHex('#FFFFFF').withOpacity(0.6)
                          : HexColor.fromHex('#5D6A68')),
                ),
                SizedBox(
                  height: 2.h,
                ),
                Expanded(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        avgDbp.toString(),
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                            color: Theme.of(context).brightness ==
                                    Brightness.dark
                                ? HexColor.fromHex('#FFFFFF').withOpacity(0.87)
                                : HexColor.fromHex('#384341')),
                      ),
                      SizedBox(
                        width: 2.h,
                      ),
                      Text(
                        'mmHg',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: Theme.of(context).brightness ==
                                    Brightness.dark
                                ? HexColor.fromHex('#FFFFFF').withOpacity(0.6)
                                : HexColor.fromHex('#5D6A68')),
                      )
                    ],
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  interpolateWeightGraph(
      List<chart.Series<GraphItemData, num>> lineChartSeries) async {
    DateTime dbDate = selectedDate.subtract(Duration(days: 1));
    WeightMeasurementModel? tempWeightModel;
    await dbHelper
        .getLastWeightData(globalUser != null ? globalUser!.userId ?? '' : '',
            dbDate.toString())
        .then((List<WeightMeasurementModel> lastWeightList) {
      tempWeightModel = lastWeightList.isEmpty
          ? WeightMeasurementModel()
          : lastWeightList.first;
    });

    if (tempWeightModel != null && tempWeightModel!.weightSum != null) {
      if (UnitExtension.getUnitType(weightUnit) == UnitTypeEnum.imperial) {
        tempWeightModel!.weightSum = tempWeightModel!.weightSum! * 2.205;
      } else {
        tempWeightModel!.weightSum = tempWeightModel!.weightSum!;
      }
    }

    var tempList = lineChartSeries[0].data;
    for (int i = 0; i < tempList.length; i++) {
      if (tempList[0].yValue == 0) {
        tempList[0].yValue = tempWeightModel?.weightSum ??
            double.parse(globalUser != null ? globalUser!.weight ?? '0' : '0');
      } else if (tempList[i].yValue == 0) {
        tempList[i].yValue = tempList[i - 1].yValue;
      }
    }
    lineChartWeightSeries = lineChartSeries;
  }
}

class SleepGraphData {
  double xValue;
  double yValue;
  Color color;

  SleepGraphData(
      {required this.xValue, required this.yValue, required this.color});
}

class BloodPressure {
  double xValue;
  double yValue;
  Color color;
  String? pointID;
  String? date;

  BloodPressure(
      {required this.yValue,
      required this.xValue,
      required this.color,
      this.pointID,
      this.date});
}

/// added by: Shahzad
/// added on: 29th dec 2020
/// contains value for candle stick graph
class BPGraph {
  int sbpMax;
  int dbpMax;
  int sbpMin;
  int dbpMin;

  BPGraph(
      {required this.dbpMax,
      required this.dbpMin,
      required this.sbpMax,
      required this.sbpMin});
}

class RadioModel {
  bool isSelected;
  final String text;

  RadioModel(this.isSelected, this.text);
}
