import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:health_gauge/models/tag.dart';
import 'package:health_gauge/screens/dashboard/dash_board_screen.dart';
import 'package:health_gauge/screens/icons_screen.dart';
import 'package:health_gauge/screens/loading_screen.dart';
import 'package:health_gauge/ui/graph_screen/manager/graph_item_enum.dart';
import 'package:health_gauge/ui/graph_screen/manager/graph_shared_preference_manager_model.dart';
import 'package:health_gauge/ui/graph_screen/manager/graph_type_model.dart';
import 'package:health_gauge/utils/concave_decoration.dart';
import 'package:health_gauge/utils/constants.dart';
import 'package:health_gauge/utils/database_table_name_and_fields.dart';
import 'package:health_gauge/utils/gloabals.dart';
import 'package:health_gauge/value/app_color.dart';
import 'package:health_gauge/value/string_localization_support/string_localization.dart';
import 'package:health_gauge/widgets/custom_dialog.dart';
import 'package:health_gauge/widgets/custom_snackbar.dart';
import 'package:health_gauge/widgets/text_utils.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'graph_list_page.dart';

List<GraphTypeModel> graphTypeList = [];

class PageViewScreen extends StatefulWidget {
  final int graphPageIndex;

  PageViewScreen({required this.graphPageIndex, required Key key})
      : super(key: key);

  @override
  PageViewScreenState createState() => PageViewScreenState();
}

class PageViewScreenState extends State<PageViewScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  bool errorIcon = false;

  RegExp regExForRestrictEmoji() => RegExp(
      r'(\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff])');
  late String userId;
  bool showLoadingScreen = true;
  TextEditingController titleController = TextEditingController();
  late PageController pageController;
  List<GraphSharedPreferenceManagerModel> listOfPagesFromPreference = [];
  int currentIndex = 0;

  bool sameTitle = false;

  bool errorTitle = false;
  FocusNode titleFocusNode = new FocusNode();
  bool openKeyboardTitle = false;

  bool isAddedNewTab = false;
  late String selectedIcon;

  @override
  void initState() {
    currentIndex = widget.graphPageIndex;
    selectedIcon = '';
    pageController = PageController(initialPage: widget.graphPageIndex);
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        // setState(() {});
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(kToolbarHeight),
          child: Container(
            decoration: BoxDecoration(boxShadow: [
              BoxShadow(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.black.withOpacity(0.5)
                    : HexColor.fromHex('#384341').withOpacity(0.2),
                offset: Offset(0, 2.0),
                blurRadius: 4.0,
              )
            ]),
            child: AppBar(
              elevation: 0,
              backgroundColor: Theme.of(context).brightness == Brightness.dark
                  ? HexColor.fromHex('#111B1A')
                  : HexColor.fromHex('#EEF1F1'),
              leading: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  previousButton(),
                ],
              ),
              title: GestureDetector(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    nextButton(),
                    Platform.isIOS
                        ? Expanded(
                            child: Padding(
                            padding: EdgeInsets.only(right: 25.w),
                            child: Center(child: pageTitle()),
                          ))
                        : Expanded(child: Center(child: pageTitle())),
                  ],
                ),
                onLongPress: () {
                  titleController.clear();
                  if (currentIndex >= 0 &&
                      listOfPagesFromPreference[currentIndex].isDefault) {
                  } else {
                    HapticFeedback.heavyImpact();
                    showDialogToEditName(
                        isNewTab: false,
                        onClickOk: () {
                          openKeyboardTitle = false;
                          if (context != null) {
                            Navigator.of(context, rootNavigator: true).pop();
                          }
                          setState(() {
                            listOfPagesFromPreference[currentIndex].title =
                                titleController.text;
                            listOfPagesFromPreference[currentIndex].iconPath =
                                selectedIcon;
                          });
                          storeOrUpdatePreferenceList();
                        });
                  }
                },
              ),
              actions: [
                Align(
                  alignment: Alignment.centerRight,
                  child: Row(
                    children: [
                      listOfPagesFromPreference.isNotEmpty &&
                              listOfPagesFromPreference.length > currentIndex &&
                              !listOfPagesFromPreference[currentIndex].isDefault
                          ? IconButton(
                              key: Key('removeGraphButton'),
                              padding: EdgeInsets.only(right: 20),
                              icon: Image.asset(Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? 'asset/dark_minus_icon.png'
                                  : 'asset/minus-icon.png'),
                              onPressed: () {
                                deleteDialog(onClickOk: () {
                                  if (context != null) {
                                    Navigator.of(context, rootNavigator: true)
                                        .pop();
                                  }
                                  if (listOfPagesFromPreference != null &&
                                      listOfPagesFromPreference.length >
                                          currentIndex) {
                                    listOfPagesFromPreference
                                        .removeAt(currentIndex);
                                  }
                                  storeOrUpdatePreferenceList();
                                  print(preferences!.getStringList(
                                      Constants.prefKeyForGraphPages));
                                  if (listOfPagesFromPreference.isNotEmpty) {
                                    if (currentIndex > 0) {
                                      currentIndex--;
                                    } else {
                                      currentIndex = 0;
                                    }
                                    pageController.jumpToPage(currentIndex);
                                  }
                                  if (mounted) {
                                    setState(() {});
                                  }
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(
                                        'Graph deleted successfully',
                                        style: TextStyle(
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black),
                                      ),
                                      backgroundColor:
                                          Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.black
                                              : Colors.white,
                                      duration: Duration(seconds: 3),
                                    ),
                                  );
                                  // popTillThis(widget.graphPageIndex);
                                });
                              })
                          : SizedBox(
                              width: 40,
                            ),
                      IconButton(
                        key: Key('addNewGraphButton'),
                        padding: EdgeInsets.only(right: 15),
                        icon: Image.asset(
                          Theme.of(context).brightness == Brightness.dark
                              ? 'asset/dark_plus.png'
                              : 'asset/plus.png',
                          height: 16,
                          width: 16,
                        ),
                        onPressed: () {
                          titleController.clear();
                          if (listOfPagesFromPreference.last.windowList.first
                                  ?.selectedType.isNotEmpty ??
                              false) {
                            addGraphDialog(
                              onClickOk: () async {
                                try {
                                  if (context != null) {
                                    Navigator.of(context, rootNavigator: true)
                                        .pop();
                                  }
                                  isAddedNewTab = true;
                                  await showDialogToEditName(
                                    title: stringLocalization.getText(
                                        StringLocalization.addTitleOfpage),
                                    isNewTab: true,
                                    onClickOk: () {
                                      openKeyboardTitle = false;
                                      try {
                                        if (context != null) {
                                          Navigator.of(context,
                                                  rootNavigator: true)
                                              .pop();
                                        }
                                        if (listOfPagesFromPreference != null &&
                                            listOfPagesFromPreference
                                                .isNotEmpty) {
                                          listOfPagesFromPreference[
                                                  listOfPagesFromPreference
                                                          .length -
                                                      1]
                                              .title = titleController.text;
                                          listOfPagesFromPreference[
                                                  listOfPagesFromPreference
                                                          .length -
                                                      1]
                                              .iconPath = selectedIcon;
                                        }
                                        storeOrUpdatePreferenceList();
                                        pageController.jumpToPage(
                                            listOfPagesFromPreference.length -
                                                1);
                                        currentIndex =
                                            listOfPagesFromPreference.length -
                                                1;
                                        if (mounted) {
                                          setState(() {});
                                        }
                                      } catch (e) {
                                        print(e);
                                      }
                                    },
                                  );
                                } catch (e) {
                                  print(e);
                                }
                              },
                            );
                          } else {
                            pageController.jumpToPage(
                                listOfPagesFromPreference.length - 1);
                            setState(() {});
                          }
                        },
                      )
                    ],
                  ),
                )
              ],
              bottom: dotIndicators(),
            ),
          )),
      body: layoutMain(),
    );
  }

  deleteDialog({required GestureTapCallback onClickOk}) {
    var dialog = CustomDialog(
      title: stringLocalization.getText(StringLocalization.delete),
      subTitle: stringLocalization.getText(StringLocalization.deleteInfo),
      maxLine: 2,
      onClickNo: () {
        if (context != null) {
          Navigator.of(context, rootNavigator: true).pop();
        }
      },
      onClickYes: onClickOk,
    );
    showDialog(
        context: context,
        useRootNavigator: true,
        builder: (context) => dialog,
        barrierDismissible: false);
  }

  addGraphDialog({required GestureTapCallback onClickOk}) {
    var dialog = CustomDialog(
      title: stringLocalization.getText(StringLocalization.addNewCategory),
      subTitle: stringLocalization.getText(StringLocalization.addNewGraphTab),
      maxLine: 2,
      onClickNo: () {
        if (context != null) {
          Navigator.of(context, rootNavigator: true).pop();
        }
      },
      onClickYes: onClickOk,
      secondaryButton:
          stringLocalization.getText(StringLocalization.cancel).toUpperCase(),
    );
    showDialog(
        context: context,
        useRootNavigator: true,
        builder: (context) => dialog,
        barrierDismissible: false);
  }

  refreshData() {
//    onChangeDate.value = selectedDate;
    print("refreshData");

    for (var element2
    in listOfPagesFromPreference[currentIndex].windowList) {
      element2?.isChange.value = true;
    }
    // for (var element in listOfPagesFromPreference) {
    //   for (var element2 in element.windowList) {
    //     element2?.isChange.value = true;
    //   }
    // }
  }

  Widget layoutMain() {
    print('layoutMain_000');
    if (showLoadingScreen) {
      return LoadingScreen();
    }
    return PageView(
      controller: pageController,
      children: List.generate(listOfPagesFromPreference.length, (index) {
        return GraphListPage(
          graphSharedPreferenceManagerModel: listOfPagesFromPreference[index],
          graphTypeList: graphTypeList,
        );
      }),
      onPageChanged: (page) {
        dashCommonNotifier.notifyListeners();
        if (isAddedNewTab) {
          currentIndex = page + 1;
          isAddedNewTab = false;
        } else {
          currentIndex = page;
        }
        if (mounted) {
          setState(() {});
        }
      },
    );
  }

  Future<bool> storeOrUpdatePreferenceList() => preferences!.setStringList(
      Constants.prefKeyForGraphPages,
      listOfPagesFromPreference.map((e) => jsonEncode(e.toMap())).toList());

  Text pageTitle() {
    var title = ' ';
    try {
      if (listOfPagesFromPreference.length > currentIndex) {
        title = '${listOfPagesFromPreference.elementAt(currentIndex).title}';
      }
    } catch (e) {
      print('Exception at pageview screen $e');
    }
    return Text(
      title,
      style: TextStyle(
          color: HexColor.fromHex('#62CBC9'),
          fontSize: 18,
          fontWeight: FontWeight.bold),
    );
  }

  Future showDialogToEditName(
      {required GestureTapCallback onClickOk, String? title, bool? isNewTab}) {
    if (isNewTab != null && isNewTab) {
      selectedIcon = '';
    } else {
      selectedIcon = listOfPagesFromPreference[currentIndex].iconPath;
      titleController.text = listOfPagesFromPreference[currentIndex].title;
    }

    return showDialog(
        context: context,
        useRootNavigator: true,
        builder: (context) {
          return StatefulBuilder(builder: (context, setState) {
            return Dialog(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.h),
                ),
                elevation: 0,
                backgroundColor: Theme.of(context).brightness == Brightness.dark
                    ? HexColor.fromHex('#111B1A')
                    : AppColor.backgroundColor,
                child: Container(
                    decoration: BoxDecoration(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? AppColor.darkBackgroundColor
                            : AppColor.backgroundColor,
                        borderRadius: BorderRadius.circular(10.h),
                        boxShadow: [
                          BoxShadow(
                            color: Theme.of(context).brightness ==
                                    Brightness.dark
                                ? HexColor.fromHex('#D1D9E6').withOpacity(0.1)
                                : HexColor.fromHex('#DDE3E3').withOpacity(0.3),
                            blurRadius: 5,
                            spreadRadius: 0,
                            offset: Offset(-5, -5),
                          ),
                          BoxShadow(
                            color: Theme.of(context).brightness ==
                                    Brightness.dark
                                ? HexColor.fromHex('#000000').withOpacity(0.75)
                                : HexColor.fromHex('#384341').withOpacity(0.9),
                            blurRadius: 5,
                            spreadRadius: 0,
                            offset: Offset(5, 5),
                          ),
                        ]),
                    padding:
                        EdgeInsets.only(top: 27.h, left: 26.w, right: 26.w),
                    // height: 385.h,
                    width: 309.w,
                    child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: 25.h,
                            child: Body1AutoText(
                              text: (isNewTab != null && isNewTab)
                                  ? StringLocalization.of(context).getText(
                                      StringLocalization.addTitleOfpage)
                                  : StringLocalization.of(context).getText(
                                      StringLocalization.editTitleOfpage),
                              fontSize: 20.sp,
                              fontWeight: FontWeight.bold,
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? HexColor.fromHex('#FFFFFF')
                                      .withOpacity(0.87)
                                  : HexColor.fromHex('#384341'),
                              maxLine: 1,
                              minFontSize: 10,
                            ),
                          ),
                          Container(
                              padding: EdgeInsets.only(
                                top: 34.h,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Container(
                                    // height: 48.h,
                                    decoration: BoxDecoration(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? HexColor.fromHex('#111B1A')
                                            : AppColor.backgroundColor,
                                        borderRadius:
                                            BorderRadius.circular(10.h),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Theme.of(context)
                                                        .brightness ==
                                                    Brightness.dark
                                                ? HexColor.fromHex('#D1D9E6')
                                                    .withOpacity(0.1)
                                                : Colors.white.withOpacity(0.7),
                                            blurRadius: 4,
                                            spreadRadius: 0,
                                            offset: Offset(-4, -4),
                                          ),
                                          BoxShadow(
                                            color: Theme.of(context)
                                                        .brightness ==
                                                    Brightness.dark
                                                ? Colors.black.withOpacity(0.75)
                                                : HexColor.fromHex('#9F2DBC')
                                                    .withOpacity(0.15),
                                            blurRadius: 4,
                                            spreadRadius: 0,
                                            offset: Offset(4, 4),
                                          ),
                                        ]),
                                    child: GestureDetector(
                                      key: Key('newCategoryTitleContainer'),
                                      onTap: () {
                                        errorTitle = false;
                                        titleFocusNode.requestFocus();
                                        openKeyboardTitle = true;
                                        setState(() {});
                                      },
                                      child: Container(
                                        padding: EdgeInsets.only(
                                            left: 10.w, right: 10.w),
                                        decoration: openKeyboardTitle
                                            ? ConcaveDecoration(
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            10.h)),
                                                depression: 7,
                                                colors: [
                                                    Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? Colors.black
                                                            .withOpacity(0.5)
                                                        : HexColor.fromHex(
                                                            '#D1D9E6'),
                                                    Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? HexColor.fromHex(
                                                                '#D1D9E6')
                                                            .withOpacity(0.07)
                                                        : Colors.white,
                                                  ])
                                            : BoxDecoration(
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(10.h)),
                                                color: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? HexColor.fromHex(
                                                        '#111B1A')
                                                    : AppColor.backgroundColor,
                                              ),
                                        child: IgnorePointer(
                                          ignoring:
                                              openKeyboardTitle ? false : true,
                                          child: TextFormField(
                                            keyboardType: TextInputType.text,
                                            inputFormatters: [
                                              FilteringTextInputFormatter(
                                                  regExForRestrictEmoji(),
                                                  allow: false),
                                              FilteringTextInputFormatter(
                                                  RegExp('[a-zA-Z0-9 ]'),
                                                  allow: true),
                                              LengthLimitingTextInputFormatter(
                                                  20),
                                              FilteringTextInputFormatter(
                                                  RegExp(r'^\S.*$'),
                                                  allow: true)
                                            ],
                                            focusNode: titleFocusNode,
                                            controller: titleController,
                                            style: TextStyle(fontSize: 16.0),
                                            decoration: InputDecoration(
                                                border: InputBorder.none,
                                                focusedBorder: InputBorder.none,
                                                enabledBorder: InputBorder.none,
                                                errorBorder: InputBorder.none,
                                                disabledBorder:
                                                    InputBorder.none,
                                                hintText: sameTitle
                                                    ? 'Title already exists'
                                                    : errorTitle
                                                        ? StringLocalization.of(
                                                                context)
                                                            .getText(
                                                                StringLocalization
                                                                    .emptyTitle)
                                                        : StringLocalization.of(
                                                                context)
                                                            .getText(
                                                                StringLocalization
                                                                    .editTitle),
                                                hintStyle: TextStyle(
                                                    color: errorTitle ||
                                                            sameTitle
                                                        ? HexColor.fromHex(
                                                            'FF6259')
                                                        : Theme.of(context)
                                                                    .brightness ==
                                                                Brightness.dark
                                                            ? Colors.white
                                                                .withOpacity(
                                                                    0.38)
                                                            : HexColor.fromHex(
                                                                '7F8D8C'),
                                                    fontSize: 16.sp)),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 22.h),
                                  Row(
                                    children: [
                                      selectedIcon.isNotEmpty
                                          ? Image.asset(
                                              selectedIcon,
                                              height: 43.h,
                                              width: 43.h,
                                            )
                                          : Container(),
                                      selectedIcon.isNotEmpty
                                          ? SizedBox(
                                              width: 19.w,
                                            )
                                          : Container(),
                                      Material(
                                        color: Colors.transparent,
                                        child: InkWell(
                                          key: Key('selectIconText'),
                                          child: Text(
                                            stringLocalization.getText(
                                                StringLocalization.selectIcon),
                                            style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              color:
                                                  HexColor.fromHex('#00AFAA'),
                                              fontSize: 16.sp,
                                            ),
                                          ),
                                          onTap: () {
                                            Constants.navigatePush(
                                                    IconsScreen(
                                                      tagCategory: 3,
                                                    ),
                                                    context)
                                                .then((value) {
                                              screen = Constants.tagEditor;
                                              if (value != null) {
                                                selectedIcon = value;
                                                errorIcon = false;
                                                CustomSnackBar.CurrentBuildSnackBar(
                                                    context,
                                                    'Icon selected successfully');
                                              }
                                              setState(() {});
                                            });
                                          },
                                        ),
                                      )
                                    ],
                                  ),
                                  errorIcon
                                      ? Body1Text(
                                          text: 'Please select an Icon',
                                          color: AppColor.colorFF6259,
                                          fontSize: 12.sp,
                                        )
                                      : Container(),
                                  SizedBox(height: 29.h),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Container(
                                          height: 34.h,
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(30.h),
                                              color: HexColor.fromHex('#FF6259')
                                                  .withOpacity(0.8),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? HexColor.fromHex(
                                                              '#D1D9E6')
                                                          .withOpacity(0.1)
                                                      : Colors.white,
                                                  blurRadius: 5,
                                                  spreadRadius: 0,
                                                  offset: Offset(-5, -5),
                                                ),
                                                BoxShadow(
                                                  color: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? Colors.black
                                                          .withOpacity(0.75)
                                                      : HexColor.fromHex(
                                                          '#D1D9E6'),
                                                  blurRadius: 5,
                                                  spreadRadius: 0,
                                                  offset: Offset(5, 5),
                                                ),
                                              ]),
                                          child: Material(
                                            color: Colors.transparent,
                                            child: InkWell(
                                              borderRadius:
                                                  BorderRadius.circular(30.h),
                                              splashColor:
                                                  HexColor.fromHex('#FF6259')
                                                      .withOpacity(0.8),
                                              onTap: () {
                                                titleController.clear();
                                                openKeyboardTitle = false;
                                                sameTitle = false;
                                                errorTitle = false;
                                                if (context != null) {
                                                  Navigator.of(context,
                                                          rootNavigator: true)
                                                      .pop();
                                                }
                                              },
                                              child: Container(
                                                decoration: ConcaveDecoration(
                                                    shape:
                                                        RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              30.h),
                                                    ),
                                                    depression: 10,
                                                    colors: [
                                                      Colors.white,
                                                      HexColor.fromHex(
                                                          '#D1D9E6'),
                                                    ]),
                                                child: Center(
                                                  key: Key(
                                                      'addCategoryCancelButtom'),
                                                  child: Text(
                                                    stringLocalization
                                                        .getText(
                                                            StringLocalization
                                                                .cancel)
                                                        .toUpperCase(),
                                                    style: TextStyle(
                                                      fontSize: 14.sp,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? HexColor.fromHex(
                                                              '#111B1A')
                                                          : Colors.white,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(width: 17.w),
                                      Expanded(
                                        child: Container(
                                          height: 34.h,
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(30.h),
                                              color:
                                                  HexColor.fromHex('#00AFAA'),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? HexColor.fromHex(
                                                              '#D1D9E6')
                                                          .withOpacity(0.1)
                                                      : Colors.white,
                                                  blurRadius: 5,
                                                  spreadRadius: 0,
                                                  offset: Offset(-5, -5),
                                                ),
                                                BoxShadow(
                                                  color: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? Colors.black
                                                          .withOpacity(0.75)
                                                      : HexColor.fromHex(
                                                          '#D1D9E6'),
                                                  blurRadius: 5,
                                                  spreadRadius: 0,
                                                  offset: Offset(5, 5),
                                                ),
                                              ]),
                                          child: Material(
                                            color: Colors.transparent,
                                            child: InkWell(
                                              borderRadius:
                                                  BorderRadius.circular(30.h),
                                              splashColor:
                                                  HexColor.fromHex('#00AFAA'),
                                              onTap: () {
                                                validateTitle();
                                                for (var i = 0;
                                                    i <
                                                        listOfPagesFromPreference
                                                            .length;
                                                    i++) {
                                                  if (isNewTab != null &&
                                                      !isNewTab &&
                                                      i == currentIndex) {
                                                  } else if (listOfPagesFromPreference[
                                                                  i]
                                                              .title
                                                              .toLowerCase() ==
                                                          titleController.text
                                                              .toLowerCase() ||
                                                      titleController.text
                                                              .toLowerCase() ==
                                                          'bp') {
                                                    titleController.clear();
                                                    sameTitle = true;
                                                  }
                                                }

                                                if (!errorTitle &&
                                                    !sameTitle &&
                                                    !errorIcon) {
                                                  if (isNewTab != null &&
                                                      isNewTab) {
                                                    listOfPagesFromPreference
                                                        .add(
                                                      getGraphPageTemplate(
                                                        listOfPagesFromPreference
                                                            .length,
                                                        titleController.text,
                                                        selectedIcon,
                                                      ),
                                                    );
                                                  }
                                                  storeOrUpdatePreferenceList();
                                                  onClickOk();
                                                } else {
                                                  setState(() {});
                                                }
                                              },
                                              child: Container(
                                                decoration: ConcaveDecoration(
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            30.h),
                                                  ),
                                                  depression: 10,
                                                  colors: [
                                                    Colors.white,
                                                    HexColor.fromHex('#D1D9E6'),
                                                  ],
                                                ),
                                                child: Center(
                                                  key: Key(
                                                      'addCategoryAddButtom'),
                                                  child: Text(
                                                    isNewTab != null && isNewTab
                                                        ? stringLocalization
                                                            .getText(
                                                                StringLocalization
                                                                    .add)
                                                            .toUpperCase()
                                                        : stringLocalization
                                                            .getText(
                                                                StringLocalization
                                                                    .update)
                                                            .toUpperCase(),
                                                    style: TextStyle(
                                                      fontSize: 14.sp,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? HexColor.fromHex(
                                                              '#111B1A')
                                                          : Colors.white,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 25.h,
                                  )
                                ],
                              ))
                        ])));
          });
        },
        barrierDismissible: false);
  }

  ///Added by : Shahzad
  ///Added on: 22nd Feb 2021
  /// This function validates whether title field is empty or not
  validateTitle() {
    sameTitle = false;
    // errorTitle = false;
    if (titleController != null && titleController.text.trim().isEmpty) {
      errorTitle = true;
    }
    if (selectedIcon.isEmpty) {
      errorIcon = true;
    } else {
      errorIcon = false;
    }
    setState(() {});
  }

  PreferredSize dotIndicators() {
    try {
      if (listOfPagesFromPreference != null &&
          listOfPagesFromPreference.length > 0) {
        return PreferredSize(
          preferredSize: Size.fromHeight(10.h),
          child: Column(
            children: [
              Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Expanded(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: List<Widget>.generate(
                            listOfPagesFromPreference.length, (index) {


                          return Container(
                            width: 8.h,
                            height: 8.h,
                            margin: EdgeInsets.symmetric(horizontal: 4.w),
                            decoration: BoxDecoration(
                                color: currentIndex == index
//                                ? Colors.white
//                                : Colors.transparent,
                                    ? Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? HexColor.fromHex('#FF6259')
                                        : HexColor.fromHex('#FF9E99')
                                    : HexColor.fromHex('#BDC7C5'),
                                shape: BoxShape.circle),
                          );
                        }),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 10.h,
              )
            ],
          ),
        );
      }
    } catch (e) {
      print('Exception at pageview screen $e');
    }
    return PreferredSize(
      preferredSize: Size(Constants.width.w, 0.h),
      child: Container(),
    );
  }

  Widget nextButton() {
    return InkWell(
        child: Container(
          key: Key('graphScreenNextButton'),
          // padding: EdgeInsets.only(left: 10.w),
          alignment: Alignment.center,
          height: 33.h,
          width: 33.w,
          // color: Colors.red,
          child: Image.asset(
            Theme.of(context).brightness == Brightness.dark
                ? 'asset/dark_right.png'
                : 'asset/right.png',
          ),
        ),
        onTap: () async {
          if (listOfPagesFromPreference == null ||
              listOfPagesFromPreference.length == 0 ||
              currentIndex == listOfPagesFromPreference.length - 1) {
            pageController.jumpToPage(0);
          } else {
            pageController.nextPage(
                duration: Duration(milliseconds: 400), curve: Curves.linear);
            currentIndex++;
          }
          await refreshData();
          if (this.mounted) {
            setState(() {});
          }
        });
  }

  Widget previousButton() {
    return InkWell(
      child: Container(
        key: Key('graphScreenPreviousButton'),
        alignment: Alignment.center,
        height: 33.h,
        width: 33.w,
        child: Image.asset(
          Theme.of(context).brightness == Brightness.dark
              ? 'asset/dark_left.png'
              : 'asset/left.png',
        ),
      ),
      onTap: () async {
        if (currentIndex == 0) {
          pageController.jumpToPage(listOfPagesFromPreference.length - 1);
        } else {
          pageController.previousPage(
              duration: Duration(milliseconds: 400), curve: Curves.linear);
          currentIndex--;
        }


        await refreshData();
        if (mounted) {
          setState(() {});
        }
      },
    );
  }

//   loadPreference() async {
//     if (preferences == null) {
//       preferences = await SharedPreferences.getInstance();
//     }
//     userId = preferences.getString(Constants.prefUserIdKeyInt);
//     await getGraphTypeModelList();
//
//     var listOfPages = preferences.getStringList(Constants.prefKeyForGraphPages);
//     if (listOfPages != null && listOfPages.isNotEmpty) {
//       listOfPagesFromPreference = listOfPages
//           .map((e) => GraphSharedPreferenceManagerModel.fromMap(jsonDecode(e)))
//           .toList();
//     } else {
//       GraphSharedPreferenceManagerModel graphSharedPreferenceManagerModel =
//           new GraphSharedPreferenceManagerModel(
//               index: 0,
//               title: stringLocalization.getText(StringLocalization.tab),
//               windowList: [
//             new WindowModel(
//               index: 0,
//               title: stringLocalization.getText(StringLocalization.unknown),
//               selectedChartType: ChartType.bar,
//               selectedType: [
// //                  graphTypeList.firstWhere((element) => element.fieldName == DefaultGraphItem.step.fieldName),
// //                  graphTypeList.firstWhere((element) => element.fieldName == DefaultGraphItem.hrv.fieldName),
// //                  graphTypeList.firstWhere((element) => element.fieldName == DefaultGraphItem.allSleep.fieldName),
//               ],
//             )
//           ]);
//       listOfPagesFromPreference.add(graphSharedPreferenceManagerModel);
//       storeOrUpdatePreferenceList();
//     }
//     showLoadingScreen = false;
//     currentIndex = 0;
//     if (this.mounted) {
//       setState(() {});
//     }
//   }

  GraphSharedPreferenceManagerModel getGraphPageTemplate(
      index, title, iconPath) {
    return GraphSharedPreferenceManagerModel(
        iconPath: iconPath,
        isDefault: false,
        index: index,
        title: title,
        windowList: [
          new WindowModel(
              // onChangeDate:ValueNotifier<DateTime?>(DateTime(
              //     DateTime.now().year,
              //     DateTime.now().month,
              //     DateTime.now().day,
              //     0,
              //     0,
              //     0,
              //     0,
              //     0)),
              index: 0,
              title: '',
              selectedChartType: ChartType.bar,
              selectedType: [],
              normalization: false,
              editMode: true,
              defaultGraph: false,
              interpolation: false)
        ]);
  }

  Future getGraphTypeModelList() async {
    graphTypeList = await dbHelper.getGraphTypeList(userId);
    graphTypeList.forEach((element) {
      print("getGraphTypeModelList ${element.fieldName}");
    });
    if (graphTypeList == null || graphTypeList.length == 0) {
      await storeGraphTypes();
    }
    await addTagInItem(graphTypeList);
    return Future.value();
  }

  Future addTagInItem(List<GraphTypeModel> graphTypeList) async {
    var tagList = await dbHelper.getTagList(userId);
    //region remove null and deleted tag from list
    try {
      List indexList = tagList.where((tag) {
        try {
          print('remove ${tag.isRemove}');
        } catch (e) {
          print('Exception at pageview screen $e');
        }
        return (tag == null ||
            (tag.tagType != null && tag.tagType == TagType.sleep.value) ||
            (tag.isRemove == 1));
      }).toList();

      for (var i = 0; i < indexList.length; i++) {
        tagList.remove(indexList[i]);
      }
    } catch (e) {
      print('Exception at page view screen $e');
    }
    //endregion
    for (var i = 0; i < tagList.length; i++) {
      var tag = tagList[i];
      var tagType = new GraphTypeModel(
          name:
              '${tag.label} (${stringLocalization.getText(StringLocalization.tag)})',
          fieldName: tag.label ?? '',
          tableName: DefaultGraphItem.tag.tableName,
          color: AppColor.primaryColor.toHex(),
          image: tag.icon ?? '');
      var index = graphTypeList.indexWhere((element) =>
          ((element.fieldName == tag.label) &&
              (element.tableName == DefaultGraphItem.tag.tableName)));
      if (index > -1) {
        var existGraphTypeModel = graphTypeList[index];
        tagType.id = existGraphTypeModel.id;
      }
      var map = tagType.toMap();
      map[DatabaseTableNameAndFields.UserId] = userId;
      tagType.id = await dbHelper.insertUpdateGraphTypeTable(map);
      graphTypeList.add(tagType);
    }
    graphTypeList = graphTypeList.toSet().toList();
    //region distinct graph type list
    try {
      var distinctGraphTypeList = <GraphTypeModel>[];
      graphTypeList.forEach((element) {
        if (!distinctGraphTypeList.any((e) => e.id == element.id)) {
          distinctGraphTypeList.add(element);
        }
      });
      graphTypeList = distinctGraphTypeList;
    } catch (e) {
      print('Exception at pageview screen $e');
    }
    //endregion
    print(graphTypeList);
  }

  Future storeGraphTypes() async {
    var step = GraphTypeModel(
        name: DefaultGraphItem.step.name(context),
        fieldName: DefaultGraphItem.step.fieldName,
        tableName: DefaultGraphItem.step.tableName,
        color: DefaultGraphItem.step.color.toHex(),
        image: await DefaultGraphItem.step.imageString);
    var hr = GraphTypeModel(
        name: DefaultGraphItem.hr.name(context),
        fieldName: DefaultGraphItem.hr.fieldName,
        tableName: DefaultGraphItem.hr.tableName,
        color: DefaultGraphItem.hr.color.toHex(),
        image: await DefaultGraphItem.hr.imageString);
    var hrv = GraphTypeModel(
        name: DefaultGraphItem.hrv.name(context),
        fieldName: DefaultGraphItem.hrv.fieldName,
        tableName: DefaultGraphItem.hrv.tableName,
        color: DefaultGraphItem.hrv.color.toHex(),
        image: await DefaultGraphItem.hrv.imageString);
    var sbp = GraphTypeModel(
        name: DefaultGraphItem.sbp.name(context),
        fieldName: DefaultGraphItem.sbp.fieldName,
        tableName: DefaultGraphItem.sbp.tableName,
        color: DefaultGraphItem.sbp.color.toHex(),
        image: await DefaultGraphItem.sbp.imageString);
    var dbp = GraphTypeModel(
        name: DefaultGraphItem.dbp.name(context),
        fieldName: DefaultGraphItem.dbp.fieldName,
        tableName: DefaultGraphItem.dbp.tableName,
        color: DefaultGraphItem.dbp.color.toHex(),
        image: await DefaultGraphItem.dbp.imageString);
    var allSleep = GraphTypeModel(
        name: DefaultGraphItem.allSleep.name(context),
        fieldName: DefaultGraphItem.allSleep.fieldName,
        tableName: DefaultGraphItem.allSleep.tableName,
        color: DefaultGraphItem.allSleep.color.toHex(),
        image: await DefaultGraphItem.allSleep.imageString);
    var deepSleep = GraphTypeModel(
        name: DefaultGraphItem.deepSleep.name(context),
        fieldName: DefaultGraphItem.deepSleep.fieldName,
        tableName: DefaultGraphItem.deepSleep.tableName,
        color: DefaultGraphItem.deepSleep.color.toHex(),
        image: await DefaultGraphItem.deepSleep.imageString);
    var lightSleep = GraphTypeModel(
        name: DefaultGraphItem.lightSleep.name(context),
        fieldName: DefaultGraphItem.lightSleep.fieldName,
        tableName: DefaultGraphItem.lightSleep.tableName,
        color: DefaultGraphItem.lightSleep.color.toHex(),
        image: await DefaultGraphItem.lightSleep.imageString);
    var awake = GraphTypeModel(
        name: DefaultGraphItem.awake.name(context),
        fieldName: DefaultGraphItem.awake.fieldName,
        tableName: DefaultGraphItem.awake.tableName,
        color: DefaultGraphItem.awake.color.toHex(),
        image: await DefaultGraphItem.awake.imageString);
    var healthKitStep = GraphTypeModel(
        name: DefaultGraphItem.healthKitStep.name(context),
        fieldName: DefaultGraphItem.healthKitStep.fieldName,
        tableName: DefaultGraphItem.healthKitStep.tableName,
        color: DefaultGraphItem.step.color.toHex(),
        image: await DefaultGraphItem.healthKitStep.imageString);
    var healthKitSleep = GraphTypeModel(
        name: DefaultGraphItem.healthKitSleep.name(context),
        fieldName: DefaultGraphItem.healthKitSleep.fieldName,
        tableName: DefaultGraphItem.healthKitStep.tableName,
        color: DefaultGraphItem.step.color.toHex(),
        image: await DefaultGraphItem.healthKitSleep.imageString);
    var healthKitDistance = GraphTypeModel(
        name: DefaultGraphItem.healthKitDistance.name(context),
        fieldName: DefaultGraphItem.healthKitDistance.fieldName,
        tableName: DefaultGraphItem.healthKitStep.tableName,
        color: DefaultGraphItem.step.color.toHex(),
        image: await DefaultGraphItem.healthKitDistance.imageString);
    // GraphTypeModel healthKitHeight =  GraphTypeModel(
    //     name: DefaultGraphItem.healthKitHeight.name(context),
    //     fieldName: DefaultGraphItem.healthKitHeight.fieldName,
    //     tableName: DefaultGraphItem.healthKitStep.tableName,
    //     color: DefaultGraphItem.step.color.toHex(),
    //     image: await DefaultGraphItem.healthKitHeight.imageString);
    var healthKitWeight = GraphTypeModel(
        name: DefaultGraphItem.healthKitWeight.name(context),
        fieldName: DefaultGraphItem.healthKitWeight.fieldName,
        tableName: DefaultGraphItem.healthKitStep.tableName,
        color: DefaultGraphItem.step.color.toHex(),
        image: await DefaultGraphItem.healthKitWeight.imageString);
    var healthKitHeartRate = GraphTypeModel(
        name: DefaultGraphItem.healthKitHeartRate.name(context),
        fieldName: DefaultGraphItem.healthKitHeartRate.fieldName,
        tableName: DefaultGraphItem.healthKitStep.tableName,
        color: DefaultGraphItem.step.color.toHex(),
        image: await DefaultGraphItem.healthKitHeartRate.imageString);
    var healthKitSbp = GraphTypeModel(
        name: DefaultGraphItem.healthKitSBP.name(context),
        fieldName: DefaultGraphItem.healthKitSBP.fieldName,
        tableName: DefaultGraphItem.healthKitStep.tableName,
        color: DefaultGraphItem.step.color.toHex(),
        image: await DefaultGraphItem.healthKitSBP.imageString);
    var healthKitDbp = GraphTypeModel(
        name: DefaultGraphItem.healthKitDBP.name(context),
        fieldName: DefaultGraphItem.healthKitDBP.fieldName,
        tableName: DefaultGraphItem.healthKitStep.tableName,
        color: DefaultGraphItem.step.color.toHex(),
        image: await DefaultGraphItem.healthKitDBP.imageString);
    var healthKitBloodGlucose = GraphTypeModel(
        name: DefaultGraphItem.healthKitBloodGlucose.name(context),
        fieldName: DefaultGraphItem.healthKitBloodGlucose.fieldName,
        tableName: DefaultGraphItem.healthKitStep.tableName,
        color: DefaultGraphItem.step.color.toHex(),
        image: await DefaultGraphItem.healthKitBloodGlucose.imageString);
    var weight = GraphTypeModel(
        name: DefaultGraphItem.weight.name(context),
        fieldName: DefaultGraphItem.weight.fieldName,
        tableName: DefaultGraphItem.weight.tableName,
        color: DefaultGraphItem.weight.color.toHex(),
        image: await DefaultGraphItem.weight.imageString);
    var bmi = GraphTypeModel(
        name: DefaultGraphItem.bmi.name(context),
        fieldName: DefaultGraphItem.bmi.fieldName,
        tableName: DefaultGraphItem.bmi.tableName,
        color: DefaultGraphItem.bmi.color.toHex(),
        image: await DefaultGraphItem.bmi.imageString);
    var bfr = GraphTypeModel(
        name: DefaultGraphItem.bfr.name(context),
        fieldName: DefaultGraphItem.bfr.fieldName,
        tableName: DefaultGraphItem.bfr.tableName,
        color: DefaultGraphItem.bfr.color.toHex(),
        image: await DefaultGraphItem.bfr.imageString);
    var muscleRate = GraphTypeModel(
        name: DefaultGraphItem.muscleRate.name(context),
        fieldName: DefaultGraphItem.muscleRate.fieldName,
        tableName: DefaultGraphItem.muscleRate.tableName,
        color: DefaultGraphItem.muscleRate.color.toHex(),
        image: await DefaultGraphItem.muscleRate.imageString);
    var bodyWater = GraphTypeModel(
        name: DefaultGraphItem.bodyWater.name(context),
        fieldName: DefaultGraphItem.bodyWater.fieldName,
        tableName: DefaultGraphItem.bodyWater.tableName,
        color: DefaultGraphItem.bodyWater.color.toHex(),
        image: await DefaultGraphItem.bodyWater.imageString);
    var bmr = GraphTypeModel(
        name: DefaultGraphItem.bmr.name(context),
        fieldName: DefaultGraphItem.bmr.fieldName,
        tableName: DefaultGraphItem.bmr.tableName,
        color: DefaultGraphItem.bmr.color.toHex(),
        image: await DefaultGraphItem.bmr.imageString);
    var boneMass = GraphTypeModel(
        name: DefaultGraphItem.boneMass.name(context),
        fieldName: DefaultGraphItem.boneMass.fieldName,
        tableName: DefaultGraphItem.boneMass.tableName,
        color: DefaultGraphItem.boneMass.color.toHex(),
        image: await DefaultGraphItem.boneMass.imageString);
    var proteinRate = GraphTypeModel(
        name: DefaultGraphItem.proteinRate.name(context),
        fieldName: DefaultGraphItem.proteinRate.fieldName,
        tableName: DefaultGraphItem.proteinRate.tableName,
        color: DefaultGraphItem.proteinRate.color.toHex(),
        image: await DefaultGraphItem.proteinRate.imageString);
    var visceralFatIndex = GraphTypeModel(
        name: DefaultGraphItem.visceralFatIndex.name(context),
        fieldName: DefaultGraphItem.visceralFatIndex.fieldName,
        tableName: DefaultGraphItem.bodyWater.tableName,
        color: DefaultGraphItem.visceralFatIndex.color.toHex(),
        image: await DefaultGraphItem.visceralFatIndex.imageString);
    var calories = GraphTypeModel(
        name: DefaultGraphItem.calories.name(context),
        fieldName: DefaultGraphItem.calories.fieldName,
        tableName: DefaultGraphItem.calories.tableName,
        color: DefaultGraphItem.calories.color.toHex(),
        image: await DefaultGraphItem.calories.imageString);
    var temperature = GraphTypeModel(
        name: DefaultGraphItem.temperature.name(context),
        fieldName: DefaultGraphItem.temperature.fieldName,
        tableName: DefaultGraphItem.temperature.tableName,
        color: DefaultGraphItem.temperature.color.toHex(),
        image: await DefaultGraphItem.temperature.imageString);
    var oxygen = GraphTypeModel(
        name: DefaultGraphItem.oxygen.name(context),
        fieldName: DefaultGraphItem.oxygen.fieldName,
        tableName: DefaultGraphItem.oxygen.tableName,
        color: DefaultGraphItem.oxygen.color.toHex(),
        image: await DefaultGraphItem.oxygen.imageString);
    var healthKitTemperature = GraphTypeModel(
        name: DefaultGraphItem.healthKitTemperature.name(context),
        fieldName: DefaultGraphItem.healthKitTemperature.fieldName,
        tableName: DefaultGraphItem.healthKitTemperature.tableName,
        color: DefaultGraphItem.healthKitTemperature.color.toHex(),
        image: await DefaultGraphItem.healthKitTemperature.imageString);
    var healthKitOxygen = GraphTypeModel(
        name: DefaultGraphItem.healthKitOxygen.name(context),
        fieldName: DefaultGraphItem.healthKitOxygen.fieldName,
        tableName: DefaultGraphItem.healthKitOxygen.tableName,
        color: DefaultGraphItem.healthKitOxygen.color.toHex(),
        image: await DefaultGraphItem.healthKitOxygen.imageString);

    graphTypeList.add(step);
    graphTypeList.add(hr);
    graphTypeList.add(hrv);
    graphTypeList.add(sbp);
    graphTypeList.add(dbp);
    graphTypeList.add(allSleep);
    graphTypeList.add(deepSleep);
    graphTypeList.add(lightSleep);
    graphTypeList.add(awake);
    // graphTypeList.add(healthKitSleep);
    // graphTypeList.add(healthKitDistance);
    // graphTypeList.add(healthKitWeight);
    // graphTypeList.add(healthKitHeartRate);
    // graphTypeList.add(healthKitSbp);
    // graphTypeList.add(healthKitDbp);
    // graphTypeList.add(healthKitStep);
    // graphTypeList.add(healthKitBloodGlucose);
    graphTypeList.add(weight);
    graphTypeList.add(bmi);
    graphTypeList.add(bfr);
    graphTypeList.add(bodyWater);
    graphTypeList.add(muscleRate);
    graphTypeList.add(bmr);
    graphTypeList.add(boneMass);
    graphTypeList.add(proteinRate);
    graphTypeList.add(visceralFatIndex);
    graphTypeList.add(calories);
    graphTypeList.add(temperature);
    graphTypeList.add(oxygen);
    // graphTypeList.add(healthKitTemperature);
    // graphTypeList.add(healthKitOxygen);

    for (var i = 0; i < graphTypeList.length; i++) {
      var map = graphTypeList[i].toMap();
      map[DatabaseTableNameAndFields.UserId] = userId;
      graphTypeList[i].id = await dbHelper.insertUpdateGraphTypeTable(map);
    }
    return Future.value();
  }

  void popTillThis(int index) async {
    showLoadingScreen = true;
    Future.delayed(Duration(milliseconds: 100), () async {
      pageController = PageController(initialPage: index);
      await initialLoadPreference();
    });
    setState(() {});
  }

  initialLoadPreference() async {
    userId = preferences!.getString(Constants.prefUserIdKeyInt) ?? '';
    await getGraphTypeModelList();

    var listOfPages =
        preferences!.getStringList(Constants.prefKeyForGraphPages);
    if (listOfPages != null && listOfPages.isNotEmpty) {
      listOfPagesFromPreference = listOfPages
          .map((e) => GraphSharedPreferenceManagerModel.fromMap(jsonDecode(e)))
          .toList();
      print(
          'listOfPagesFromPreference ${listOfPagesFromPreference.map((e) => e.title)}');
      print('listOfPagesFromPreference $currentIndex');
      if (listOfPagesFromPreference[0].windowList.length < 3) {
        listOfPagesFromPreference[0].windowList = [];
        listOfPagesFromPreference[0].windowList.add(WindowModel(
            // onChangeDate:ValueNotifier<DateTime?>(DateTime(
            //     DateTime.now().year,
            //     DateTime.now().month,
            //     DateTime.now().day,
            //     0,
            //     0,
            //     0,
            //     0,
            //     0)),
            defaultGraph: true,
            index: 0,
            title:
                '${stringLocalization.getText(StringLocalization.heartRate)} Vs ${stringLocalization.getText(StringLocalization.allSleep)}',
            selectedChartType: ChartType.line,
            selectedType: [
              graphTypeList.firstWhere((element) =>
                  element.fieldName == DefaultGraphItem.hr.fieldName),
              graphTypeList.firstWhere((element) =>
                  element.fieldName == DefaultGraphItem.allSleep.fieldName),
            ],
            normalization: false,
            editMode: false,
            interpolation: false));
        listOfPagesFromPreference[0].windowList.add(WindowModel(
            // onChangeDate:ValueNotifier<DateTime?>(DateTime(
            //     DateTime.now().year,
            //     DateTime.now().month,
            //     DateTime.now().day,
            //     0,
            //     0,
            //     0,
            //     0,
            //     0)),
            defaultGraph: true,
            index: 1,
            title:
                '${stringLocalization.getText(StringLocalization.oxygen)} Vs ${stringLocalization.getText(StringLocalization.allSleep)}',
            selectedChartType: ChartType.line,
            selectedType: [
              graphTypeList.firstWhere((element) =>
                  element.fieldName == DefaultGraphItem.oxygen.fieldName),
              graphTypeList.firstWhere((element) =>
                  element.fieldName == DefaultGraphItem.allSleep.fieldName),
            ],
            normalization: false,
            editMode: false,
            interpolation: false));
        listOfPagesFromPreference[0].windowList.add(WindowModel(
            // onChangeDate:ValueNotifier<DateTime?>(DateTime(
            //     DateTime.now().year,
            //     DateTime.now().month,
            //     DateTime.now().day,
            //     0,
            //     0,
            //     0,
            //     0,
            //     0)),
            defaultGraph: true,
            index: 2,
            title:
                '${stringLocalization.getText(StringLocalization.bodyTemperature)} Vs ${stringLocalization.getText(StringLocalization.allSleep)}',
            selectedChartType: ChartType.line,
            selectedType: [
              graphTypeList.firstWhere((element) =>
                  element.fieldName == DefaultGraphItem.temperature.fieldName),
              graphTypeList.firstWhere((element) =>
                  element.fieldName == DefaultGraphItem.allSleep.fieldName),
            ],
            normalization: false,
            editMode: false,
            interpolation: false));
      }
      for (var i = 5; i < listOfPagesFromPreference.length; i++) {
        listOfPagesFromPreference[i].windowList.removeWhere((element) {
          for (var item in element!.selectedType) {
            if (item.fieldName == DefaultGraphItem.deepSleep.fieldName ||
                item.fieldName == DefaultGraphItem.lightSleep.fieldName ||
                item.fieldName == DefaultGraphItem.allSleep.fieldName ||
                item.fieldName == DefaultGraphItem.awake.fieldName) {
              return true;
            }
          }
          return false;
        });
      }

      for (var item in listOfPagesFromPreference) {
        for (var ele in item.windowList) {
          if (Platform.isAndroid &&
              ele != null &&
              ele.title.contains('HealthKit')) {
            ele.title = ele.title.replaceAll('HealthKit', 'GoogleFit');
            for (var data in ele.selectedType) {
              if (data.name.contains('HealthKit')) {
                data.name = data.name.replaceAll('HealthKit', 'GoogleFit');
              }
            }
          } else if (Platform.isIOS &&
              ele != null &&
              ele.title.contains('GoogleFit')) {
            ele.title = ele.title.replaceAll('GoogleFit', 'HealthKit');
            for (var data in ele.selectedType) {
              if (data.name.contains('GoogleFit')) {
                data.name = data.name.replaceAll('GoogleFit', 'HealthKit');
              }
            }
          }
        }
      }
    }
    showLoadingScreen = false;
    currentIndex = widget.graphPageIndex;
    if (mounted) {
      setState(() {});
    }
  }
}
